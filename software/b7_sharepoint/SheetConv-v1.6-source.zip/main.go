// SheetConv: konverter Google Sheets ke Excel (SharePoint).
// Jalankan: ./sheetconv  (port default 2030, bisa diubah lewat env PORT)
// File formulas.json di folder yang sama (kalau ada) dipakai sebagai katalog;
// kalau tidak ada, dipakai katalog yang ter-embed di binary.
package main

import (
	"embed"
	"fmt"
	"html/template"
	"log"
	"os"
	"path/filepath"
	"runtime/debug"

	"github.com/labstack/echo/v4"

	"sheetconv/engine"
	"sheetconv/web"
)

//go:embed formulas.json
var embeddedFormulas []byte

//go:embed template/*.html
var embeddedTemplates embed.FS

//go:embed static/*
var embeddedStatic embed.FS

func main() {
	// Batas memori lunak: GC bekerja lebih agresif supaya proses convert
	// workbook besar tidak membengkak (file 25 MB bisa butuh >1 GB sesaat).
	debug.SetMemoryLimit(2 << 30)
	cat, err := engine.LoadCatalog("formulas.json", embeddedFormulas)
	if err != nil {
		log.Fatalf("katalog gagal dimuat: %v", err)
	}

	// Template: dari disk dulu (bisa diedit tanpa rebuild), fallback embed.
	var tmpl *template.Template
	if data, err := os.ReadFile(filepath.Join("template", "index.html")); err == nil {
		tmpl, err = template.New("index.html").Parse(string(data))
		if err != nil {
			log.Fatalf("template gagal diparse: %v", err)
		}
	} else {
		tmpl, err = template.ParseFS(embeddedTemplates, "template/*.html")
		if err != nil {
			log.Fatalf("template embed gagal diparse: %v", err)
		}
	}

	// Static embed sebagai fallback.
	staticFS := map[string][]byte{}
	if entries, err := embeddedStatic.ReadDir("static"); err == nil {
		for _, e := range entries {
			if b, err := embeddedStatic.ReadFile("static/" + e.Name()); err == nil {
				staticFS[e.Name()] = b
			}
		}
	}

	e := echo.New()
	e.HideBanner = true
	srv := web.NewServer(cat, tmpl, staticFS)
	srv.Routes(e)

	port := os.Getenv("PORT")
	if port == "" {
		port = "2030"
	}
	fmt.Printf("SheetConv jalan di http://localhost:%s\n", port)
	fmt.Printf("Katalog: %d fungsi Excel native, %d pemetaan Google Sheets -> Excel.\n", len(cat.Native), len(cat.Mappings))
	if err := e.Start(":" + port); err != nil {
		log.Fatalf("server gagal jalan: %v", err)
	}
}
