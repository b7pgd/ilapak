# SheetConv

Konverter Google Sheets ke Excel (untuk file yang disimpan di SharePoint /
OneDrive). Rumus tetap rumus, tidak diubah jadi nilai.

## Menjalankan

Butuh Go 1.21+. Dari folder project:

```sh
go run .                # jalan di http://localhost:2030
```

Port bisa diubah lewat environment variable `PORT`:

```sh
PORT=8080 go run .
```

File `formulas.json`, folder `template/` dan folder `static/` harus berada di
folder yang sama dengan `main.go`. Kalau file `formulas.json` ada di sebelah
project, katalog yang dipakai adalah file itu (jadi pemetaan rumus bisa diedit
tanpa rebuild; restart server sesudah edit). Kalau tidak ada, dipakai katalog
yang tertanam di dalam binary.

Untuk membuat binary sendiri:

```sh
go build -o sheetconv .                   # Linux / macOS
GOOS=windows go build -o sheetconv.exe .  # Windows
```

## Cara pakai

Satu halaman, dua cara import:

1. **Link Google Sheets** - tempel link spreadsheet publik (Anyone with the
   link). File diambil dari link, dikonversi, lalu bisa diunduh.
2. **Upload File** - upload file `.xlsx` (rumus ikut dikonversi) atau `.csv`
   (data saja, maks 100 MB).

Selama convert ada bar loading dengan persen dan perkiraan sisa waktu.
Sesudah selesai muncul panel hasil analisa dan tombol unduh. File hasil
convert otomatis terhapus dari server setelah diunduh, atau 10 menit setelah
selesai. Refresh halaman juga menghilangkan file. **Server tidak pernah
menyimpan file ke disk** - semua pemrosesan di memori.

Hasil convert adalah file `.xlsx` yang bisa di-upload ke SharePoint lalu
dibuka lewat File > Open (Excel Online).

## Cara kerja convert

- **Rumus native Excel** (IF, VLOOKUP, SUMIFS, dan 500+ fungsi lainnya)
  dipakai apa adanya, tanpa diubah.
- **IMPORTRANGE dan QUERY (v1.6: rumus per-sel hidup)** di-convert jadi
  rumus Excel per-sel: tiap sel hasil menunjuk ke satu sel sumber di sheet
  `_IMPORT` (atau tab lokal), mis. `IF(_IMPORT!A1="","",_IMPORT!A1)`,
  lengkap dengan nilai cache. Tidak ada rumus dynamic-array
  (LET/VSTACK/FILTER + spill) di file hasil, tapi rumusnya tetap HIDUP:
  kalau nilai sumber berubah, hasil ikut berubah. QUERY dievaluasi di
  converter (dari data cache) untuk menentukan baris mana yang masuk
  hasil, lalu tiap sel hasil ditulis sebagai rumus per-sel ke sumbernya.
- **Pivot table yang sumbernya workbook eksternal** ("in.xlsx", artefak
  export Google) diperbaiki jadi sumber lokal, dan refresh otomatis saat
  dibuka dimatikan supaya tidak muncul error Data Refresh Failed.
- **Rumus #REF!** (referensi sheet hilang saat export) diperbaiki dengan
  menyalin referensi dari rumus yang polanya sama di sheet yang sama;
  yang tidak punya donor dilaporkan.
- **Referensi kolom penuh** (mis. `$H:$H`) dibatasi ke baris terakhir data
  supaya tidak memicu peringatan SLOW WORKBOOK di Excel Online.
- **Sel kosong tetap kosong**, bukan 0: rumus per-sel dibungkus
  `IF(src="","",src)` dan nilai cache-nya kosong.
- **Pivot table, Excel table, dan semua bagian lain file** dipertahankan apa
  adanya (hanya sel yang berubah yang disentuh).
- **Tidak ada hardcoding perhitungan**: rumus tidak pernah diubah jadi nilai
  statis. Yang dibekukan hanyalah sel yang sumber impornya tidak bisa
  diunduh sama sekali (dan itu dicatat jelas di laporan). Untuk memperbarui
  data impor, jalankan converter lagi.

## Panel hasil analisa

- **Rumus dengan padanan persis** - fungsi yang sama persis di Excel.
- **Rumus dengan padanan** - fungsi Google yang tidak ada persis di Excel,
  diganti padanan beserta penjelasan mekanismenya.
- **Rumus dengan padanan sebagian** - padanan yang tidak 100% sama; cek
  hasilnya sebelum dipakai.
- **Rumus tanpa padanan** (kotak merah) - fungsi yang tidak punya padanan di
  Excel dan dibiarkan apa adanya; sel yang memakainya mungkin menampilkan
  error di Excel.
- **Rumus tidak dikenali** - fungsi yang tidak ada di katalog; laporkan ke
  pengembang supaya ditambahkan pemetaannya.
- **Sheet tambahan (_IMPORT)** - 1 sheet tersembunyi berisi semua blok data
  hasil impor (satu blok per IMPORTRANGE, lengkap dengan sumber dan
  ukurannya). Sheet asli tidak berubah jumlahnya; sheet ini hanya tempat
  data, bukan sheet kerja. Untuk melihatnya, klik kanan tab mana pun lalu
  Unhide.
- **Rumus impor ditulis per-sel** - jumlah sel hasil IMPORTRANGE/QUERY yang
  ditulis sebagai rumus per-sel hidup (tanpa dynamic-array).
- **Pivot table diperbaiki** - pivot yang sumbernya workbook eksternal
  (in.xlsx) dan sudah dijadikan sheet lokal.
- **Rumus #REF!** - jumlah yang diperbaiki dan yang tidak bisa diperbaiki
  (tanpa donor yang polanya sama).
- **Referensi kolom penuh dibatasi** - jumlah rumus yang jangkauan kolom
  penuhnya dibatasi ke baris terakhir data.
- **Sel yang dibekukan jadi nilai** - daftar sel yang terpaksa dibekukan
  (hanya kalau sumber impor tidak bisa diunduh).

## Katalog rumus

Katalog ada di `formulas.json` (bisa diedit):

- **519 fungsi Excel native** (daftar resmi Microsoft).
- **50 pemetaan** Google Sheets ke Excel: 44 padanan, 4 parsial
  (GOOGLEFINANCE, ISDATE, ISEMAIL, ISURL), 2 tanpa padanan rumus (SPARKLINE,
  AI).
- **8 fungsi native yang tidak jalan di Excel Online**: CELL, ENCODEURL,
  FILTERXML, INFO, WEBSERVICE, CALL, REGISTER.ID, RTD. Fungsi ini di-flag
  di laporan, bukan diklaim bisa.

Urutan pengecekan: pemetaan dulu, lalu fungsi native, lalu flag merah kalau
tidak dikenal.

## Batasan yang jujur

- **Tidak ada auto-update.** Data hasil convert tidak berubah sendiri kalau
  Google Sheet sumber berubah. Ini memang alat migrasi: sesudah migrasi,
  file hasil convert di SharePoint yang jadi sumber kebenaran baru. Auto-update
  butuh sumber di SharePoint + Power Query, itu urusan fase berikutnya.
- **Pivot table tidak dihitung ulang otomatis** oleh converter; pivot
  menampilkan data cache dari export. Tekan Refresh di Excel sesudah dibuka
  untuk memperbarui (sumbernya sudah lokal, jadi refresh bisa jalan).
- **LibreOffice tidak bisa menghitung rumus modern** (LET, VSTACK, FILTER,
  UNIQUE, SORT). File hasil convert v1.6 tidak memakai rumus itu, jadi bisa
  dibuka dan dihitung di LibreOffice. Verifikasi perhitungan akhir sebaiknya
  tetap di Excel / Excel Online.
- **Excel Online dan file besar.** File hasil convert sengaja TIDAK memakai
  `fullCalcOnLoad` (tanda "hitung ulang semua rumus saat dibuka"). Tanda itu
  membuat Excel Online menghitung ulang ratusan ribu rumus saat membuka file
  sehingga kehabisan waktu dan menolak membuka workbook ("Couldn't Open the
  Workbook"). Sejak v1.6, rumus Google-only (IMPORTRANGE/QUERY) ditulis
  sebagai rumus per-sel hidup (IF ke satu sel sumber) dengan nilai cache,
  jadi file tidak mengandung rumus dynamic-array (LET/VSTACK/FILTER) sama
  sekali dan Excel Online membukanya dengan nilai cache tanpa menghitung
  ulang rumus berat.

## Perubahan v1.6

- **Pendekatan baru: rumus per-sel hidup (tanpa dynamic-array, tanpa mode
  beku).** Mode beku v1.5 DITARIK karena melanggar aturan keras (jangan
  hardcode rumus jadi nilai mati). Sekarang IMPORTRANGE/QUERY di-convert
  jadi rumus per-sel: tiap sel hasil menunjuk ke satu sel sumber
  (`IF(_IMPORT!A1="","",_IMPORT!A1)`) lengkap dengan nilai cache. QUERY
  dievaluasi di converter dari data cache untuk menentukan baris hasil,
  lalu tiap sel hasil ditulis sebagai rumus per-sel ke sumbernya. File
  hasil TIDAK mengandung rumus dynamic-array sama sekali, dan rumusnya
  tetap hidup (kalau nilai sumber berubah, hasil ikut berubah). Sheet
  `_IMPORT` kembali dipakai (55 sheet total: 54 asli + 1 data).
- **Perbaikan PivotTable external reference.** Pivot yang sumbernya
  dideklarasikan sebagai workbook eksternal ("in.xlsx", artefak export
  Google) diperbaiki: relasi externalLinkPath dihapus, sumber dijadikan
  sheet lokal, refresh otomatis saat dibuka dimatikan supaya tidak muncul
  error Data Refresh Failed di Excel Online.
- **Perbaikan rumus #REF!.** Rumus yang referensinya hilang saat export
  diperbaiki dengan menyalin referensi dari rumus yang polanya sama di
  sheet yang sama; yang tidak punya donor dilaporkan, bukan ditebak.
- **Pembatasan referensi kolom penuh.** Referensi kolom penuh (mis.
  `$H:$H`) dibatasi ke baris terakhir data supaya tidak memicu peringatan
  SLOW WORKBOOK di Excel Online. Nilai cache asli rumus yang dibatasi
  dipertahankan (termasuk cache string kosong), jadi Excel tidak perlu
  menghitung ulang semua rumus itu saat file dibuka; rumus hasil repair
  #REF! sengaja ditulis tanpa cache karena nilainya berubah.
- **Jendela unduh dihitung dari selesai.** Hasil convert bisa diunduh 10
  menit penuh sesudah convert selesai; sebelumnya batas 10 menit dihitung
  dari job dibuat, sehingga file besar yang convert-nya di atas 10 menit
  langsung terhapus begitu selesai.
- Perbaikan v1.2, v1.3, dan v1.4 tetap dipertahankan (lihat bawah).

## Perubahan v1.5 (DITARIK)

- **Mode beku. DITARIK user 2026-11-07 karena melanggar aturan keras.**
  Jangan dipakai. Lihat v1.6 untuk pendekatan penggantinya.

## Build dari source

Butuh Go 1.21+.

```sh
go run .                                 # langsung jalan
go build -o sheetconv .                  # Linux / macOS
GOOS=windows go build -o sheetconv.exe . # Windows
```

## Perubahan v1.5

- **Pendekatan baru: mode beku.** Rumus hasil convert v1.0-v1.4 (QUERY jadi
  `FILTER(VSTACK(...))` hidup dan IMPORTRANGE jadi rumus spill ke sheet
  `_IMPORT`) ternyata TETAP ditolak Excel Online ("Couldn't Open the
  Workbook") padahal file yang sama bisa dibuka di WPS, dan menulis nilai
  cache untuk rumusnya (v1.4) tidak mengubah hasil. Karena itu sejak v1.5
  bagian Google-only dibekukan jadi nilai: sel IMPORTRANGE/QUERY dan sel
  spill-nya diganti nilai terakhir dari export. File hasil convert TIDAK
  mengandung rumus dynamic-array sama sekali, TIDAK ada sheet tambahan
  (jumlah sheet sama persis seperti aslinya, 54), dan TIDAK perlu mengunduh
  spreadsheet sumber saat convert (convert jadi jauh lebih cepat). Rumus
  Excel native (IF, VLOOKUP, SUMIFS, dan lain-lain) tetap hidup sebagai
  rumus. Konsekuensi: data impor tidak berubah sendiri kalau sumber Google
  berubah atau tab lokal diedit; untuk memperbarui, jalankan converter lagi.
  Kode mode live (rumus dynamic-array + sheet `_IMPORT`) masih ada di
  `converter.go` (`resolveAnchors`) tapi tidak dipakai.
- Perbaikan v1.2, v1.3, dan v1.4 tetap dipertahankan (lihat bawah).

## Perubahan v1.4

- **Rumus hasil convert sekarang ditulis dengan nilai cache.** Sebelumnya
  rumus QUERY dan IMPORTRANGE ditulis tanpa nilai cache, sehingga Excel
  Online menghitung ulang rumus-rumus berat itu saat membuka file dan
  menolak membuka workbook ("Couldn't Open the Workbook") meskipun
  `fullCalcOnLoad` sudah dihapus. Sekarang tiap rumus hasil convert membawa
  nilai cache dari export aslinya, jadi file dibuka dengan nilai terakhir
  seperti file aslinya. Ini juga memperbaiki tampilan di WPS Office: rumus
  yang tadinya dihitung ulang saat dibuka dan menampilkan 0 / 00-Jan-1900 /
  #VALUE! sekarang menampilkan nilai cache yang benar. (Catatan: rumus yang
  merujuk sel kosong, mis. `=R72`, di Google Sheets tampil kosong tapi di
  Excel tampil 0 / 00-Jan-1900 kalau dihitung ulang. Selama file dibuka
  dengan nilai cache, tampilannya tetap kosong seperti aslinya.)
- Perbaikan v1.2 dan v1.3 tetap dipertahankan (lihat bawah).

## Perubahan v1.3

- **Semua data impor numpuk di 1 sheet tersembunyi (`_IMPORT`).** Sebelumnya
  tiap IMPORTRANGE dibuatkan tab sendiri (`_IMPORT_1` sampai `_IMPORT_23`)
  sehingga file 54 sheet jadi 77 sheet. Sekarang blok-blok impor ditumpuk
  vertikal di satu sheet `_IMPORT` (tersembunyi): total 55 sheet (54 asli +
  1 data), bar tab tetap 54 seperti aslinya. Panel hasil convert menjelaskan
  sheet tambahan ini.
- **Format angka, lebar kolom, dan tab tersembunyi** dari v1.2 tetap
  dipertahankan (lihat bawah).

## Perubahan v1.2

- **Format angka tab impor dipetakan dengan benar.** Sebelumnya indeks style
  sumber disalin mentah sehingga angka jam 6.8 tampil jadi 680.00%.
  Sekarang format angka sumber (persen, tanggal, desimal) dicari padanannya
  di workbook utama.
- **Lebar kolom sumber ikut tersalin** ke tab impor, jadi tidak ada lagi
  kolom `######` atau angka yang berubah jadi notasi ilmiah.
- **Tab impor disembunyikan** (hidden) supaya bar tab tetap rapi; bisa
  dimunculkan lagi lewat Unhide.
- **ID relasi (rId) tab impor tidak lagi tabrakan** dengan pivotCache /
  slicerCache. Sebelumnya 8 tab impor pertama bisa terbaca kosong di
  beberapa pembaca.
- **Range kolom polos (mis. `B:C`) tidak lagi tergeser satu baris.** Sebelumnya
  baris pertama tab impor kosong dan seluruh isi turun satu baris.

## Struktur project

```
main.go              entry point, load katalog + template, jalan di :2030
formulas.json        katalog fungsi + pemetaan (bisa diedit)
template/index.html  halaman utama (1 halaman)
static/style.css     tampilan putih-biru
engine/              katalog, tokenizer, rewrite rumus, QUERY, IMPORTRANGE
xlsx/                baca/tulis file .xlsx lewat edit XML (pivot tetap utuh)
converter/           orkestrasi convert + laporan
web/                 server HTTP (Echo), job di memori, auto-hapus
```
