// Styles: baca dan tulis xl/styles.xml.
//
// Dipakai untuk SATU hal: memetakan format angka (numFmt) dari workbook
// SUMBER ke workbook UTAMA saat membuat tab impor.
//
// Latar belakang bug: sel impor dulu menyalin indeks style (atribut `s`)
// mentah dari workbook sumber. Indeks style itu per-workbook: di workbook
// sumber, numFmtId 164 bisa berarti format angka `#`, sedangkan di workbook
// utama 164 berarti format tanggal. Akibatnya angka biasa tampil sebagai
// persen (6.8 -> 680.00%) atau tanggal. Di sini yang disalin BUKAN indeksnya,
// melainkan numFmt-nya: numFmtId + formatCode dicari/dibuatkan xf yang
// setara di workbook utama.
package xlsx

import (
	"regexp"
	"strconv"
	"strings"
)

// xfAttr satu entri <xf> di <cellXfs>.
type xfAttr struct {
	NumFmtID int
	FontID   int
	FillID   int
	BorderID int
}

// styles isi xl/styles.xml yang relevan.
type styles struct {
	// NumFmts: numFmtId kustom (>=164) -> formatCode.
	NumFmts map[int]string
	// CellXfs: satu entri per <xf> di <cellXfs>.
	CellXfs []xfAttr
}

var (
	numFmtRe  = regexp.MustCompile(`<numFmt[^>]*>`)
	cellXfsRe = regexp.MustCompile(`(?s)<cellXfs[^>]*>(.*?)</cellXfs>`)
	xfRe      = regexp.MustCompile(`<xf[^>]*>`)
)

// parseStyles baca xl/styles.xml kalau ada. Gagal parse -> styles kosong
// (bukan error fatal: pemanggil jatuh ke General).
func (wb *Workbook) parseStyles() {
	raw, ok := wb.parts["xl/styles.xml"]
	if !ok {
		return
	}
	st := &styles{NumFmts: make(map[int]string)}
	s := string(raw)
	for _, m := range numFmtRe.FindAllString(s, -1) {
		a := parseAttrs(m)
		id, err := strconv.Atoi(a["numFmtId"])
		if err != nil {
			continue
		}
		st.NumFmts[id] = a["formatCode"]
	}
	if m := cellXfsRe.FindStringSubmatch(s); m != nil {
		for _, x := range xfRe.FindAllString(m[1], -1) {
			a := parseAttrs(x)
			numFmt, _ := strconv.Atoi(a["numFmtId"])
			font, _ := strconv.Atoi(a["fontId"])
			fill, _ := strconv.Atoi(a["fillId"])
			border, _ := strconv.Atoi(a["borderId"])
			st.CellXfs = append(st.CellXfs, xfAttr{NumFmtID: numFmt, FontID: font, FillID: fill, BorderID: border})
		}
	}
	wb.styles = st
}

// NumFmtForStyle kembalikan (numFmtId, formatCode) untuk indeks style.
// numFmtId 0 = General (formatCode kosong). numFmtId < 164 = format bawaan
// Excel (tidak butuh formatCode). numFmtId >= 164 = format kustom.
func (wb *Workbook) NumFmtForStyle(styleIdx int) (int, string) {
	if wb.styles == nil || styleIdx < 0 || styleIdx >= len(wb.styles.CellXfs) {
		return 0, ""
	}
	id := wb.styles.CellXfs[styleIdx].NumFmtID
	if id < 164 {
		return id, ""
	}
	return id, wb.styles.NumFmts[id]
}

// EnsureNumFmtStyle pastikan workbook utama punya xf dengan numFmt yang
// diminta; kembalikan indeks xf-nya, atau -1 kalau tidak bisa (pakai General).
// xf yang dibuat/dipakai polos (font/fill/border default), hanya numFmt yang
// dibawa dari sumber, supaya tidak ada format nyasar dari workbook lain.
func (wb *Workbook) EnsureNumFmtStyle(numFmtID int, code string) int {
	if numFmtID == 0 {
		return -1
	}
	if _, ok := wb.parts["xl/styles.xml"]; !ok || wb.styles == nil {
		return -1
	}
	effectiveID := numFmtID
	if numFmtID >= 164 {
		if existing, has := wb.styles.NumFmts[numFmtID]; has && existing == code {
			// Id sudah ada dengan formatCode yang sama: pakai.
		} else if !has {
			// Id belum dipakai: tambahkan definisinya.
			if !wb.addNumFmt(numFmtID, code) {
				return -1
			}
		} else {
			// Id dipakai format lain: alokasikan id baru.
			newID := 164
			for _, id := range wb.styles.numFmtIDs() {
				if id >= newID {
					newID = id + 1
				}
			}
			if !wb.addNumFmt(newID, code) {
				return -1
			}
			effectiveID = newID
		}
	}
	// Cari xf polos yang numFmt-nya cocok.
	for i, x := range wb.styles.CellXfs {
		if x.NumFmtID == effectiveID && x.FontID == 0 && x.FillID == 0 && x.BorderID == 0 {
			return i
		}
	}
	// Tambahkan xf baru di akhir <cellXfs>.
	s := string(wb.parts["xl/styles.xml"])
	idx := strings.Index(s, "</cellXfs>")
	if idx < 0 {
		return -1
	}
	xfTag := `<xf numFmtId="` + strconv.Itoa(effectiveID) + `" fontId="0" fillId="0" borderId="0" xfId="0" applyNumberFormat="1"/>`
	s = s[:idx] + xfTag + s[idx:]
	s = bumpCountAttr(s, "cellXfs")
	wb.parts["xl/styles.xml"] = []byte(s)
	wb.styles.CellXfs = append(wb.styles.CellXfs, xfAttr{NumFmtID: effectiveID})
	return len(wb.styles.CellXfs) - 1
}

// numFmtIDs daftar semua id di <numFmts>.
func (st *styles) numFmtIDs() []int {
	ids := make([]int, 0, len(st.NumFmts))
	for id := range st.NumFmts {
		ids = append(ids, id)
	}
	return ids
}

// addNumFmt tambahkan <numFmt> ke xl/styles.xml (buat <numFmts> kalau belum
// ada). Kembalikan false kalau gagal.
func (wb *Workbook) addNumFmt(id int, code string) bool {
	s := string(wb.parts["xl/styles.xml"])
	tag := `<numFmt numFmtId="` + strconv.Itoa(id) + `" formatCode="` + xmlEscape(code) + `"/>`
	if strings.Contains(s, "</numFmts>") {
		s = strings.Replace(s, "</numFmts>", tag+"</numFmts>", 1)
		s = bumpCountAttr(s, "numFmts")
	} else {
		// Sisipkan <numFmts> tepat sesudah tag pembuka <styleSheet ...>.
		end := strings.Index(s, ">")
		if end < 0 {
			return false
		}
		s = s[:end+1] + `<numFmts count="1">` + tag + `</numFmts>` + s[end+1:]
	}
	wb.parts["xl/styles.xml"] = []byte(s)
	if wb.styles.NumFmts == nil {
		wb.styles.NumFmts = make(map[int]string)
	}
	wb.styles.NumFmts[id] = code
	return true
}

// bumpCountAttr naikkan count="N" pada elemen <name ...> sebanyak 1.
func bumpCountAttr(s, name string) string {
	re := regexp.MustCompile(`<` + name + `[^>]*count="(\d+)"`)
	loc := re.FindStringSubmatchIndex(s)
	if loc == nil {
		return s
	}
	n, err := strconv.Atoi(s[loc[2]:loc[3]])
	if err != nil {
		return s
	}
	return s[:loc[2]] + strconv.Itoa(n+1) + s[loc[3]:]
}

// ColWidths baca lebar kolom dari <cols> di XML satu sheet, untuk kolom
// minCol..maxCol. Hasil: lebar per kolom (string apa adanya dari XML,
// "" kalau kolom itu tidak punya lebar eksplisit). Elemen <col> yang
// muncul belakangan menimpa yang lebih awal untuk kolom yang sama.
func ColWidths(sheetXML string, minCol, maxCol int) []string {
	out := make([]string, maxCol-minCol+1)
	m := regexp.MustCompile(`(?s)<cols>(.*?)</cols>`).FindStringSubmatch(sheetXML)
	if m == nil {
		return out
	}
	for _, c := range regexp.MustCompile(`<col[^>]*/?>`).FindAllString(m[1], -1) {
		a := parseAttrs(c)
		mn, err1 := strconv.Atoi(a["min"])
		mx, err2 := strconv.Atoi(a["max"])
		if err1 != nil || err2 != nil || a["width"] == "" {
			continue
		}
		for col := mn; col <= mx; col++ {
			if col >= minCol && col <= maxCol {
				out[col-minCol] = a["width"]
			}
		}
	}
	return out
}
