// Package xlsx: baca/tulis file .xlsx lewat operasi ZIP+XML langsung (tanpa
// library spreadsheet), supaya pivot table, Excel table, chart, drawing,
// conditional formatting, dan semua bagian lain file asli tetap utuh.
// Yang diubah hanya isi sel yang memang perlu di-convert.
package xlsx

import (
	"archive/zip"
	"bytes"
	"fmt"
	"regexp"
	"sort"
	"strconv"
	"strings"
)

// Workbook satu file .xlsx di memori (tidak pernah ditulis ke disk).
type Workbook struct {
	parts map[string][]byte
	order []string
	Sheets []*Sheet
	// SharedStrings isi xl/sharedStrings.xml (nil kalau tidak ada).
	SharedStrings []string
	// styles isi xl/styles.xml (nil kalau tidak ada).
	styles *styles
}

// Sheet satu tab.
type Sheet struct {
	Name    string
	SheetID int
	RelID   string
	File    string // mis. xl/worksheets/sheet49.xml
}

// Open baca file .xlsx dari bytes.
func Open(data []byte) (*Workbook, error) {
	zr, err := zip.NewReader(bytes.NewReader(data), int64(len(data)))
	if err != nil {
		return nil, fmt.Errorf("bukan file xlsx yang valid: %w", err)
	}
	wb := &Workbook{parts: make(map[string][]byte)}
	for _, f := range zr.File {
		rc, err := f.Open()
		if err != nil {
			return nil, err
		}
		var buf bytes.Buffer
		if _, err := buf.ReadFrom(rc); err != nil {
			rc.Close()
			return nil, err
		}
		rc.Close()
		wb.parts[f.Name] = buf.Bytes()
		wb.order = append(wb.order, f.Name)
	}
	if err := wb.parseWorkbook(); err != nil {
		return nil, err
	}
	if err := wb.parseSharedStrings(); err != nil {
		return nil, err
	}
	wb.parseStyles()
	return wb, nil
}

var attrRe = regexp.MustCompile(`([\w:.]+)="([^"]*)"`)

func parseAttrs(tag string) map[string]string {
	m := make(map[string]string)
	for _, g := range attrRe.FindAllStringSubmatch(tag, -1) {
		m[g[1]] = xmlUnescape(g[2])
	}
	return m
}

func (wb *Workbook) parseWorkbook() error {
	raw, ok := wb.parts["xl/workbook.xml"]
	if !ok {
		return fmt.Errorf("xl/workbook.xml tidak ditemukan")
	}
	// rels: rId -> Target
	relsRaw, ok := wb.parts["xl/_rels/workbook.xml.rels"]
	if !ok {
		return fmt.Errorf("xl/_rels/workbook.xml.rels tidak ditemukan")
	}
	relMap := make(map[string]string)
	for _, m := range regexp.MustCompile(`<Relationship[^>]*/?>`).FindAllString(string(relsRaw), -1) {
		a := parseAttrs(m)
		if a["Id"] != "" && a["Target"] != "" {
			t := a["Target"]
			t = strings.TrimPrefix(t, "/")
			if !strings.HasPrefix(t, "xl/") {
				t = "xl/" + t
			}
			relMap[a["Id"]] = t
		}
	}
	s := string(raw)
	for _, m := range regexp.MustCompile(`<sheet[^>]*/?>`).FindAllString(s, -1) {
		a := parseAttrs(m)
		name := a["name"]
		rid := a["r:id"]
		if name == "" || rid == "" {
			continue
		}
		sid, _ := strconv.Atoi(a["sheetId"])
		file, ok := relMap[rid]
		if !ok {
			continue
		}
		wb.Sheets = append(wb.Sheets, &Sheet{Name: name, SheetID: sid, RelID: rid, File: file})
	}
	if len(wb.Sheets) == 0 {
		return fmt.Errorf("tidak ada sheet di workbook")
	}
	return nil
}

func (wb *Workbook) parseSharedStrings() error {
	raw, ok := wb.parts["xl/sharedStrings.xml"]
	if !ok {
		return nil
	}
	s := string(raw)
	// Tiap <si>...</si> jadi satu string (gabungan semua <t> di dalamnya).
	for _, m := range regexp.MustCompile(`(?s)<si>(.*?)</si>`).FindAllStringSubmatch(s, -1) {
		var b strings.Builder
		for _, t := range regexp.MustCompile(`(?s)<t[^>]*>(.*?)</t>`).FindAllStringSubmatch(m[1], -1) {
			b.WriteString(xmlUnescape(t[1]))
		}
		wb.SharedStrings = append(wb.SharedStrings, b.String())
	}
	return nil
}

// SheetByName cari sheet berdasarkan nama persis.
func (wb *Workbook) SheetByName(name string) *Sheet {
	for _, s := range wb.Sheets {
		if s.Name == name {
			return s
		}
	}
	return nil
}

// FindSheetNormalized cari sheet berdasarkan nama yang dinormalisasi
// (dipakai untuk nama tab lama ber-slash, mis. LKPTA/LKCPA -> LKPTALKCPA).
// normalize adalah fungsi normalisasi dari engine (dioper sebagai argumen
// supaya package xlsx tidak bergantung ke engine).
func (wb *Workbook) FindSheetNormalized(norm string, normalize func(string) string) *Sheet {
	for _, s := range wb.Sheets {
		if normalize(s.Name) == norm {
			return s
		}
	}
	return nil
}

// SheetXML isi mentah XML satu sheet.
func (wb *Workbook) SheetXML(sh *Sheet) (string, bool) {
	b, ok := wb.parts[sh.File]
	return string(b), ok
}

// SetSheetXML ganti isi XML satu sheet.
func (wb *Workbook) SetSheetXML(sh *Sheet, xml string) {
	wb.parts[sh.File] = []byte(xml)
}

// HasPart true kalau part ada di file.
func (wb *Workbook) HasPart(name string) bool {
	_, ok := wb.parts[name]
	return ok
}

// Part isi mentah satu part (nil kalau tidak ada).
func (wb *Workbook) Part(name string) ([]byte, bool) {
	b, ok := wb.parts[name]
	return b, ok
}

// SetPart ganti isi satu part yang sudah ada.
func (wb *Workbook) SetPart(name string, data []byte) {
	if _, ok := wb.parts[name]; ok {
		wb.parts[name] = data
	}
}

// RemoveCalcChain hapus xl/calcChain.xml (Excel membangun ulang saat dibuka).
func (wb *Workbook) RemoveCalcChain() {
	if !wb.HasPart("xl/calcChain.xml") {
		return
	}
	delete(wb.parts, "xl/calcChain.xml")
	for i, p := range wb.order {
		if p == "xl/calcChain.xml" {
			wb.order = append(wb.order[:i], wb.order[i+1:]...)
			break
		}
	}
	ct := string(wb.parts["[Content_Types].xml"])
	re := regexp.MustCompile(`<Override[^>]*PartName="/xl/calcChain\.xml"[^>]*/>`)
	wb.parts["[Content_Types].xml"] = []byte(re.ReplaceAllString(ct, ""))
}

// SetFullCalcOnLoad tandai workbook supaya Excel menghitung ulang semua rumus
// saat file dibuka (nilai cache lama diabaikan).
func (wb *Workbook) SetFullCalcOnLoad() {
	raw, ok := wb.parts["xl/workbook.xml"]
	if !ok {
		return
	}
	s := string(raw)
	re := regexp.MustCompile(`<calcPr[^>]*/>`)
	if loc := re.FindStringIndex(s); loc != nil {
		tag := s[loc[0]:loc[1]]
		if strings.Contains(tag, "fullCalcOnLoad") {
			tag = regexp.MustCompile(`fullCalcOnLoad="[^"]*"`).ReplaceAllString(tag, `fullCalcOnLoad="1"`)
		} else {
			tag = strings.Replace(tag, "/>", ` fullCalcOnLoad="1"/>`, 1)
		}
		s = s[:loc[0]] + tag + s[loc[1]:]
	} else if strings.Contains(s, "<calcPr") {
		// <calcPr>...</calcPr> berpasangan
		re2 := regexp.MustCompile(`<calcPr([^>]*)>`)
		s = re2.ReplaceAllString(s, `<calcPr$1 fullCalcOnLoad="1">`)
	} else {
		s = strings.Replace(s, "</workbook>", `<calcPr fullCalcOnLoad="1"/></workbook>`, 1)
	}
	wb.parts["xl/workbook.xml"] = []byte(s)
}

// AddSheet tambah sheet baru (untuk tab impor). Mengembalikan sheet baru.
func (wb *Workbook) AddSheet(name, sheetXML string) (*Sheet, error) {
	// Nomor file sheet baru.
	maxFile := 0
	reNum := regexp.MustCompile(`^xl/worksheets/sheet(\d+)\.xml$`)
	for _, p := range wb.order {
		if m := reNum.FindStringSubmatch(p); m != nil {
			if n, err := strconv.Atoi(m[1]); err == nil && n > maxFile {
				maxFile = n
			}
		}
	}
	// rId dan sheetId baru.
	// PENTING: rId harus unik di SELURUH workbook.xml.rels, bukan cuma di
	// antara sheet. File ini punya relasi non-sheet (theme, styles,
	// sharedStrings, pivotCache, slicerCache) yang juga memakai rId — dulu
	// maxRid hanya dihitung dari sheet sehingga tab impor baru dapat
	// rId59..rId66 yang tabrakan dengan pivotCache/slicerCache, dan
	// pembaca yang memakai kemunculan pertama (mis. openpyxl) mengira tab
	// impor itu file pivotCache (kosong).
	maxRid, maxSid := 0, 0
	reRid := regexp.MustCompile(`^rId(\d+)$`)
	for _, s := range wb.Sheets {
		if s.SheetID > maxSid {
			maxSid = s.SheetID
		}
	}
	if relsRaw, ok := wb.parts["xl/_rels/workbook.xml.rels"]; ok {
		for _, m := range regexp.MustCompile(`Id="(rId\d+)"`).FindAllStringSubmatch(string(relsRaw), -1) {
			if g := reRid.FindStringSubmatch(m[1]); g != nil {
				if n, err := strconv.Atoi(g[1]); err == nil && n > maxRid {
					maxRid = n
				}
			}
		}
	}
	newFile := fmt.Sprintf("xl/worksheets/sheet%d.xml", maxFile+1)
	newRid := fmt.Sprintf("rId%d", maxRid+1)
	newSid := maxSid + 1

	wb.parts[newFile] = []byte(sheetXML)
	wb.order = append(wb.order, newFile)

	// workbook.xml: tambah <sheet .../> sebelum </sheets>. Tab impor
	// disembunyikan (state="hidden") supaya tidak memenuhi bar tab: datanya
	// tetap dipakai rumus, dan bisa dimunculkan lagi lewat Unhide.
	raw := string(wb.parts["xl/workbook.xml"])
	sheetTag := fmt.Sprintf(`<sheet name="%s" sheetId="%d" state="hidden" r:id="%s"/>`, xmlEscape(name), newSid, newRid)
	if strings.Contains(raw, "</sheets>") {
		raw = strings.Replace(raw, "</sheets>", sheetTag+"</sheets>", 1)
	} else {
		return nil, fmt.Errorf("workbook.xml tidak punya </sheets>")
	}
	wb.parts["xl/workbook.xml"] = []byte(raw)

	// workbook.xml.rels: tambah Relationship
	rels := string(wb.parts["xl/_rels/workbook.xml.rels"])
	relTag := fmt.Sprintf(`<Relationship Id="%s" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/worksheet" Target="worksheets/sheet%d.xml"/>`, newRid, maxFile+1)
	if strings.Contains(rels, "</Relationships>") {
		rels = strings.Replace(rels, "</Relationships>", relTag+"</Relationships>", 1)
	} else {
		return nil, fmt.Errorf("workbook.xml.rels tidak punya </Relationships>")
	}
	wb.parts["xl/_rels/workbook.xml.rels"] = []byte(rels)

	// [Content_Types].xml: tambah Override
	ct := string(wb.parts["[Content_Types].xml"])
	ctTag := fmt.Sprintf(`<Override PartName="/xl/worksheets/sheet%d.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.worksheet+xml"/>`, maxFile+1)
	if strings.Contains(ct, "</Types>") {
		ct = strings.Replace(ct, "</Types>", ctTag+"</Types>", 1)
	} else {
		return nil, fmt.Errorf("[Content_Types].xml tidak punya </Types>")
	}
	wb.parts["[Content_Types].xml"] = []byte(ct)

	sh := &Sheet{Name: name, SheetID: newSid, RelID: newRid, File: newFile}
	wb.Sheets = append(wb.Sheets, sh)
	return sh, nil
}

// Bytes serialisasi workbook jadi file .xlsx (ZIP).
func (wb *Workbook) Bytes() ([]byte, error) {
	var buf bytes.Buffer
	zw := zip.NewWriter(&buf)
	for _, name := range wb.order {
		data, ok := wb.parts[name]
		if !ok {
			continue
		}
		hdr := &zip.FileHeader{Name: name, Method: zip.Deflate}
		w, err := zw.CreateHeader(hdr)
		if err != nil {
			return nil, err
		}
		if _, err := w.Write(data); err != nil {
			return nil, err
		}
	}
	if err := zw.Close(); err != nil {
		return nil, err
	}
	return buf.Bytes(), nil
}

// SortedPartNames daftar part terurut (untuk debug/laporan).
func (wb *Workbook) SortedPartNames() []string {
	out := append([]string(nil), wb.order...)
	sort.Strings(out)
	return out
}

// xmlEscape escape lima karakter XML untuk atribut/teks.
func xmlEscape(s string) string {
	r := strings.NewReplacer(
		`&`, "&amp;",
		`<`, "&lt;",
		`>`, "&gt;",
		`"`, "&quot;",
		`'`, "&apos;",
	)
	return r.Replace(s)
}

// xmlUnescape kebalikan xmlEscape, termasuk referensi numerik.
func xmlUnescape(s string) string {
	if !strings.Contains(s, "&") {
		return s
	}
	r := strings.NewReplacer(
		"&amp;", "&",
		"&lt;", "<",
		"&gt;", ">",
		"&quot;", `"`,
		"&apos;", "'",
	)
	s = r.Replace(s)
	// Referensi numerik &#NN; dan &#xNN;
	s = regexp.MustCompile(`&#(\d+);`).ReplaceAllStringFunc(s, func(m string) string {
		n, _ := strconv.Atoi(m[2 : len(m)-1])
		return string(rune(n))
	})
	s = regexp.MustCompile(`&#[xX]([0-9a-fA-F]+);`).ReplaceAllStringFunc(s, func(m string) string {
		n, _ := strconv.ParseInt(m[3:len(m)-1], 16, 32)
		return string(rune(n))
	})
	return s
}
