package xlsx

import (
	"fmt"
	"regexp"
	"sort"
	"strconv"
	"strings"
)

// Cell satu sel dalam sheet.
type Cell struct {
	Ref        string
	Formula    string // rumus yang sudah di-expand (tanpa '='), "" kalau bukan rumus
	IsFormula  bool
	IsShared   bool // <f t="shared">
	IsMaster   bool // <f t="shared"> yang punya teks rumus
	SharedSI   string
	MasterRef  string // untuk shared member: sel master
	Value      string // nilai ter-resolve (teks / angka / bool)
	RawValue   string // isi <v> mentah
	HasValue   bool   // ada elemen <v> (walau kosong: <v></v> = hasil string kosong)
	Type       string // atribut t: s, str, e, b, inlineStr, ""
	Style      int    // atribut s, -1 kalau tidak ada
}

var (
	cellRe = regexp.MustCompile(`(?s)<c(\s[^>]*?)?(?:/>|>(.*?)</c>)`)
	fRe    = regexp.MustCompile(`(?s)<f(\s[^>]*?)?(?:/>|>(.*?)</f>)`)
	vRe    = regexp.MustCompile(`(?s)<v>(.*?)</v>`)
	isRe   = regexp.MustCompile(`(?s)<is>(.*?)</is>`)
	tRe    = regexp.MustCompile(`(?s)<t[^>]*>(.*?)</t>`)
)

// ReadCells baca semua sel dalam sheet (hanya bagian <sheetData>).
// Rumus shared (t="shared") di-expand ke tiap sel anggota dengan
// pergeseran referensi relatif.
func (wb *Workbook) ReadCells(sh *Sheet) (map[string]*Cell, error) {
	xml, ok := wb.SheetXML(sh)
	if !ok {
		return nil, fmt.Errorf("sheet %s tidak ditemukan", sh.Name)
	}
	start := strings.Index(xml, "<sheetData")
	if start < 0 {
		return map[string]*Cell{}, nil
	}
	end := strings.Index(xml[start:], "</sheetData>")
	var data string
	if end < 0 {
		data = xml[start:]
	} else {
		data = xml[start : start+end]
	}
	cells := make(map[string]*Cell)
	for _, m := range cellRe.FindAllStringSubmatch(data, -1) {
		attrs := parseAttrs("<c" + m[1] + ">")
		ref := attrs["r"]
		if ref == "" {
			continue
		}
		c := &Cell{Ref: ref, Type: attrs["t"], Style: -1}
		if s, ok := attrs["s"]; ok {
			if n, err := strconv.Atoi(s); err == nil {
				c.Style = n
			}
		}
		inner := m[2]
		if inner != "" {
			if fm := fRe.FindStringSubmatch(inner); fm != nil {
				fAttrs := parseAttrs("<f" + fm[1] + ">")
				fText := xmlUnescape(fm[2])
				c.IsFormula = true
				if fAttrs["t"] == "shared" {
					c.IsShared = true
					c.SharedSI = fAttrs["si"]
					if fText != "" {
						c.IsMaster = true
						c.Formula = fText
					}
				} else {
					c.Formula = fText
				}
			}
			if vm := vRe.FindStringSubmatch(inner); vm != nil {
				c.RawValue = xmlUnescape(vm[1])
				c.HasValue = true
			}
			if im := isRe.FindStringSubmatch(inner); im != nil {
				var b strings.Builder
				for _, t := range tRe.FindAllStringSubmatch(im[1], -1) {
					b.WriteString(xmlUnescape(t[1]))
				}
				c.Value = b.String()
			}
		}
		// Resolve nilai.
		switch c.Type {
		case "s":
			if idx, err := strconv.Atoi(c.RawValue); err == nil && idx >= 0 && idx < len(wb.SharedStrings) {
				c.Value = wb.SharedStrings[idx]
			}
		case "inlineStr":
			// Value sudah diisi dari <is>.
		default:
			if c.Value == "" {
				c.Value = c.RawValue
			}
		}
		cells[ref] = c
	}
	// Expand shared formulas.
	masters := make(map[string]*Cell)
	for _, c := range cells {
		if c.IsMaster {
			masters[c.SharedSI] = c
		}
	}
	for _, c := range cells {
		if c.IsShared && !c.IsMaster {
			if m, ok := masters[c.SharedSI]; ok {
				c.MasterRef = m.Ref
				dRow, dCol := refDiff(c.Ref, m.Ref)
				c.Formula = TranslateRefs(m.Formula, dRow, dCol)
			}
		}
	}
	return cells, nil
}

// MaxRow baris terbesar yang punya sel (0 kalau kosong).
func MaxRow(cells map[string]*Cell) int {
	max := 0
	for ref := range cells {
		_, row := splitRef(ref)
		if row > max {
			max = row
		}
	}
	return max
}

// MaxCol kolom terbesar yang punya sel (0 kalau kosong).
func MaxCol(cells map[string]*Cell) int {
	max := 0
	for ref := range cells {
		col, _ := splitRef(ref)
		if col > max {
			max = col
		}
	}
	return max
}

// splitRef pisah "AB123" jadi (kolom angka, baris). A=1.
// Referensi absolut ($AB$123) diperlakukan sama seperti AB123.
func splitRef(ref string) (col, row int) {
	ref = strings.ReplaceAll(ref, "$", "")
	i := 0
	for i < len(ref) && ((ref[i] >= 'A' && ref[i] <= 'Z') || (ref[i] >= 'a' && ref[i] <= 'z')) {
		i++
	}
	for _, ch := range ref[:i] {
		var v int
		if ch >= 'a' {
			v = int(ch - 'a' + 1)
		} else {
			v = int(ch - 'A' + 1)
		}
		col = col*26 + v
	}
	row, _ = strconv.Atoi(ref[i:])
	return col, row
}

// ColLetters ubah angka kolom jadi huruf (1=A, 27=AA).
func ColLetters(col int) string {
	var b []byte
	for col > 0 {
		col--
		b = append([]byte{byte('A' + col%26)}, b...)
		col /= 26
	}
	return string(b)
}

// CellRef buat referensi "A1" dari kolom dan baris.
func CellRef(col, row int) string {
	return ColLetters(col) + strconv.Itoa(row)
}

// refDiff selisih (baris, kolom) antara dua ref.
func refDiff(ref, base string) (dRow, dCol int) {
	c1, r1 := splitRef(ref)
	c2, r2 := splitRef(base)
	return r1 - r2, c1 - c2
}

// TranslateRefs geser referensi relatif A1 dalam rumus sebanyak dRow/dCol.
// Referensi absolut ($A$1, $A1, A$1) tidak digeser pada sumbu yang di-$.
// Nama fungsi, string literal, dan nama sheet berpetik tidak disentuh.
func TranslateRefs(formula string, dRow, dCol int) string {
	if dRow == 0 && dCol == 0 {
		return formula
	}
	var b strings.Builder
	n := len(formula)
	i := 0
	for i < n {
		c := formula[i]
		if c == '"' {
			j := i + 1
			for j < n {
				if formula[j] == '"' {
					if j+1 < n && formula[j+1] == '"' {
						j += 2
						continue
					}
					j++
					break
				}
				j++
			}
			b.WriteString(formula[i:j])
			i = j
			continue
		}
		if c == '\'' {
			j := i + 1
			for j < n {
				if formula[j] == '\'' {
					if j+1 < n && formula[j+1] == '\'' {
						j += 2
						continue
					}
					j++
					break
				}
				j++
			}
			b.WriteString(formula[i:j])
			i = j
			continue
		}
		// Coba baca referensi di posisi i.
		if ref, end, ok := readRefAt(formula, i); ok {
			b.WriteString(shiftRef(ref, dRow, dCol))
			i = end
			continue
		}
		b.WriteByte(c)
		i++
	}
	return b.String()
}

// readRefAt baca referensi A1 di posisi i (opsional $ di depan kolom/baris).
// Mengembalikan teks ref asli, indeks akhir, dan ok.
func readRefAt(s string, i int) (string, int, bool) {
	n := len(s)
	// Karakter sebelum harus bukan huruf/angka/_/./$ (bukan bagian identifier).
	if i > 0 {
		p := s[i-1]
		if (p >= 'A' && p <= 'Z') || (p >= 'a' && p <= 'z') || (p >= '0' && p <= '9') || p == '_' || p == '.' || p == '$' {
			return "", 0, false
		}
	}
	j := i
	if j < n && s[j] == '$' {
		j++
	}
	colStart := j
	for j < n && ((s[j] >= 'A' && s[j] <= 'Z') || (s[j] >= 'a' && s[j] <= 'z')) {
		j++
	}
	colLen := j - colStart
	if colLen < 1 || colLen > 3 {
		return "", 0, false
	}
	if j < n && s[j] == '$' {
		j++
	}
	rowStart := j
	for j < n && s[j] >= '0' && s[j] <= '9' {
		j++
	}
	if rowStart == j {
		return "", 0, false
	}
	// Sesudahnya tidak boleh '(' (itu nama fungsi) atau huruf/angka/_/.
	if j < n {
		nc := s[j]
		if nc == '(' || (nc >= 'A' && nc <= 'Z') || (nc >= 'a' && nc <= 'z') || (nc >= '0' && nc <= '9') || nc == '_' || nc == '.' {
			return "", 0, false
		}
	}
	// Validasi batas Excel.
	colNum := 0
	for k := colStart; k < colStart+colLen; k++ {
		ch := s[k]
		if ch >= 'a' {
			ch -= 'a' - 'A'
		}
		colNum = colNum*26 + int(ch-'A'+1)
	}
	rowNum, _ := strconv.Atoi(s[rowStart:j])
	if colNum < 1 || colNum > 16384 || rowNum < 1 || rowNum > 1048576 {
		return "", 0, false
	}
	return s[i:j], j, true
}

// shiftRef geser satu referensi (bentuk asli, bisa ber-$).
func shiftRef(ref string, dRow, dCol int) string {
	// Urai: [$]COL[$]ROW
	i := 0
	colAbs := false
	if i < len(ref) && ref[i] == '$' {
		colAbs = true
		i++
	}
	colStart := i
	for i < len(ref) && ((ref[i] >= 'A' && ref[i] <= 'Z') || (ref[i] >= 'a' && ref[i] <= 'z')) {
		i++
	}
	colLetters := ref[colStart:i]
	rowAbs := false
	if i < len(ref) && ref[i] == '$' {
		rowAbs = true
		i++
	}
	rowStr := ref[i:]
	colNum := 0
	for _, ch := range strings.ToUpper(colLetters) {
		colNum = colNum*26 + int(ch-'A'+1)
	}
	row, _ := strconv.Atoi(rowStr)
	if !colAbs {
		colNum += dCol
	}
	if !rowAbs {
		row += dRow
	}
	var b strings.Builder
	if colAbs {
		b.WriteByte('$')
	}
	b.WriteString(ColLetters(colNum))
	if rowAbs {
		b.WriteByte('$')
	}
	b.WriteString(strconv.Itoa(row))
	return b.String()
}

// ---- Penulisan sel (satu pass) ----

// CellEdit perubahan satu sel.
type CellEdit struct {
	Kind    EditKind
	Formula string // untuk EditFormula (tanpa '=')
	Value   string // untuk EditValue (nilai cache)
	VType   string // untuk EditValue: t attr ("str" untuk teks, "" untuk angka)
	// HasCache/Cache/CacheType: nilai cache untuk EditFormula. Rumus yang
	// ditulis TANPA nilai cache dianggap kotor (dirty) sehingga Excel/Excel
	// Online menghitung ulang seluruh workbook saat dibuka — di file ini
	// rumusnya berat (QUERY VSTACK+FILTER 200 ribu baris) sehingga Excel
	// Online kehabisan waktu dan menolak membuka workbook, sementara WPS
	// menghitung ulang dan menampilkan 0 / 00-Jan-1900 / #VALUE!. Dengan
	// nilai cache, file dibuka dengan nilai terakhir seperti file aslinya.
	HasCache  bool
	Cache     string
	CacheType string // t attr nilai cache: "str" teks, "b" bool, "e" error, "" angka
}

// EditKind jenis perubahan sel.
type EditKind int

const (
	EditFormula EditKind = iota // ganti rumus (atau tulis rumus baru)
	EditClear                   // kosongkan sel (nilai + rumus dihapus, style dipertahankan)
	EditValue                   // ganti rumus jadi nilai statis (hanya untuk sel yang sumbernya hilang)
)

// WriteSheetEdits terapkan perubahan sel ke XML sheet dalam satu pass.
// Sel target harus sudah ada di sheet; kalau tidak ada, error.
func (wb *Workbook) WriteSheetEdits(sh *Sheet, edits map[string]CellEdit) error {
	xml, ok := wb.SheetXML(sh)
	if !ok {
		return fmt.Errorf("sheet %s tidak ditemukan", sh.Name)
	}
	start := strings.Index(xml, "<sheetData")
	if start < 0 {
		return fmt.Errorf("sheet %s tidak punya <sheetData>", sh.Name)
	}
	endRel := strings.Index(xml[start:], "</sheetData>")
	if endRel < 0 {
		return fmt.Errorf("sheet %s tidak punya </sheetData>", sh.Name)
	}
	dataStart, dataEnd := start, start+endRel
	data := xml[dataStart:dataEnd]

	// Cari semua span <c> beserta ref-nya.
	type span struct {
		start, end int
		ref        string
		style      string // atribut s asli ("" kalau tidak ada)
	}
	var spans []span
	for _, m := range cellRe.FindAllStringSubmatchIndex(data, -1) {
		full := data[m[0]:m[1]]
		attrs := parseAttrs("<c" + data[m[2]:m[3]] + ">")
		ref := attrs["r"]
		if ref == "" {
			continue
		}
		_ = full
		spans = append(spans, span{start: m[0], end: m[1], ref: ref, style: attrs["s"]})
	}
	byRef := make(map[string]span, len(spans))
	for _, sp := range spans {
		byRef[sp.ref] = sp
	}
	// Validasi: semua edit target ada.
	var missing []string
	for ref := range edits {
		if _, ok := byRef[ref]; !ok {
			missing = append(missing, ref)
		}
	}
	if len(missing) > 0 {
		sort.Strings(missing)
		return fmt.Errorf("sheet %s: sel tidak ditemukan: %s", sh.Name, strings.Join(missing, ", "))
	}
	// Bangun ulang data dengan substitusi.
	var b strings.Builder
	b.Grow(len(data))
	pos := 0
	// Urutkan span berdasarkan posisi.
	for _, sp := range spans {
		if sp.start < pos {
			continue
		}
		edit, isEdit := edits[sp.ref]
		b.WriteString(data[pos:sp.start])
		if isEdit {
			b.WriteString(buildCellXML(sp.ref, sp.style, edit))
		} else {
			b.WriteString(data[sp.start:sp.end])
		}
		pos = sp.end
	}
	b.WriteString(data[pos:])
	newXML := xml[:dataStart] + b.String() + xml[dataEnd:]
	wb.SetSheetXML(sh, newXML)
	return nil
}

func buildCellXML(ref, style string, edit CellEdit) string {
	var b strings.Builder
	b.WriteString(`<c r="` + ref + `"`)
	if style != "" {
		b.WriteString(` s="` + style + `"`)
	}
	switch edit.Kind {
	case EditFormula:
		if edit.HasCache && edit.CacheType != "" {
			b.WriteString(` t="` + edit.CacheType + `"`)
		}
		b.WriteString(`><f>` + xmlEscape(edit.Formula) + `</f>`)
		if edit.HasCache {
			b.WriteString(`<v>` + xmlEscape(edit.Cache) + `</v>`)
		}
		b.WriteString(`</c>`)
	case EditValue:
		if edit.VType != "" {
			b.WriteString(` t="` + edit.VType + `"`)
		}
		b.WriteString(`><v>` + xmlEscape(edit.Value) + `</v></c>`)
	case EditClear:
		b.WriteString(`/>`)
	}
	return b.String()
}

var rowRe = regexp.MustCompile(`(?s)<row(\s[^>]*?)?(?:/>|>(.*?)</row>)`)

// UpsertCells terapkan perubahan sel, menyisipkan sel baru kalau belum ada
// (beserta barisnya kalau baris belum ada). Dipakai untuk rumus per-sel
// anchor (v1.6) yang menulis ke seluruh persegi hasil impor, termasuk sel
// kosong yang tidak punya elemen <c> di XML asli. Baris dan sel yang tidak
// disentuh dibiarkan byte-nya apa adanya.
func (wb *Workbook) UpsertCells(sh *Sheet, edits map[string]CellEdit) error {
	xml, ok := wb.SheetXML(sh)
	if !ok {
		return fmt.Errorf("sheet %s tidak ditemukan", sh.Name)
	}
	start := strings.Index(xml, "<sheetData")
	if start < 0 {
		return fmt.Errorf("sheet %s tidak punya <sheetData>", sh.Name)
	}
	endRel := strings.Index(xml[start:], "</sheetData>")
	if endRel < 0 {
		return fmt.Errorf("sheet %s tidak punya </sheetData>", sh.Name)
	}
	dataStart, dataEnd := start, start+endRel
	data := xml[dataStart:dataEnd]

	// Kelompokkan edit per baris.
	byRow := make(map[int]map[string]CellEdit)
	for ref, e := range edits {
		_, row := splitRef(ref)
		if row < 1 {
			continue
		}
		if byRow[row] == nil {
			byRow[row] = make(map[string]CellEdit)
		}
		byRow[row][ref] = e
	}
	if len(byRow) == 0 {
		return nil
	}

	// Cari semua baris di sheetData.
	type rowSpan struct {
		start, end int
		num        int
		openTag    string // "<row ...>" (tanpa "/" penutup)
		inner      string // isi antara <row> dan </row> ("" kalau self-closing)
	}
	var rows []rowSpan
	for _, m := range rowRe.FindAllStringSubmatchIndex(data, -1) {
		attrs := parseAttrs("<row" + data[m[2]:m[3]] + ">")
		num, _ := strconv.Atoi(attrs["r"])
		if num == 0 {
			continue
		}
		full := data[m[0]:m[1]]
		gt := strings.Index(full, ">")
		openTag := full[:gt+1]
		inner := ""
		if m[4] >= 0 {
			inner = data[m[4]:m[5]]
		}
		rows = append(rows, rowSpan{start: m[0], end: m[1], num: num, openTag: openTag, inner: inner})
	}
	byNum := make(map[int]rowSpan, len(rows))
	for _, rs := range rows {
		byNum[rs.num] = rs
	}

	// Bangun ulang sheetData: baris lama (dengan edit yang digabung) +
	// baris baru, tetap urut nomor baris. Baris yang tidak disentuh
	// disalin byte-nya apa adanya. Bagian pembuka <sheetData ...> ditulis
	// dulu supaya baris baru yang nomornya lebih kecil dari baris lama
	// pertama tetap berada di dalam sheetData.
	var b strings.Builder
	b.Grow(len(data) + len(edits)*64)
	pos := 0
	if len(rows) > 0 {
		first := rows[0].start
		for _, rs := range rows {
			if rs.start < first {
				first = rs.start
			}
		}
		b.WriteString(data[:first])
		pos = first
	} else {
		// Tidak ada baris sama sekali: data hanya tag pembuka sheetData.
		b.WriteString(data)
		pos = len(data)
	}
	// Kumpulkan semua nomor baris (lama + baru) lalu urutkan.
	allNums := make([]int, 0, len(rows)+len(byRow))
	seen := make(map[int]bool)
	for _, rs := range rows {
		if !seen[rs.num] {
			seen[rs.num] = true
			allNums = append(allNums, rs.num)
		}
	}
	for n := range byRow {
		if !seen[n] {
			seen[n] = true
			allNums = append(allNums, n)
		}
	}
	sort.Ints(allNums)
	for _, n := range allNums {
		if rs, ok := byNum[n]; ok {
			b.WriteString(data[pos:rs.start])
			if len(byRow[n]) == 0 {
				// Baris tidak disentuh: salin apa adanya.
				b.WriteString(data[rs.start:rs.end])
			} else {
				// Baris ada edit: gabung sel, perbarui spans.
				inner, err := mergeRowCells(rs.inner, byRow[n])
				if err != nil {
					return err
				}
				openTag := rs.openTag
				// Baris self-closing (<row .../>) tidak punya penutup;
				// buang "/" supaya bisa ditulis <row ...>isi</row>.
				openTag = strings.TrimSuffix(openTag, "/>")
				if !strings.HasSuffix(openTag, ">") {
					openTag += ">"
				}
				openTag = updateRowSpans(openTag, inner)
				b.WriteString(openTag + inner + `</row>`)
			}
			pos = rs.end
		} else {
			// Baris baru: bangun <row r="N"> dari edit.
			inner, err := mergeRowCells("", byRow[n])
			if err != nil {
				return err
			}
			b.WriteString(`<row r="` + strconv.Itoa(n) + `">` + inner + `</row>`)
		}
	}
	b.WriteString(data[pos:])
	newXML := xml[:dataStart] + b.String() + xml[dataEnd:]
	wb.SetSheetXML(sh, newXML)
	return nil
}

// mergeRowCells gabung edit ke isi satu baris: sel yang sudah ada diganti,
// sel baru disisipkan pada posisi kolom yang benar (kolom menaik).
func mergeRowCells(inner string, edits map[string]CellEdit) (string, error) {
	if len(edits) == 0 {
		return inner, nil
	}
	// Sel yang sudah ada di baris ini.
	type span struct {
		start, end int
		ref        string
		style      string
		col        int
	}
	var spans []span
	for _, m := range cellRe.FindAllStringSubmatchIndex(inner, -1) {
		attrs := parseAttrs("<c" + inner[m[2]:m[3]] + ">")
		ref := attrs["r"]
		if ref == "" {
			continue
		}
		col, _ := splitRef(ref)
		spans = append(spans, span{start: m[0], end: m[1], ref: ref, style: attrs["s"], col: col})
	}
	byRef := make(map[string]span, len(spans))
	for _, sp := range spans {
		byRef[sp.ref] = sp
	}
	// Edit baru (sel belum ada), urut kolom.
	var news []string
	for ref := range edits {
		if _, ok := byRef[ref]; !ok {
			news = append(news, ref)
		}
	}
	sort.Slice(news, func(i, j int) bool {
		ci, _ := splitRef(news[i])
		cj, _ := splitRef(news[j])
		return ci < cj
	})
	newIdx := 0
	var b strings.Builder
	b.Grow(len(inner) + len(edits)*64)
	pos := 0
	for _, sp := range spans {
		// Sisipkan sel baru yang kolomnya lebih kecil dari sel ini.
		for newIdx < len(news) {
			nc, _ := splitRef(news[newIdx])
			if nc >= sp.col {
				break
			}
			b.WriteString(buildCellXML(news[newIdx], "", edits[news[newIdx]]))
			newIdx++
		}
		b.WriteString(inner[pos:sp.start])
		if edit, isEdit := edits[sp.ref]; isEdit {
			b.WriteString(buildCellXML(sp.ref, sp.style, edit))
		} else {
			b.WriteString(inner[sp.start:sp.end])
		}
		pos = sp.end
	}
	// Sisa sel baru di akhir baris.
	for newIdx < len(news) {
		b.WriteString(buildCellXML(news[newIdx], "", edits[news[newIdx]]))
		newIdx++
	}
	b.WriteString(inner[pos:])
	return b.String(), nil
}

// updateRowSpans perbarui atribut spans="min:max" di tag <row> supaya
// mencakup semua sel di baris setelah merge. Kalau tidak ada atribut spans,
// tag dibiarkan apa adanya.
func updateRowSpans(openTag, inner string) string {
	if !strings.Contains(openTag, "spans=") {
		return openTag
	}
	minCol, maxCol := 0, 0
	for _, m := range cellRe.FindAllStringSubmatchIndex(inner, -1) {
		attrs := parseAttrs("<c" + inner[m[2]:m[3]] + ">")
		col, _ := splitRef(attrs["r"])
		if col == 0 {
			continue
		}
		if minCol == 0 || col < minCol {
			minCol = col
		}
		if col > maxCol {
			maxCol = col
		}
	}
	if minCol == 0 || maxCol == 0 {
		return openTag
	}
	re := regexp.MustCompile(`spans="[^"]*"`)
	return re.ReplaceAllString(openTag, `spans="`+strconv.Itoa(minCol)+`:`+strconv.Itoa(maxCol)+`"`)
}

// ---- Pembuatan sheet impor dari nol ----

// ImportCell satu sel data untuk tab impor.
type ImportCell struct {
	Text     string // nilai teks / angka sebagai string
	IsNumber bool
	IsBool   bool
	// Style indeks xf di workbook UTAMA (-1 = tanpa style). Diisi pemanggil
	// sesudah memetakan numFmt sumber; jangan isi langsung dari workbook sumber.
	Style int
	// NumFmtID dan NumFmtCode format angka sel di workbook SUMBER
	// (di-resolve dari styles.xml sumber, bukan indeks style mentah).
	NumFmtID   int
	NumFmtCode string
}

// BuildImportSheetXML bangun XML worksheet dari grid nilai (baris x kolom).
// Sel kosong tidak ditulis (benar-benar kosong, bukan 0).
// widths: lebar kolom per kolom impor ("" = lebar default); boleh nil.
func BuildImportSheetXML(grid [][]ImportCell, widths []string) string {
	maxCol := 0
	for _, row := range grid {
		if len(row) > maxCol {
			maxCol = len(row)
		}
	}
	var b strings.Builder
	b.WriteString(`<?xml version="1.0" encoding="UTF-8" standalone="yes"?>` + "\r")
	b.WriteString(`<worksheet xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main" xmlns:r="http://schemas.openxmlformats.org/officeDocument/2006/relationships">`)
	if len(grid) > 0 && maxCol > 0 {
		b.WriteString(`<dimension ref="A1:` + CellRef(maxCol, len(grid)) + `"/>`)
	}
	b.WriteString(`<sheetViews><sheetView workbookViewId="0"/></sheetViews><sheetFormatPr defaultRowHeight="15"/>`)
	if hasWidth(widths) {
		b.WriteString(`<cols>`)
		for i, w := range widths {
			if w == "" {
				continue
			}
			b.WriteString(`<col min="` + strconv.Itoa(i+1) + `" max="` + strconv.Itoa(i+1) + `" width="` + w + `" customWidth="1"/>`)
		}
		b.WriteString(`</cols>`)
	}
	b.WriteString(`<sheetData>`)
	for ri, row := range grid {
		b.WriteString(`<row r="` + strconv.Itoa(ri+1) + `">`)
		for ci, cell := range row {
			if cell.Text == "" && !cell.IsNumber {
				continue
			}
			ref := CellRef(ci+1, ri+1)
			b.WriteString(`<c r="` + ref + `"`)
			if cell.Style >= 0 {
				b.WriteString(` s="` + strconv.Itoa(cell.Style) + `"`)
			}
			if cell.IsBool {
				b.WriteString(` t="b"><v>` + cell.Text + `</v></c>`)
			} else if cell.IsNumber {
				b.WriteString(`><v>` + cell.Text + `</v></c>`)
			} else {
				b.WriteString(` t="inlineStr"><is><t>` + xmlEscape(cell.Text) + `</t></is></c>`)
			}
		}
		b.WriteString(`</row>`)
	}
	b.WriteString(`</sheetData></worksheet>`)
	return b.String()
}

// hasWidth true kalau ada satu saja lebar kolom eksplisit.
func hasWidth(widths []string) bool {
	for _, w := range widths {
		if w != "" {
			return true
		}
	}
	return false
}

// MinimalWorkbookParts bangun workbook .xlsx minimal (untuk input CSV).
func MinimalWorkbookParts() map[string][]byte {
	ct := `<?xml version="1.0" encoding="UTF-8" standalone="yes"?>` + "\r" +
		`<Types xmlns="http://schemas.openxmlformats.org/package/2006/content-types"><Default Extension="rels" ContentType="application/vnd.openxmlformats-package.relationships+xml"/><Default Extension="xml" ContentType="application/xml"/><Override PartName="/xl/workbook.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet.main+xml"/><Override PartName="/xl/worksheets/sheet1.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.worksheet+xml"/><Override PartName="/xl/styles.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.styles+xml"/></Types>`
	rels := `<?xml version="1.0" encoding="UTF-8" standalone="yes"?>` + "\r" +
		`<Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships"><Relationship Id="rId1" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/officeDocument" Target="xl/workbook.xml"/></Relationships>`
	wb := `<?xml version="1.0" encoding="UTF-8" standalone="yes"?>` + "\r" +
		`<workbook xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main" xmlns:r="http://schemas.openxmlformats.org/officeDocument/2006/relationships"><workbookPr/><sheets><sheet name="Data" sheetId="1" r:id="rId1"/></sheets><calcPr fullCalcOnLoad="1"/></workbook>`
	wbrels := `<?xml version="1.0" encoding="UTF-8" standalone="yes"?>` + "\r" +
		`<Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships"><Relationship Id="rId1" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/worksheet" Target="worksheets/sheet1.xml"/><Relationship Id="rId2" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/styles" Target="styles.xml"/></Relationships>`
	styles := `<?xml version="1.0" encoding="UTF-8" standalone="yes"?>` + "\r" +
		`<styleSheet xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main"><fonts count="1"><font><sz val="11"/><name val="Calibri"/></font></fonts><fills count="2"><fill><patternFill patternType="none"/></fill><fill><patternFill patternType="gray125"/></fill></fills><borders count="1"><border><left/><right/><top/><bottom/><diagonal/></border></borders><cellStyleXfs count="1"><xf numFmtId="0" fontId="0" fillId="0" borderId="0"/></cellStyleXfs><cellXfs count="1"><xf numFmtId="0" fontId="0" fillId="0" borderId="0" xfId="0"/></cellXfs><cellStyles count="1"><cellStyle name="Normal" xfId="0" builtinId="0"/></cellStyles></styleSheet>`
	return map[string][]byte{
		"[Content_Types].xml":            []byte(ct),
		"_rels/.rels":                     []byte(rels),
		"xl/workbook.xml":                 []byte(wb),
		"xl/_rels/workbook.xml.rels":     []byte(wbrels),
		"xl/styles.xml":                   []byte(styles),
	}
}
