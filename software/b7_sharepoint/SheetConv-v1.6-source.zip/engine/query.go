package engine

import (
	"fmt"
	"regexp"
	"strconv"
	"strings"
)

// LocalRange satu range yang sudah ter-resolve ke tab lokal.
type LocalRange struct {
	Sheet string
	Ref   string // sudah dibatasi ke baris terakhir data, mis. A2:CB500
}

// BuildQueryFormula ubah QUERY Google menjadi rumus Excel hidup:
// LET(d, VSTACK(...), FILTER/SORT/CHOOSECOLS/TAKE...).
// Mendukung subset Google Visualization Query Language: select *, select Col,
// where (perbandingan, is null/not null, contains, starts with, ends with,
// digabung AND/OR), order by, limit, offset. group by / fungsi agregat /
// matches (regex) / label / format tidak didukung dan mengembalikan error.
func BuildQueryFormula(ranges []LocalRange, query string) (string, error) {
	if len(ranges) == 0 {
		return "", fmt.Errorf("QUERY tidak punya sumber data")
	}
	var parts []string
	for _, r := range ranges {
		parts = append(parts, QuoteSheetName(r.Sheet)+"!"+r.Ref)
	}
	vstack := "VSTACK(" + strings.Join(parts, ", ") + ")"

	q, err := parseQuery(query)
	if err != nil {
		return "", err
	}

	// Pipeline: d -> FILTER (where) -> SORT (order by) -> CHOOSECOLS (select)
	// -> DROP (offset) -> TAKE (limit).
	expr := "d"
	if q.where != "" {
		expr = "FILTER(" + expr + ", " + q.where + ")"
	}
	if len(q.orderBy) > 0 {
		expr = applyOrderBy(expr, q.orderBy)
	}
	if len(q.selectCols) > 0 {
		var cols []string
		for _, c := range q.selectCols {
			cols = append(cols, strconv.Itoa(c))
		}
		expr = "CHOOSECOLS(" + expr + ", " + strings.Join(cols, ", ") + ")"
	}
	if q.offset > 0 {
		expr = "DROP(" + expr + ", " + strconv.Itoa(q.offset) + ")"
	}
	if q.limit > 0 {
		expr = "TAKE(" + expr + ", " + strconv.Itoa(q.limit) + ")"
	}
	return "LET(d, " + vstack + ", " + expr + ")", nil
}

func applyOrderBy(expr string, order []orderCol) string {
	if len(order) == 1 {
		o := "1"
		if !order[0].asc {
			o = "-1"
		}
		return "SORT(" + expr + ", " + strconv.Itoa(order[0].col) + ", " + o + ")"
	}
	var cols, ords []string
	for _, oc := range order {
		cols = append(cols, strconv.Itoa(oc.col))
		if oc.asc {
			ords = append(ords, "1")
		} else {
			ords = append(ords, "-1")
		}
	}
	return "SORT(" + expr + ", {" + strings.Join(cols, ",") + "}, {" + strings.Join(ords, ",") + "})"
}

type orderCol struct {
	col int
	asc bool
}

type parsedQuery struct {
	selectCols []int // kosong = select *
	where      string
	orderBy    []orderCol
	limit      int
	offset     int
}

// ---- tokenizer + parser query ----

type qtoken struct {
	kind string // word, number, str, op, comma, paren
	text string
}

func tokenizeQuery(q string) []qtoken {
	var toks []qtoken
	i := 0
	n := len(q)
	for i < n {
		c := q[i]
		switch {
		case c == ' ' || c == '\t' || c == '\n' || c == '\r':
			i++
		case c == '\'' || c == '"':
			quote := c
			j := i + 1
			var b strings.Builder
			for j < n {
				if q[j] == quote {
					if quote == '\'' && j+1 < n && q[j+1] == '\'' {
						b.WriteByte('\'')
						j += 2
						continue
					}
					j++
					break
				}
				b.WriteByte(q[j])
				j++
			}
			toks = append(toks, qtoken{"str", b.String()})
			i = j
		case c == ',':
			toks = append(toks, qtoken{"comma", ","})
			i++
		case c == '(' || c == ')':
			toks = append(toks, qtoken{"paren", string(c)})
			i++
		case c == '<' || c == '>' || c == '=' || c == '!':
			j := i + 1
			if j < n && (q[j] == '=' || q[j] == '>') {
				j++
			}
			toks = append(toks, qtoken{"op", q[i:j]})
			i = j
		case (c >= '0' && c <= '9') || (c == '-' && i+1 < n && q[i+1] >= '0' && q[i+1] <= '9') || c == '.':
			j := i
			for j < n && ((q[j] >= '0' && q[j] <= '9') || q[j] == '.' || q[j] == '-' || q[j] == '+' || q[j] == 'e' || q[j] == 'E') {
				j++
			}
			toks = append(toks, qtoken{"number", q[i:j]})
			i = j
		case (c >= 'A' && c <= 'Z') || (c >= 'a' && c <= 'z') || c == '_' || c == '*':
			j := i
			for j < n && ((q[j] >= 'A' && q[j] <= 'Z') || (q[j] >= 'a' && q[j] <= 'z') || (q[j] >= '0' && q[j] <= '9') || q[j] == '_' || q[j] == '*' || q[j] == '.') {
				j++
			}
			toks = append(toks, qtoken{"word", q[i:j]})
			i = j
		default:
			i++
		}
	}
	return toks
}

var colRe = regexp.MustCompile(`(?i)^col(\d+)$`)

func parseQuery(query string) (*parsedQuery, error) {
	toks := tokenizeQuery(query)
	pq := &parsedQuery{}
	i := 0
	// SELECT
	if i < len(toks) && toks[i].kind == "word" && strings.EqualFold(toks[i].text, "select") {
		i++
		if i < len(toks) && toks[i].kind == "word" && toks[i].text == "*" {
			i++
		} else {
			for i < len(toks) {
				if toks[i].kind == "word" && isClauseKeyword(toks[i].text) {
					break
				}
				if toks[i].kind == "word" {
					m := colRe.FindStringSubmatch(toks[i].text)
					if m == nil {
						return nil, fmt.Errorf("select hanya mendukung ColN atau *, ketemu %q", toks[i].text)
					}
					n, _ := strconv.Atoi(m[1])
					pq.selectCols = append(pq.selectCols, n)
					i++
					continue
				}
				if toks[i].kind == "comma" {
					i++
					continue
				}
				return nil, fmt.Errorf("select tidak bisa diurai di %q", toks[i].text)
			}
		}
	}
	// WHERE
	if i < len(toks) && toks[i].kind == "word" && strings.EqualFold(toks[i].text, "where") {
		i++
		start := i
		for i < len(toks) && !(toks[i].kind == "word" && isClauseKeyword(toks[i].text)) {
			i++
		}
		cond, err := parseWhere(toks[start:i])
		if err != nil {
			return nil, err
		}
		pq.where = cond
	}
	// ORDER BY
	if i < len(toks) && toks[i].kind == "word" && strings.EqualFold(toks[i].text, "order") {
		i++
		if i < len(toks) && toks[i].kind == "word" && strings.EqualFold(toks[i].text, "by") {
			i++
		} else {
			return nil, fmt.Errorf("order harus diikuti by")
		}
		for i < len(toks) {
			if toks[i].kind == "word" && isClauseKeyword(toks[i].text) {
				break
			}
			if toks[i].kind == "word" {
				m := colRe.FindStringSubmatch(toks[i].text)
				if m == nil {
					return nil, fmt.Errorf("order by hanya mendukung ColN, ketemu %q", toks[i].text)
				}
				n, _ := strconv.Atoi(m[1])
				asc := true
				i++
				if i < len(toks) && toks[i].kind == "word" && (strings.EqualFold(toks[i].text, "asc") || strings.EqualFold(toks[i].text, "desc")) {
					asc = strings.EqualFold(toks[i].text, "asc")
					i++
				}
				pq.orderBy = append(pq.orderBy, orderCol{col: n, asc: asc})
				continue
			}
			if toks[i].kind == "comma" {
				i++
				continue
			}
			return nil, fmt.Errorf("order by tidak bisa diurai di %q", toks[i].text)
		}
	}
	// LIMIT / OFFSET
	for i < len(toks) {
		if toks[i].kind == "word" && strings.EqualFold(toks[i].text, "limit") {
			i++
			if i < len(toks) && toks[i].kind == "number" {
				pq.limit, _ = strconv.Atoi(toks[i].text)
				i++
				continue
			}
			return nil, fmt.Errorf("limit harus diikuti angka")
		}
		if toks[i].kind == "word" && strings.EqualFold(toks[i].text, "offset") {
			i++
			if i < len(toks) && toks[i].kind == "number" {
				pq.offset, _ = strconv.Atoi(toks[i].text)
				i++
				continue
			}
			return nil, fmt.Errorf("offset harus diikuti angka")
		}
		// label, format, options, group by: diabaikan / tidak didukung
		if toks[i].kind == "word" && strings.EqualFold(toks[i].text, "group") {
			return nil, fmt.Errorf("group by tidak didukung converter")
		}
		i++
	}
	return pq, nil
}

func isClauseKeyword(w string) bool {
	switch strings.ToLower(w) {
	case "where", "order", "limit", "offset", "label", "format", "options", "group":
		return true
	}
	return false
}

// parseWhere gabungkan kondisi dengan AND (*) atau OR (+).
// Tanda kurung di where tidak didukung.
func parseWhere(toks []qtoken) (string, error) {
	// Pecah pada AND / OR top-level.
	type group struct {
		conds []string
		or    bool
	}
	var groups []group
	cur := group{}
	flush := func() {
		if len(cur.conds) > 0 {
			groups = append(groups, cur)
		}
		cur = group{}
	}
	start := 0
	for i := 0; i <= len(toks); i++ {
		if i == len(toks) || (toks[i].kind == "word" && (strings.EqualFold(toks[i].text, "and") || strings.EqualFold(toks[i].text, "or"))) {
			cond, err := parseCondition(toks[start:i])
			if err != nil {
				return "", err
			}
			cur.conds = append(cur.conds, cond)
			if i < len(toks) && strings.EqualFold(toks[i].text, "or") {
				cur.or = true
			}
			if i == len(toks) || strings.EqualFold(toks[i].text, "or") {
				flush()
			}
			start = i + 1
		}
	}
	flush()
	if len(groups) == 0 {
		return "", fmt.Errorf("where kosong")
	}
	var andParts []string
	for _, g := range groups {
		if len(g.conds) == 1 {
			andParts = append(andParts, g.conds[0])
		} else if g.or {
			andParts = append(andParts, "("+strings.Join(g.conds, "+")+")")
		} else {
			andParts = append(andParts, "("+strings.Join(g.conds, "*")+")")
		}
	}
	if len(andParts) == 1 {
		return andParts[0], nil
	}
	return strings.Join(andParts, "*"), nil
}

func parseCondition(toks []qtoken) (string, error) {
	// Buang token kosong.
	var t []qtoken
	for _, tk := range toks {
		t = append(t, tk)
	}
	if len(t) == 0 {
		return "", fmt.Errorf("kondisi where kosong")
	}
	if t[0].kind == "paren" {
		return "", fmt.Errorf("tanda kurung di where tidak didukung")
	}
	if t[0].kind != "word" {
		return "", fmt.Errorf("kondisi where harus mulai dari ColN, ketemu %q", t[0].text)
	}
	m := colRe.FindStringSubmatch(t[0].text)
	if m == nil {
		return "", fmt.Errorf("kondisi where harus mulai dari ColN, ketemu %q", t[0].text)
	}
	col, _ := strconv.Atoi(m[1])
	ref := "INDEX(d,," + strconv.Itoa(col) + ")"
	if len(t) < 2 {
		return "", fmt.Errorf("kondisi where tidak lengkap untuk Col%d", col)
	}
	// IS [NOT] NULL
	if t[1].kind == "word" && strings.EqualFold(t[1].text, "is") {
		notNull := false
		j := 2
		if j < len(t) && t[j].kind == "word" && strings.EqualFold(t[j].text, "not") {
			notNull = true
			j++
		}
		if j < len(t) && t[j].kind == "word" && strings.EqualFold(t[j].text, "null") {
			if notNull {
				return ref + "<>\"\"", nil
			}
			return ref + "=\"\"", nil
		}
		return "", fmt.Errorf("is harus diikuti null di where")
	}
	// CONTAINS / STARTS WITH / ENDS WITH / MATCHES
	if t[1].kind == "word" {
		w := strings.ToLower(t[1].text)
		if w == "contains" || w == "starts" || w == "ends" || w == "matches" {
			if w == "matches" {
				return "", fmt.Errorf("matches (regex) di where tidak didukung")
			}
			// starts with / ends with: dua kata
			valIdx := 2
			if (w == "starts" || w == "ends") && valIdx < len(t) && t[valIdx].kind == "word" && strings.EqualFold(t[valIdx].text, "with") {
				valIdx = 3
			}
			if valIdx >= len(t) || t[valIdx].kind != "str" {
				return "", fmt.Errorf("%s harus diikuti teks dalam petik", w)
			}
			val := excelStr(t[valIdx].text)
			switch w {
			case "contains":
				return "ISNUMBER(SEARCH(" + val + "," + ref + "))", nil
			case "starts":
				return "LEFT(" + ref + ",LEN(" + val + "))=" + val, nil
			case "ends":
				return "RIGHT(" + ref + ",LEN(" + val + "))=" + val, nil
			}
		}
	}
	// Perbandingan: op + nilai
	if t[1].kind != "op" {
		return "", fmt.Errorf("operator tidak dikenal di where: %q", t[1].text)
	}
	op := t[1].text
	if len(t) < 3 {
		return "", fmt.Errorf("kondisi where tidak lengkap untuk Col%d", col)
	}
	val, err := whereValue(t[2])
	if err != nil {
		return "", err
	}
	switch op {
	case "=", "<>", "!=", "<", "<=", ">", ">=":
		if op == "!=" {
			op = "<>"
		}
		return ref + op + val, nil
	}
	return "", fmt.Errorf("operator %q tidak didukung di where", op)
}

func whereValue(t qtoken) (string, error) {
	switch t.kind {
	case "str":
		return excelStr(t.text), nil
	case "number":
		return t.text, nil
	case "word":
		if strings.EqualFold(t.text, "true") || strings.EqualFold(t.text, "false") {
			return strings.ToUpper(t.text), nil
		}
		if strings.EqualFold(t.text, "null") {
			return "\"\"", nil
		}
		return "", fmt.Errorf("nilai tidak dikenal di where: %q", t.text)
	}
	return "", fmt.Errorf("nilai tidak dikenal di where: %q", t.text)
}

// excelStr jadi literal string Excel ("..." dengan "" untuk petik).
func excelStr(s string) string {
	return "\"" + strings.ReplaceAll(s, "\"", "\"\"") + "\""
}
