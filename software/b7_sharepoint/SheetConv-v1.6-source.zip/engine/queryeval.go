// Evaluasi QUERY Google di Go (bukan sebagai rumus Excel).
//
// Dipakai v1.6 untuk rumus per-sel: hasil QUERY dihitung di sini dari data
// cache (grid sumber yang sudah diunduh), lalu tiap sel hasil ditulis
// sebagai rumus per-sel yang menunjuk ke sel sumbernya di sheet _IMPORT.
// Dengan begitu tidak ada rumus dynamic-array (LET/VSTACK/FILTER + spill)
// di file hasil, tapi rumusnya tetap HIDUP (bukan nilai mati): kalau nilai
// di sheet sumber berubah, hasil ikut berubah.
//
// Mendukung subset yang sama seperti BuildQueryFormula: select * / select
// ColN, where (perbandingan, is null/not null, contains, starts with,
// ends with, digabung AND/OR), order by, limit, offset. group by /
// agregat / matches (regex) / label / format tidak didukung.
package engine

import (
	"fmt"
	"sort"
	"strconv"
	"strings"
)

// QCell satu sel sumber untuk evaluasi QUERY.
type QCell struct {
	Text   string
	IsNum  bool
	IsBool bool
}

// QSrc lokasi satu sel sumber (indeks grid, baris, kolom — 0-based).
type QSrc struct {
	Grid int
	Row  int
	Col  int
}

// EvalQuery jalankan QUERY terhadap grid sumber yang sudah di-stack
// (grids[0] di atas grids[1], dst.). Mengembalikan baris hasil; tiap
// baris adalah daftar sel sumber (satu per kolom hasil) supaya pemanggil
// bisa membangun rumus per-sel ke sheet _IMPORT. Mengembalikan juga
// jumlah kolom hasil.
func EvalQuery(grids [][][]QCell, query string) ([][]QSrc, int, error) {
	plan, err := parseQueryPlan(query)
	if err != nil {
		return nil, 0, err
	}
	// Stack semua grid (baris demi baris).
	var rows [][]QCell
	var src [][]QSrc // src[r][c] = lokasi sel (grid, baris, kolom) data r kolom c
	for gi, g := range grids {
		for ri, row := range g {
			rows = append(rows, row)
			srow := make([]QSrc, len(row))
			for ci := range row {
				srow[ci] = QSrc{Grid: gi, Row: ri, Col: ci}
			}
			src = append(src, srow)
		}
	}
	if len(rows) == 0 {
		return nil, 0, fmt.Errorf("QUERY tidak punya sumber data")
	}
	ncols := 0
	for _, r := range rows {
		if len(r) > ncols {
			ncols = len(r)
		}
	}
	// Normalisasi: semua baris punya ncols kolom (sel kosong di akhir).
	for i, r := range rows {
		if len(r) < ncols {
			pad := make([]QCell, ncols-len(r))
			rows[i] = append(r, pad...)
			spad := make([]QSrc, ncols-len(r))
			for j := range spad {
				spad[j] = QSrc{Grid: -1, Row: -1, Col: -1}
			}
			src[i] = append(src[i], spad...)
		}
	}
	// WHERE: saring baris.
	keep := make([]bool, len(rows))
	for i, r := range rows {
		if plan.where == nil {
			keep[i] = true
			continue
		}
		keep[i] = evalCond(plan.where, r)
	}
	var frows [][]QCell
	var fsrc [][]QSrc
	for i := range rows {
		if keep[i] {
			frows = append(frows, rows[i])
			fsrc = append(fsrc, src[i])
		}
	}
	// ORDER BY: urutkan baris (stabil).
	if len(plan.orderBy) > 0 {
		idx := make([]int, len(frows))
		for i := range idx {
			idx[i] = i
		}
		sort.SliceStable(idx, func(a, b int) bool {
			ra, rb := frows[idx[a]], frows[idx[b]]
			for _, oc := range plan.orderBy {
				c := compareCells(cellAt(ra, oc.col), cellAt(rb, oc.col))
				if c != 0 {
					if oc.asc {
						return c < 0
					}
					return c > 0
				}
			}
			return false
		})
		nr := make([][]QCell, len(frows))
		ns := make([][]QSrc, len(fsrc))
		for i, j := range idx {
			nr[i] = frows[j]
			ns[i] = fsrc[j]
		}
		frows, fsrc = nr, ns
	}
	// SELECT: pilih kolom.
	outCols := ncols
	if len(plan.selectCols) > 0 {
		outCols = len(plan.selectCols)
	}
	var out [][]QSrc
	for i := range frows {
		row := make([]QSrc, outCols)
		if len(plan.selectCols) == 0 {
			copy(row, fsrc[i])
		} else {
			for j, c := range plan.selectCols {
				if c >= 1 && c <= len(fsrc[i]) {
					row[j] = fsrc[i][c-1]
				} else {
					row[j] = QSrc{Grid: -1, Row: -1, Col: -1}
				}
			}
		}
		out = append(out, row)
	}
	// OFFSET lalu LIMIT.
	if plan.offset > 0 {
		if plan.offset >= len(out) {
			out = nil
		} else {
			out = out[plan.offset:]
		}
	}
	if plan.limit > 0 && plan.limit < len(out) {
		out = out[:plan.limit]
	}
	return out, outCols, nil
}

// cellAt ambil sel kolom ke-col (1-based) dari baris; sel kosong kalau di
// luar jangkauan.
func cellAt(row []QCell, col int) QCell {
	if col < 1 || col > len(row) {
		return QCell{}
	}
	return row[col-1]
}

// compareCells bandingkan dua sel untuk ORDER BY: angka dibanding angka,
// teks dibanding teks (tanpa bedakan huruf besar/kecil), angka < teks.
func compareCells(a, b QCell) int {
	an, aok := cellNumber(a)
	bn, bok := cellNumber(b)
	if aok && bok {
		if an < bn {
			return -1
		}
		if an > bn {
			return 1
		}
		return 0
	}
	if aok != bok {
		if aok {
			return -1
		}
		return 1
	}
	return strings.Compare(strings.ToLower(a.Text), strings.ToLower(b.Text))
}

// cellNumber nilai numerik sel (angka atau bool sebagai 1/0).
func cellNumber(c QCell) (float64, bool) {
	if c.IsBool {
		if strings.EqualFold(c.Text, "true") || c.Text == "1" {
			return 1, true
		}
		return 0, true
	}
	if c.IsNum {
		f, err := strconv.ParseFloat(strings.ReplaceAll(c.Text, ",", "."), 64)
		if err == nil {
			return f, true
		}
	}
	return 0, false
}

// ---- pohon kondisi where ----

type qcond struct {
	op    string // "and", "or", "cmp", "isnull", "contains", "starts", "ends"
	col   int    // kolom 1-based (untuk cmp/isnull/contains/starts/ends)
	cmpOp string // "=", "<>", "<", "<=", ">", ">=" (untuk cmp)
	val   string // nilai pembanding (untuk cmp/contains/starts/ends)
	isNum bool   // val adalah angka (untuk cmp)
	left  *qcond
	right *qcond
}

// evalCond nilai kondisi where untuk satu baris data.
func evalCond(c *qcond, row []QCell) bool {
	switch c.op {
	case "and":
		return evalCond(c.left, row) && evalCond(c.right, row)
	case "or":
		return evalCond(c.left, row) || evalCond(c.right, row)
	case "isnull":
		return cellAt(row, c.col).Text == ""
	case "notnull":
		return cellAt(row, c.col).Text != ""
	case "contains":
		return strings.Contains(strings.ToLower(cellAt(row, c.col).Text), strings.ToLower(c.val))
	case "starts":
		return strings.HasPrefix(strings.ToLower(cellAt(row, c.col).Text), strings.ToLower(c.val))
	case "ends":
		return strings.HasSuffix(strings.ToLower(cellAt(row, c.col).Text), strings.ToLower(c.val))
	case "cmp":
		cell := cellAt(row, c.col)
		if c.isNum {
			cv, ok := cellNumber(cell)
			if !ok {
				return false
			}
			nv, _ := strconv.ParseFloat(c.val, 64)
			return cmpNum(cv, nv, c.cmpOp)
		}
		// null (string kosong) sebagai nilai pembanding.
		if c.val == "" && !c.isNum {
			return cmpStr(cell.Text, "", c.cmpOp)
		}
		return cmpStr(cell.Text, c.val, c.cmpOp)
	}
	return false
}

func cmpNum(a, b float64, op string) bool {
	switch op {
	case "=":
		return a == b
	case "<>":
		return a != b
	case "<":
		return a < b
	case "<=":
		return a <= b
	case ">":
		return a > b
	case ">=":
		return a >= b
	}
	return false
}

func cmpStr(a, b, op string) bool {
	c := strings.Compare(strings.ToLower(a), strings.ToLower(b))
	switch op {
	case "=":
		return c == 0
	case "<>":
		return c != 0
	case "<":
		return c < 0
	case "<=":
		return c <= 0
	case ">":
		return c > 0
	case ">=":
		return c >= 0
	}
	return false
}

// ---- parser rencana query (untuk evaluasi Go) ----

type queryPlan struct {
	selectCols []int
	where      *qcond
	orderBy    []orderCol
	limit      int
	offset     int
}

func parseQueryPlan(query string) (*queryPlan, error) {
	toks := tokenizeQuery(query)
	pq := &queryPlan{}
	i := 0
	// SELECT
	if i < len(toks) && toks[i].kind == "word" && strings.EqualFold(toks[i].text, "select") {
		i++
		if i < len(toks) && toks[i].kind == "word" && toks[i].text == "*" {
			i++
		} else {
			for i < len(toks) {
				if toks[i].kind == "word" && isClauseKeyword(toks[i].text) {
					break
				}
				if toks[i].kind == "word" {
					m := colRe.FindStringSubmatch(toks[i].text)
					if m == nil {
						return nil, fmt.Errorf("select hanya mendukung ColN atau *, ketemu %q", toks[i].text)
					}
					n, _ := strconv.Atoi(m[1])
					pq.selectCols = append(pq.selectCols, n)
					i++
					continue
				}
				if toks[i].kind == "comma" {
					i++
					continue
				}
				return nil, fmt.Errorf("select tidak bisa diurai di %q", toks[i].text)
			}
		}
	}
	// WHERE
	if i < len(toks) && toks[i].kind == "word" && strings.EqualFold(toks[i].text, "where") {
		i++
		start := i
		for i < len(toks) && !(toks[i].kind == "word" && isClauseKeyword(toks[i].text)) {
			i++
		}
		cond, err := parseWherePlan(toks[start:i])
		if err != nil {
			return nil, err
		}
		pq.where = cond
	}
	// ORDER BY
	if i < len(toks) && toks[i].kind == "word" && strings.EqualFold(toks[i].text, "order") {
		i++
		if i < len(toks) && toks[i].kind == "word" && strings.EqualFold(toks[i].text, "by") {
			i++
		} else {
			return nil, fmt.Errorf("order harus diikuti by")
		}
		for i < len(toks) {
			if toks[i].kind == "word" && isClauseKeyword(toks[i].text) {
				break
			}
			if toks[i].kind == "word" {
				m := colRe.FindStringSubmatch(toks[i].text)
				if m == nil {
					return nil, fmt.Errorf("order by hanya mendukung ColN, ketemu %q", toks[i].text)
				}
				n, _ := strconv.Atoi(m[1])
				asc := true
				i++
				if i < len(toks) && toks[i].kind == "word" && (strings.EqualFold(toks[i].text, "asc") || strings.EqualFold(toks[i].text, "desc")) {
					asc = strings.EqualFold(toks[i].text, "asc")
					i++
				}
				pq.orderBy = append(pq.orderBy, orderCol{col: n, asc: asc})
				continue
			}
			if toks[i].kind == "comma" {
				i++
				continue
			}
			return nil, fmt.Errorf("order by tidak bisa diurai di %q", toks[i].text)
		}
	}
	// LIMIT / OFFSET
	for i < len(toks) {
		if toks[i].kind == "word" && strings.EqualFold(toks[i].text, "limit") {
			i++
			if i < len(toks) && toks[i].kind == "number" {
				pq.limit, _ = strconv.Atoi(toks[i].text)
				i++
				continue
			}
			return nil, fmt.Errorf("limit harus diikuti angka")
		}
		if toks[i].kind == "word" && strings.EqualFold(toks[i].text, "offset") {
			i++
			if i < len(toks) && toks[i].kind == "number" {
				pq.offset, _ = strconv.Atoi(toks[i].text)
				i++
				continue
			}
			return nil, fmt.Errorf("offset harus diikuti angka")
		}
		if toks[i].kind == "word" && strings.EqualFold(toks[i].text, "group") {
			return nil, fmt.Errorf("group by tidak didukung converter")
		}
		i++
	}
	return pq, nil
}

// parseWherePlan gabungkan kondisi dengan AND/OR (semantik sama seperti
// parseWhere: kondisi berurutan yang dihubungkan OR membentuk satu grup,
// grup-grup dihubungkan AND).
func parseWherePlan(toks []qtoken) (*qcond, error) {
	type group struct {
		conds []*qcond
		or    bool
	}
	var groups []group
	cur := group{}
	flush := func() {
		if len(cur.conds) > 0 {
			groups = append(groups, cur)
		}
		cur = group{}
	}
	start := 0
	for i := 0; i <= len(toks); i++ {
		if i == len(toks) || (toks[i].kind == "word" && (strings.EqualFold(toks[i].text, "and") || strings.EqualFold(toks[i].text, "or"))) {
			cond, err := parseConditionPlan(toks[start:i])
			if err != nil {
				return nil, err
			}
			cur.conds = append(cur.conds, cond)
			if i < len(toks) && strings.EqualFold(toks[i].text, "or") {
				cur.or = true
			}
			if i == len(toks) || strings.EqualFold(toks[i].text, "or") {
				flush()
			}
			start = i + 1
		}
	}
	flush()
	if len(groups) == 0 {
		return nil, fmt.Errorf("where kosong")
	}
	var andParts []*qcond
	for _, g := range groups {
		if len(g.conds) == 1 {
			andParts = append(andParts, g.conds[0])
		} else {
			joined := g.conds[0]
			for _, c := range g.conds[1:] {
				op := "and"
				if g.or {
					op = "or"
				}
				joined = &qcond{op: op, left: joined, right: c}
			}
			andParts = append(andParts, joined)
		}
	}
	root := andParts[0]
	for _, c := range andParts[1:] {
		root = &qcond{op: "and", left: root, right: c}
	}
	return root, nil
}

func parseConditionPlan(toks []qtoken) (*qcond, error) {
	if len(toks) == 0 {
		return nil, fmt.Errorf("kondisi where kosong")
	}
	if toks[0].kind == "paren" {
		return nil, fmt.Errorf("tanda kurung di where tidak didukung")
	}
	if toks[0].kind != "word" {
		return nil, fmt.Errorf("kondisi where harus mulai dari ColN, ketemu %q", toks[0].text)
	}
	m := colRe.FindStringSubmatch(toks[0].text)
	if m == nil {
		return nil, fmt.Errorf("kondisi where harus mulai dari ColN, ketemu %q", toks[0].text)
	}
	col, _ := strconv.Atoi(m[1])
	if len(toks) < 2 {
		return nil, fmt.Errorf("kondisi where tidak lengkap untuk Col%d", col)
	}
	// IS [NOT] NULL
	if toks[1].kind == "word" && strings.EqualFold(toks[1].text, "is") {
		notNull := false
		j := 2
		if j < len(toks) && toks[j].kind == "word" && strings.EqualFold(toks[j].text, "not") {
			notNull = true
			j++
		}
		if j < len(toks) && toks[j].kind == "word" && strings.EqualFold(toks[j].text, "null") {
			if notNull {
				return &qcond{op: "notnull", col: col}, nil
			}
			return &qcond{op: "isnull", col: col}, nil
		}
		return nil, fmt.Errorf("is harus diikuti null di where")
	}
	// CONTAINS / STARTS WITH / ENDS WITH / MATCHES
	if toks[1].kind == "word" {
		w := strings.ToLower(toks[1].text)
		if w == "contains" || w == "starts" || w == "ends" || w == "matches" {
			if w == "matches" {
				return nil, fmt.Errorf("matches (regex) di where tidak didukung")
			}
			valIdx := 2
			if (w == "starts" || w == "ends") && valIdx < len(toks) && toks[valIdx].kind == "word" && strings.EqualFold(toks[valIdx].text, "with") {
				valIdx = 3
			}
			if valIdx >= len(toks) || toks[valIdx].kind != "str" {
				return nil, fmt.Errorf("%s harus diikuti teks dalam petik", w)
			}
			return &qcond{op: w, col: col, val: toks[valIdx].text}, nil
		}
	}
	// Perbandingan: op + nilai
	if toks[1].kind != "op" {
		return nil, fmt.Errorf("operator tidak dikenal di where: %q", toks[1].text)
	}
	op := toks[1].text
	if len(toks) < 3 {
		return nil, fmt.Errorf("kondisi where tidak lengkap untuk Col%d", col)
	}
	switch op {
	case "=", "<>", "!=", "<", "<=", ">", ">=":
		if op == "!=" {
			op = "<>"
		}
	default:
		return nil, fmt.Errorf("operator %q tidak didukung di where", op)
	}
	t := toks[2]
	switch t.kind {
	case "str":
		return &qcond{op: "cmp", col: col, cmpOp: op, val: t.text}, nil
	case "number":
		return &qcond{op: "cmp", col: col, cmpOp: op, val: t.text, isNum: true}, nil
	case "word":
		if strings.EqualFold(t.text, "true") || strings.EqualFold(t.text, "false") {
			return &qcond{op: "cmp", col: col, cmpOp: op, val: strings.ToUpper(t.text)}, nil
		}
		if strings.EqualFold(t.text, "null") {
			return &qcond{op: "cmp", col: col, cmpOp: op, val: ""}, nil
		}
		return nil, fmt.Errorf("nilai tidak dikenal di where: %q", t.text)
	}
	return nil, fmt.Errorf("nilai tidak dikenal di where: %q", t.text)
}
