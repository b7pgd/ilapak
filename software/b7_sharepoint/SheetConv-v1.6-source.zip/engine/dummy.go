package engine

import (
	"fmt"
	"regexp"
	"strconv"
	"strings"
)

// UnwrapDummy membongkar =IFERROR(__xludf.DUMMYFUNCTION("payload"), fallback).
// Argumen DUMMYFUNCTION bisa berupa beberapa literal string yang digabung
// dengan & (Google memecah payload panjang menjadi potongan-potongan).
// Mengembalikan payload (rumus asli Google yang tidak bisa di-export),
// fallback (nilai terakhir yang dihitung Google), dan ok.
func UnwrapDummy(f string) (payload, fallback string, ok bool) {
	upper := strings.ToUpper(f)
	idx := strings.Index(upper, "__XLUDF.DUMMYFUNCTION(")
	if idx < 0 {
		return "", "", false
	}
	p := idx + len("__XLUDF.DUMMYFUNCTION(")
	var b strings.Builder
	for {
		for p < len(f) && f[p] == ' ' {
			p++
		}
		if p >= len(f) || f[p] != '"' {
			return "", "", false
		}
		s, end, good := parseQString(f, p)
		if !good {
			return "", "", false
		}
		b.WriteString(s)
		p = end
		for p < len(f) && f[p] == ' ' {
			p++
		}
		if p < len(f) && f[p] == '&' {
			p++
			continue
		}
		break
	}
	payload = b.String()
	// Fallback: argumen ke-2 dari IFERROR pembungkus, kalau ada.
	trimmed := strings.TrimSpace(strings.TrimPrefix(strings.TrimSpace(f), "="))
	if strings.HasPrefix(strings.ToUpper(trimmed), "IFERROR(") {
		open := strings.Index(trimmed, "(")
		close := findMatchingParen(trimmed, open)
		if close > 0 {
			args := splitTopArgs(trimmed[open+1 : close])
			if len(args) >= 2 {
				fallback = args[1]
			}
		}
	}
	return payload, fallback, true
}

// parseQString baca string literal "..." mulai dari i (f[i] harus '"').
// Mengembalikan isi string ("" di-unescape jadi "), indeks setelah petik tutup.
func parseQString(f string, i int) (string, int, bool) {
	if i >= len(f) || f[i] != '"' {
		return "", 0, false
	}
	var b strings.Builder
	i++
	for i < len(f) {
		if f[i] == '"' {
			if i+1 < len(f) && f[i+1] == '"' {
				b.WriteByte('"')
				i += 2
				continue
			}
			return b.String(), i + 1, true
		}
		b.WriteByte(f[i])
		i++
	}
	return "", 0, false
}

// ParseImportRange mengurai payload IMPORTRANGE("url", "range").
// Mengembalikan url dan range string.
func ParseImportRange(payload string) (url, rangeStr string, ok bool) {
	t := strings.TrimSpace(payload)
	if !strings.HasPrefix(strings.ToUpper(t), "IMPORTRANGE(") {
		return "", "", false
	}
	open := strings.Index(t, "(")
	close := findMatchingParen(t, open)
	if close < 0 {
		return "", "", false
	}
	args := splitTopArgs(t[open+1 : close])
	if len(args) < 2 {
		return "", "", false
	}
	u, good1 := unquote(args[0])
	r, good2 := unquote(args[1])
	if !good1 || !good2 {
		return "", "", false
	}
	return u, r, true
}

// unquote buang petik luar string literal dan unescape "".
func unquote(s string) (string, bool) {
	s = strings.TrimSpace(s)
	if len(s) < 2 || s[0] != '"' || s[len(s)-1] != '"' {
		return "", false
	}
	return strings.ReplaceAll(s[1:len(s)-1], `""`, `"`), true
}

var sheetIDRe = regexp.MustCompile(`/d/([A-Za-z0-9_-]+)`)

// SpreadsheetID ambil id spreadsheet dari URL Google Sheets.
func SpreadsheetID(url string) string {
	m := sheetIDRe.FindStringSubmatch(url)
	if m == nil {
		return ""
	}
	return m[1]
}

// ParseSheetRange mengurai 'Nama Sheet'!A1:B2 atau Nama!A1:B2 atau A1:B2.
// Mengembalikan nama sheet ("" kalau tidak ada) dan referensi range.
func ParseSheetRange(rangeStr string) (sheet, ref string) {
	s := strings.TrimSpace(rangeStr)
	if strings.HasPrefix(s, "'") {
		// Nama berpetik, '' = petik di dalam nama.
		i := 1
		var b strings.Builder
		for i < len(s) {
			if s[i] == '\'' {
				if i+1 < len(s) && s[i+1] == '\'' {
					b.WriteByte('\'')
					i += 2
					continue
				}
				i++
				break
			}
			b.WriteByte(s[i])
			i++
		}
		sheet = b.String()
		if i < len(s) && s[i] == '!' {
			i++
		}
		return sheet, strings.TrimSpace(s[i:])
	}
	if idx := strings.Index(s, "!"); idx >= 0 {
		return s[:idx], s[idx+1:]
	}
	return "", s
}

// NormalizeSheetName untuk mencocokkan nama tab lama (LKPTA/LKCPA) dengan tab
// gabungan (LKPTALKCPA): buang '/', spasi, '_' dan '-'.
func NormalizeSheetName(s string) string {
	s = strings.ToUpper(s)
	s = strings.ReplaceAll(s, "/", "")
	s = strings.ReplaceAll(s, " ", "")
	s = strings.ReplaceAll(s, "_", "")
	s = strings.ReplaceAll(s, "-", "")
	return s
}

// QuoteSheetName nama sheet untuk dipakai di dalam rumus (selalu dipetik).
func QuoteSheetName(s string) string {
	return "'" + strings.ReplaceAll(s, "'", "''") + "'"
}

// BoundRange batasi range terbuka (A2:CB atau A:A) ke baris terakhir data.
// Range yang sudah punya baris akhir dikembalikan apa adanya.
func BoundRange(ref string, maxRow int) string {
	if maxRow < 1 {
		maxRow = 1
	}
	if idx := strings.Index(ref, ":"); idx >= 0 {
		head, tail := ref[:idx], ref[idx+1:]
		if isBareColumn(head) && isBareColumn(tail) {
			// B:C -> B1:C<max>
			return head + "1:" + tail + strconv.Itoa(maxRow)
		}
		if isBareColumn(tail) {
			return head + ":" + tail + strconv.Itoa(maxRow)
		}
		return ref
	}
	return ref
}

func isBareColumn(s string) bool {
	s = strings.ReplaceAll(s, "$", "")
	if s == "" {
		return false
	}
	for _, c := range s {
		if (c < 'A' || c > 'Z') && (c < 'a' || c > 'z') {
			return false
		}
	}
	return true
}

// ---- QUERY ----

// QueryDataPart satu sumber data di dalam QUERY: IMPORTRANGE atau range lokal.
type QueryDataPart struct {
	URL      string // kosong kalau range lokal
	RangeStr string
}

// ParseQuery mengurai payload QUERY(data, "query", [headers]).
func ParseQuery(payload string) (data string, query string, ok bool) {
	t := strings.TrimSpace(payload)
	if !strings.HasPrefix(strings.ToUpper(t), "QUERY(") {
		return "", "", false
	}
	open := strings.Index(t, "(")
	close := findMatchingParen(t, open)
	if close < 0 {
		return "", "", false
	}
	args := splitTopArgs(t[open+1 : close])
	if len(args) < 2 {
		return "", "", false
	}
	q, good := unquote(args[1])
	if !good {
		return "", "", false
	}
	return args[0], q, true
}

// ParseQueryData mengurai bagian data QUERY: {IMPORTRANGE(...); ...} atau
// IMPORTRANGE(...) tunggal atau range biasa.
func ParseQueryData(data string) ([]QueryDataPart, error) {
	d := strings.TrimSpace(data)
	if strings.HasPrefix(d, "{") && strings.HasSuffix(d, "}") {
		inner := d[1 : len(d)-1]
		parts := splitTopSep(inner, ';')
		var out []QueryDataPart
		for _, p := range parts {
			p = strings.TrimSpace(p)
			if p == "" {
				continue
			}
			if strings.HasPrefix(strings.ToUpper(p), "IMPORTRANGE(") {
				u, r, good := ParseImportRange(p)
				if !good {
					return nil, errf("IMPORTRANGE di dalam QUERY tidak bisa diurai: %s", p)
				}
				out = append(out, QueryDataPart{URL: u, RangeStr: r})
			} else {
				out = append(out, QueryDataPart{RangeStr: p})
			}
		}
		return out, nil
	}
	if strings.HasPrefix(strings.ToUpper(d), "IMPORTRANGE(") {
		u, r, good := ParseImportRange(d)
		if !good {
			return nil, errf("IMPORTRANGE tidak bisa diurai: %s", d)
		}
		return []QueryDataPart{{URL: u, RangeStr: r}}, nil
	}
	return []QueryDataPart{{RangeStr: d}}, nil
}

// splitTopSep pecah string pada pemisah top-level (di luar string dan kurung).
func splitTopSep(s string, sep byte) []string {
	var out []string
	depthParen, depthBrace := 0, 0
	start := 0
	i := 0
	n := len(s)
	for i < n {
		c := s[i]
		switch {
		case c == '"':
			i++
			for i < n {
				if s[i] == '"' {
					if i+1 < n && s[i+1] == '"' {
						i += 2
						continue
					}
					i++
					break
				}
				i++
			}
		case c == '\'':
			i++
			for i < n {
				if s[i] == '\'' {
					if i+1 < n && s[i+1] == '\'' {
						i += 2
						continue
					}
					i++
					break
				}
				i++
			}
		case c == '(':
			depthParen++
			i++
		case c == ')':
			depthParen--
			i++
		case c == '{':
			depthBrace++
			i++
		case c == '}':
			depthBrace--
			i++
		case c == sep && depthParen == 0 && depthBrace == 0:
			out = append(out, s[start:i])
			start = i + 1
			i++
		default:
			i++
		}
	}
	out = append(out, s[start:])
	return out
}

func errf(format string, args ...interface{}) error {
	return &queryError{msg: fmt.Sprintf(format, args...)}
}

type queryError struct{ msg string }

func (e *queryError) Error() string { return e.msg }
