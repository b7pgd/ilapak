package engine

import (
	"strings"
)

// Scanner rumus Excel: mengenali pemanggilan fungsi di luar string literal
// ("...") dan nama sheet berpetik ('...'!). Nama sheet telanjang (DATA!A1)
// tidak diikuti '(' jadi tidak pernah salah dikenali sebagai fungsi.

// isIdentStart / isIdentChar: karakter nama fungsi.
func isIdentStart(c byte) bool {
	return c == '_' || (c >= 'A' && c <= 'Z') || (c >= 'a' && c <= 'z')
}
func isIdentChar(c byte) bool {
	return isIdentStart(c) || (c >= '0' && c <= '9') || c == '.'
}

// NormalizeName: huruf besar, buang prefix _xlfn. (fungsi modern di file .xlsx).
func NormalizeName(name string) string {
	name = strings.ToUpper(name)
	return strings.TrimPrefix(name, "_XLFN.")
}

// scanCall memindai satu pemanggilan fungsi mulai dari posisi pos.
// Mengembalikan nama (ternormalisasi), indeks awal nama, indeks '(' dan indeks
// ')' penutup. ok=false kalau tidak ada pemanggilan dari pos.
func scanCall(f string, pos int) (name string, identStart, openIdx, closeIdx int, ok bool) {
	n := len(f)
	i := pos
	for i < n {
		c := f[i]
		switch {
		case c == '"': // string literal, lewati ("" = petik di dalam string)
			i++
			for i < n {
				if f[i] == '"' {
					if i+1 < n && f[i+1] == '"' {
						i += 2
						continue
					}
					i++
					break
				}
				i++
			}
		case c == '\'': // nama sheet berpetik, lewati ('' = petik di dalam nama)
			i++
			for i < n {
				if f[i] == '\'' {
					if i+1 < n && f[i+1] == '\'' {
						i += 2
						continue
					}
					i++
					break
				}
				i++
			}
		case isIdentStart(c):
			j := i
			for j < n && isIdentChar(f[j]) {
				j++
			}
			k := j
			for k < n && f[k] == ' ' {
				k++
			}
			if k < n && f[k] == '(' {
				close := findMatchingParen(f, k)
				if close < 0 {
					return "", 0, 0, 0, false
				}
				return NormalizeName(f[i:j]), i, k, close, true
			}
			i = j
		default:
			i++
		}
	}
	return "", 0, 0, 0, false
}

// findMatchingParen cari indeks ')' yang menutup '(' di openIdx.
func findMatchingParen(f string, openIdx int) int {
	n := len(f)
	depth := 0
	i := openIdx
	for i < n {
		c := f[i]
		switch {
		case c == '"':
			i++
			for i < n {
				if f[i] == '"' {
					if i+1 < n && f[i+1] == '"' {
						i += 2
						continue
					}
					i++
					break
				}
				i++
			}
		case c == '\'':
			i++
			for i < n {
				if f[i] == '\'' {
					if i+1 < n && f[i+1] == '\'' {
						i += 2
						continue
					}
					i++
					break
				}
				i++
			}
		case c == '(':
			depth++
			i++
		case c == ')':
			depth--
			if depth == 0 {
				return i
			}
			i++
		default:
			i++
		}
	}
	return -1
}

// splitTopArgs pecah isi kurung menjadi argumen top-level.
// Koma di dalam string, kurung bersarang, atau konstanta array {...} tidak memecah.
func splitTopArgs(s string) []string {
	var args []string
	depthParen, depthBrace := 0, 0
	start := 0
	i := 0
	n := len(s)
	for i < n {
		c := s[i]
		switch {
		case c == '"':
			i++
			for i < n {
				if s[i] == '"' {
					if i+1 < n && s[i+1] == '"' {
						i += 2
						continue
					}
					i++
					break
				}
				i++
			}
		case c == '\'':
			i++
			for i < n {
				if s[i] == '\'' {
					if i+1 < n && s[i+1] == '\'' {
						i += 2
						continue
					}
					i++
					break
				}
				i++
			}
		case c == '(':
			depthParen++
			i++
		case c == ')':
			depthParen--
			i++
		case c == '{':
			depthBrace++
			i++
		case c == '}':
			depthBrace--
			i++
		case c == ',' && depthParen == 0 && depthBrace == 0:
			args = append(args, strings.TrimSpace(s[start:i]))
			start = i + 1
			i++
		default:
			i++
		}
	}
	args = append(args, strings.TrimSpace(s[start:]))
	return args
}

// ScanFunctions daftar nama fungsi dalam rumus, sesuai urutan kemunculan.
func ScanFunctions(f string) []string {
	var out []string
	pos := 0
	for {
		name, _, _, closeIdx, ok := scanCall(f, pos)
		if !ok {
			return out
		}
		out = append(out, name)
		pos = closeIdx + 1
	}
}

// HasMappingFunc true kalau rumus mengandung fungsi yang ada di mappings.
func HasMappingFunc(f string, cat *Catalog) bool {
	for _, name := range ScanFunctions(f) {
		if _, ok := cat.Mappings[name]; ok {
			return true
		}
	}
	return false
}

// Rewrite menulis ulang semua fungsi pemetaan di dalam rumus.
// Mengembalikan rumus baru + daftar nama fungsi yang ditulis ulang.
func Rewrite(f string, cat *Catalog) (string, []string) {
	var rewritten []string
	pos := 0
	for {
		name, identStart, openIdx, closeIdx, ok := scanCall(f, pos)
		if !ok {
			return f, rewritten
		}
		if _, isMap := cat.Mappings[name]; !isMap {
			pos = closeIdx + 1
			continue
		}
		inner := f[openIdx+1 : closeIdx]
		args := splitTopArgs(inner)
		for i := range args {
			args[i], _ = Rewrite(args[i], cat)
		}
		origCall := f[identStart : closeIdx+1]
		newCall, changed := applyTemplate(name, args)
		if !changed {
			// Tidak bisa ditulis ulang (parsial/tidak ada padanan): biarkan apa
			// adanya, lewati supaya tidak loop.
			pos = closeIdx + 1
			continue
		}
		f = f[:identStart] + newCall + f[closeIdx+1:]
		rewritten = append(rewritten, name)
		pos = identStart + len(newCall)
		_ = origCall
	}
}

func joinArgs(args []string) string { return strings.Join(args, ", ") }

// applyTemplate terapkan aturan padanan satu fungsi.
// changed=false berarti rumus dibiarkan apa adanya (parsial / tidak ada padanan).
func applyTemplate(name string, args []string) (string, bool) {
	need := func(n int) bool { return len(args) >= n }
	switch name {
	case "GOOGLETRANSLATE":
		if !need(1) {
			return "", false
		}
		return "TRANSLATE(" + joinArgs(args) + ")", true
	case "REGEXMATCH":
		if !need(2) {
			return "", false
		}
		return "REGEXTEST(" + joinArgs(args) + ")", true
	case "POW":
		if !need(2) {
			return "", false
		}
		return "POWER(" + joinArgs(args) + ")", true
	case "JOIN":
		if !need(2) {
			return "", false
		}
		return "TEXTJOIN(" + args[0] + ", TRUE, " + joinArgs(args[1:]) + ")", true
	case "SPLIT":
		if !need(2) {
			return "", false
		}
		return "TEXTSPLIT(" + args[0] + ", " + args[1] + ")", true
	case "SORT":
		return rewriteSort(args), true
	case "FILTER":
		if !need(2) {
			return "", false
		}
		if len(args) == 2 {
			return "FILTER(" + args[0] + ", " + args[1] + ")", true
		}
		var conds []string
		for _, c := range args[1:] {
			conds = append(conds, "("+c+")")
		}
		return "FILTER(" + args[0] + ", " + strings.Join(conds, "*") + ")", true
	case "ARRAYFORMULA":
		if !need(1) {
			return "", false
		}
		return args[0], true
	case "ARRAY_CONSTRAIN":
		if !need(3) {
			return "", false
		}
		return "TAKE(" + args[0] + ", " + args[1] + ", " + args[2] + ")", true
	case "FLATTEN":
		if !need(1) {
			return "", false
		}
		if len(args) == 1 {
			return "TOCOL(" + args[0] + ")", true
		}
		return "TOCOL(VSTACK(" + joinArgs(args) + "))", true
	case "COUNTUNIQUE":
		if !need(1) {
			return "", false
		}
		if len(args) == 1 {
			return "ROWS(UNIQUE(" + args[0] + "))", true
		}
		return "ROWS(UNIQUE(VSTACK(" + joinArgs(args) + ")))", true
	case "AVERAGE.WEIGHTED":
		if len(args) < 2 || len(args)%2 != 0 {
			return "", false
		}
		var num, den []string
		for i := 0; i < len(args); i += 2 {
			num = append(num, "SUMPRODUCT("+args[i]+", "+args[i+1]+")")
			den = append(den, "SUM("+args[i+1]+")")
		}
		return "(" + strings.Join(num, "+") + ")/(" + strings.Join(den, "+") + ")", true
	case "MARGINOFERROR":
		if !need(2) {
			return "", false
		}
		return "CONFIDENCE.NORM(1-" + args[1] + ", STDEV.P(" + args[0] + "), COUNT(" + args[0] + "))", true
	case "EPOCHTODATE":
		if !need(1) {
			return "", false
		}
		div := "86400"
		if len(args) >= 2 {
			switch strings.ToLower(strings.Trim(args[1], "\"")) {
			case "ms", "millisecond", "milliseconds":
				div = "86400000"
			case "us", "microsecond", "microseconds":
				div = "86400000000"
			}
		}
		return "(" + args[0] + "/" + div + ")+DATE(1970,1,1)", true
	case "TO_DATE", "TO_DOLLARS", "TO_PERCENT", "TO_PURE_NUMBER":
		if !need(1) {
			return "", false
		}
		return args[0], true
	case "TO_TEXT":
		if !need(1) {
			return "", false
		}
		return "TEXT(" + args[0] + ", \"@\")", true
	case "IMLOG":
		if !need(2) {
			return "", false
		}
		return "IMLN(" + args[0] + ")/LN(" + args[1] + ")", true
	case "IMCOTH":
		if !need(1) {
			return "", false
		}
		return "IMCOSH(" + args[0] + ")/IMSINH(" + args[0] + ")", true
	case "IMTANH":
		if !need(1) {
			return "", false
		}
		return "IMSINH(" + args[0] + ")/IMCOSH(" + args[0] + ")", true
	case "SORTN":
		return rewriteSortN(args), true
	case "IMAGE":
		return rewriteImage(args)
	case "ADD":
		if !need(2) {
			return "", false
		}
		return "(" + args[0] + "+" + args[1] + ")", true
	case "MINUS":
		if !need(2) {
			return "", false
		}
		return "(" + args[0] + "-" + args[1] + ")", true
	case "MULTIPLY":
		if !need(2) {
			return "", false
		}
		return "(" + args[0] + "*" + args[1] + ")", true
	case "DIVIDE":
		if !need(2) {
			return "", false
		}
		return "(" + args[0] + "/" + args[1] + ")", true
	case "EQ":
		if !need(2) {
			return "", false
		}
		return "(" + args[0] + "=" + args[1] + ")", true
	case "NE":
		if !need(2) {
			return "", false
		}
		return "(" + args[0] + "<>" + args[1] + ")", true
	case "GT":
		if !need(2) {
			return "", false
		}
		return "(" + args[0] + ">" + args[1] + ")", true
	case "GTE":
		if !need(2) {
			return "", false
		}
		return "(" + args[0] + ">=" + args[1] + ")", true
	case "LT":
		if !need(2) {
			return "", false
		}
		return "(" + args[0] + "<" + args[1] + ")", true
	case "LTE":
		if !need(2) {
			return "", false
		}
		return "(" + args[0] + "<=" + args[1] + ")", true
	case "UMINUS":
		if !need(1) {
			return "", false
		}
		return "(-" + args[0] + ")", true
	case "UPLUS":
		if !need(1) {
			return "", false
		}
		return "(+" + args[0] + ")", true
	case "UNARY_PERCENT":
		if !need(1) {
			return "", false
		}
		return "(" + args[0] + "%)", true
	case "ISBETWEEN":
		return rewriteIsBetween(args)
	case "ISDATE":
		if !need(1) {
			return "", false
		}
		return "ISNUMBER(" + args[0] + ")", true
	case "ISEMAIL":
		if !need(1) {
			return "", false
		}
		return "AND(ISNUMBER(SEARCH(\"@\", " + args[0] + ")), ISNUMBER(SEARCH(\".\", " + args[0] + ")))", true
	case "ISURL":
		if !need(1) {
			return "", false
		}
		return "ISNUMBER(SEARCH(\"://\", " + args[0] + "))", true
	case "GOOGLEFINANCE":
		// Harga historis (ada tanggal awal/akhir) -> STOCKHISTORY.
		// Harga saat ini / atribut lain: tidak ada padanan rumus.
		if len(args) >= 4 {
			return "STOCKHISTORY(" + args[0] + ", " + args[2] + ", " + args[3] + ", 0, 1)", true
		}
		return "", false
	case "SPARKLINE", "AI":
		return "", false
	}
	return "", false
}

// rewriteSort: SORT(range, col1, asc1, col2, asc2...) ->
// SORT(range, {col1,col2}, {ord1,ord2}) atau SORT(range, col, ord).
func rewriteSort(args []string) string {
	if len(args) < 1 {
		return "SORT()"
	}
	if len(args) == 1 {
		return "SORT(" + args[0] + ")"
	}
	var cols, ords []string
	for i := 1; i+1 < len(args); i += 2 {
		cols = append(cols, args[i])
		switch strings.ToUpper(strings.TrimSpace(args[i+1])) {
		case "TRUE":
			ords = append(ords, "1")
		case "FALSE":
			ords = append(ords, "-1")
		default:
			ords = append(ords, "IF("+args[i+1]+",1,-1)")
		}
	}
	if len(cols) == 0 {
		return "SORT(" + args[0] + ")"
	}
	if len(cols) == 1 {
		return "SORT(" + args[0] + ", " + cols[0] + ", " + ords[0] + ")"
	}
	return "SORT(" + args[0] + ", {" + strings.Join(cols, ",") + "}, {" + strings.Join(ords, ",") + "})"
}

// rewriteSortN: SORTN(range, [n], [ties], [col1, asc1...]) -> TAKE(SORT(...), n).
func rewriteSortN(args []string) string {
	if len(args) < 1 {
		return "SORTN()"
	}
	n := "1"
	if len(args) >= 2 && strings.TrimSpace(args[1]) != "" {
		n = args[1]
	}
	sortArgs := []string{args[0]}
	if len(args) > 3 {
		sortArgs = append(sortArgs, args[3:]...)
	}
	return "TAKE(" + rewriteSort(sortArgs) + ", " + n + ")"
}

// rewriteImage: mode Google 1/2/3/4 -> sizing Excel 0/1/2/3.
// Kalau argumen ke-2 sudah "" berarti sudah bentuk Excel, biarkan.
func rewriteImage(args []string) (string, bool) {
	if len(args) < 2 {
		return "", false
	}
	mode := strings.TrimSpace(args[1])
	if mode == `""` {
		return "", false
	}
	var sizing string
	switch mode {
	case "1":
		sizing = "0"
	case "2":
		sizing = "1"
	case "3":
		sizing = "2"
	case "4":
		sizing = "3"
	default:
		sizing = "(" + mode + "-1)"
	}
	out := "IMAGE(" + args[0] + ", \"\", " + sizing
	for _, extra := range args[2:] {
		out += ", " + extra
	}
	return out + ")", true
}

// rewriteIsBetween: ISBETWEEN(v, lo, hi, [loInc], [hiInc]) -> AND(...).
func rewriteIsBetween(args []string) (string, bool) {
	if len(args) < 3 {
		return "", false
	}
	v, lo, hi := args[0], args[1], args[2]
	loInc, hiInc := "TRUE", "TRUE"
	if len(args) >= 4 && strings.TrimSpace(args[3]) != "" {
		loInc = args[3]
	}
	if len(args) >= 5 && strings.TrimSpace(args[4]) != "" {
		hiInc = args[4]
	}
	left := cmpSide(v, lo, ">=", ">", loInc)
	right := cmpSide(v, hi, "<=", "<", hiInc)
	return "AND(" + left + ", " + right + ")", true
}

func cmpSide(v, bound, inclOp, exclOp, inc string) string {
	switch strings.ToUpper(strings.TrimSpace(inc)) {
	case "TRUE":
		return v + inclOp + bound
	case "FALSE":
		return v + exclOp + bound
	default:
		return "IF(" + inc + ", " + v + inclOp + bound + ", " + v + exclOp + bound + ")"
	}
}
