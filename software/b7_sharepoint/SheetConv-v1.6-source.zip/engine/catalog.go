// Package engine: katalog rumus + penulisan ulang rumus Google Sheets ke Excel.
package engine

import (
	"encoding/json"
	"fmt"
	"os"
	"strings"
)

// MappingKind: padanan (ada alternatif penuh), parsial (alternatif menutupi
// kasus umum saja), tidak_ada (tidak ada padanan rumus).
type Mapping struct {
	Kind      string `json:"kind"`
	Excel     string `json:"excel"`
	Mekanisme string `json:"mekanisme"`
}

type rawCatalog struct {
	Version         int               `json:"version"`
	ExcelNative     []string          `json:"excel_native"`
	WebUnavailable  []string          `json:"web_unavailable"`
	Mappings        map[string]Mapping `json:"mappings"`
}

// Catalog: daftar fungsi Excel native + pemetaan fungsi Google-only.
type Catalog struct {
	Native         map[string]bool
	WebUnavailable map[string]bool
	Mappings       map[string]Mapping
}

// LoadCatalog baca formulas.json dari disk kalau ada (bisa diedit tanpa rebuild),
// kalau tidak ada pakai fallback yang di-embed ke binary (dioper dari main).
func LoadCatalog(path string, embedded []byte) (*Catalog, error) {
	data, err := os.ReadFile(path)
	if err != nil {
		data = embedded
	}
	var raw rawCatalog
	if err := json.Unmarshal(data, &raw); err != nil {
		return nil, fmt.Errorf("formulas.json tidak bisa dibaca: %w", err)
	}
	c := &Catalog{
		Native:         make(map[string]bool, len(raw.ExcelNative)),
		WebUnavailable: make(map[string]bool, len(raw.WebUnavailable)),
		Mappings:       raw.Mappings,
	}
	for _, n := range raw.ExcelNative {
		c.Native[strings.ToUpper(n)] = true
	}
	for _, n := range raw.WebUnavailable {
		c.WebUnavailable[strings.ToUpper(n)] = true
	}
	return c, nil
}

// Tier hasil klasifikasi satu fungsi.
type Tier string

const (
	TierExact      Tier = "exact"       // ada persis di Excel, lolos apa adanya
	TierExactWeb   Tier = "exact_web"   // ada di Excel desktop, tidak jalan di Excel Online
	TierPadanan    Tier = "padanan"     // ada alternatif, ditulis ulang
	TierParsial    Tier = "parsial"     // alternatif menutupi kasus umum saja
	TierTidakAda   Tier = "tidak_ada"   // tidak ada padanan rumus
	TierTidakKenal Tier = "tidak_kenal" // tidak ada di katalog sama sekali
)

// Classify satu nama fungsi (huruf besar, tanpa prefix _xlfn.).
func (c *Catalog) Classify(name string) Tier {
	name = strings.ToUpper(strings.TrimPrefix(name, "_XLFN."))
	if m, ok := c.Mappings[name]; ok {
		switch m.Kind {
		case "padanan":
			return TierPadanan
		case "parsial":
			return TierParsial
		case "tidak_ada":
			return TierTidakAda
		}
	}
	if c.Native[name] {
		if c.WebUnavailable[name] {
			return TierExactWeb
		}
		return TierExact
	}
	return TierTidakKenal
}

// Mechanism deskripsi padanan untuk satu fungsi (kosong kalau tidak ada).
func (c *Catalog) Mechanism(name string) string {
	if m, ok := c.Mappings[strings.ToUpper(name)]; ok {
		return m.Mekanisme
	}
	return ""
}

// ExcelName nama Excel pengganti (kosong kalau tidak ada).
func (c *Catalog) ExcelName(name string) string {
	if m, ok := c.Mappings[strings.ToUpper(name)]; ok {
		return m.Excel
	}
	return ""
}
