// Referensi kolom penuh (mis. H:H, $H:$H, 'Sheet'!$H:$H).
//
// Referensi seperti ini membuat Excel Online mengeluh "SLOW WORKBOOK"
// karena menghitung 1.048.576 baris untuk tiap rumus. v1.6 membatasinya
// ke baris terakhir data (mis. $H$1:$H$402) supaya tetap rumus hidup
// tapi tidak lagi menghitung kolom penuh.
package engine

import (
	"strconv"
	"strings"
)

// HasFullColumnRef true kalau rumus mengandung referensi kolom penuh.
func HasFullColumnRef(f string) bool {
	_, _, _, _, _, ok := findFullColumnRef(f, 0)
	return ok
}

// BoundFullColumns batasi referensi kolom penuh ke baris terakhir data.
// maxRow(sheet) mengembalikan baris terakhir data untuk sheet bernama
// sheet ("" = sheet tempat rumus berada); 0 = sheet tidak dikenal,
// referensinya dibiarkan apa adanya. Mengembalikan rumus baru dan jumlah
// referensi yang dibatasi.
func BoundFullColumns(f string, maxRow func(sheet string) int) (string, int) {
	var b strings.Builder
	pos := 0
	count := 0
	for {
		s, e, sheet, c1, c2, ok := findFullColumnRef(f, pos)
		if !ok {
			break
		}
		mr := maxRow(sheet)
		if mr < 1 {
			// Sheet tidak dikenal: biarkan referensi apa adanya.
			b.WriteString(f[pos:e])
			pos = e
			continue
		}
		b.WriteString(f[pos:s])
		if sheet == "" {
			b.WriteString(c1 + "1:" + c2 + strconv.Itoa(mr))
		} else {
			b.WriteString("'" + strings.ReplaceAll(sheet, "'", "''") + "'!" + c1 + "1:" + c2 + strconv.Itoa(mr))
		}
		count++
		pos = e
	}
	b.WriteString(f[pos:])
	return b.String(), count
}

// findFullColumnRef cari referensi kolom penuh mulai dari pos.
// Mengembalikan (start, end, sheet, col1, col2, ok). sheet "" = sheet
// tempat rumus berada. String literal ("...") dan nama sheet berpetik
// ('...') tidak disentuh.
func findFullColumnRef(f string, pos int) (start, end int, sheet, c1, c2 string, ok bool) {
	n := len(f)
	i := pos
	for i < n {
		c := f[i]
		if c == '"' {
			j := i + 1
			for j < n {
				if f[j] == '"' {
					if j+1 < n && f[j+1] == '"' {
						j += 2
						continue
					}
					j++
					break
				}
				j++
			}
			i = j
			continue
		}
		if c == '\'' {
			j := i + 1
			var sb strings.Builder
			for j < n {
				if f[j] == '\'' {
					if j+1 < n && f[j+1] == '\'' {
						sb.WriteByte('\'')
						j += 2
						continue
					}
					j++
					break
				}
				sb.WriteByte(f[j])
				j++
			}
			if j < n && f[j] == '!' {
				if e, a, b, good := readFullCol(f, j+1); good {
					return i, e, sb.String(), a, b, true
				}
			}
			i = j
			continue
		}
		if isIdentStart(c) {
			j := i
			for j < n && isIdentChar(f[j]) {
				j++
			}
			k := j
			for k < n && f[k] == ' ' {
				k++
			}
			if k < n && f[k] == '!' {
				// Nama sheet telanjang (mis. Data!H:H).
				if e, a, b, good := readFullCol(f, k+1); good {
					return i, e, f[i:j], a, b, true
				}
				i = k + 1
				continue
			}
			// Bukan sheet: coba kolom penuh tanpa sheet di posisi i.
			if e, a, b, good := readFullCol(f, i); good {
				return i, e, "", a, b, true
			}
			i = j
			continue
		}
		if c == '$' {
			if e, a, b, good := readFullCol(f, i); good {
				return i, e, "", a, b, true
			}
			i++
			continue
		}
		i++
	}
	return 0, 0, "", "", "", false
}

// readFullCol baca referensi kolom penuh di posisi i: [$]COL:[$]COL (tanpa
// nomor baris). Mengembalikan indeks akhir, kolom1, kolom2 (beserta $),
// dan ok. Referensi sel (H1) atau range berbaris (H1:H10) ditolak.
func readFullCol(f string, i int) (end int, c1, c2 string, ok bool) {
	n := len(f)
	j := i
	start1 := j
	if j < n && f[j] == '$' {
		j++
	}
	cs := j
	for j < n && ((f[j] >= 'A' && f[j] <= 'Z') || (f[j] >= 'a' && f[j] <= 'z')) {
		j++
	}
	if j == cs {
		return 0, "", "", false
	}
	// Setelah huruf kolom tidak boleh ada angka (itu referensi sel).
	if j < n && f[j] >= '0' && f[j] <= '9' {
		return 0, "", "", false
	}
	c1 = f[start1:j]
	if j >= n || f[j] != ':' {
		return 0, "", "", false
	}
	j++
	start2 := j
	if j < n && f[j] == '$' {
		j++
	}
	cs2 := j
	for j < n && ((f[j] >= 'A' && f[j] <= 'Z') || (f[j] >= 'a' && f[j] <= 'z')) {
		j++
	}
	if j == cs2 {
		return 0, "", "", false
	}
	if j < n && f[j] >= '0' && f[j] <= '9' {
		return 0, "", "", false
	}
	c2 = f[start2:j]
	return j, c1, c2, true
}
