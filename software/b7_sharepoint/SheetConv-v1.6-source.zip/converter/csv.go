package converter

import (
	"archive/zip"
	"bytes"
	"encoding/csv"
	"fmt"
	"io"
	"strconv"
	"strings"

	"sheetconv/xlsx"
)

// CSVToXLSX ubah file CSV jadi workbook .xlsx minimal (satu sheet "Data").
// Mengembalikan bytes xlsx + jumlah baris data. CSV tidak mengandung rumus.
func CSVToXLSX(csvData []byte, fileName string) ([]byte, int, error) {
	text := string(csvData)
	// Hapus BOM kalau ada.
	text = strings.TrimPrefix(text, "\ufeff")
	// Deteksi pemisah dari baris pertama.
	delim := ','
	if firstLine := strings.SplitN(text, "\n", 2)[0]; firstLine != "" {
		if strings.Count(firstLine, ";") > strings.Count(firstLine, ",") {
			delim = ';'
		}
	}
	r := csv.NewReader(strings.NewReader(text))
	r.Comma = delim
	r.FieldsPerRecord = -1
	r.LazyQuotes = true
	records, err := r.ReadAll()
	if err != nil && err != io.EOF {
		return nil, 0, fmt.Errorf("CSV tidak bisa dibaca: %w", err)
	}
	grid := make([][]xlsx.ImportCell, 0, len(records))
	for _, rec := range records {
		row := make([]xlsx.ImportCell, len(rec))
		for i, v := range rec {
			v = strings.TrimSpace(v)
			if v == "" {
				continue
			}
			if num, ok := csvNumber(v); ok {
				row[i] = xlsx.ImportCell{Text: num, IsNumber: true}
			} else {
				row[i] = xlsx.ImportCell{Text: v}
			}
		}
		grid = append(grid, row)
	}
	parts := xlsx.MinimalWorkbookParts()
	parts["xl/worksheets/sheet1.xml"] = []byte(xlsx.BuildImportSheetXML(grid, nil))
	var buf bytes.Buffer
	zw := zip.NewWriter(&buf)
	order := []string{"[Content_Types].xml", "_rels/.rels", "xl/workbook.xml", "xl/_rels/workbook.xml.rels", "xl/worksheets/sheet1.xml", "xl/styles.xml"}
	for _, name := range order {
		data, ok := parts[name]
		if !ok {
			continue
		}
		w, err := zw.CreateHeader(&zip.FileHeader{Name: name, Method: zip.Deflate})
		if err != nil {
			return nil, 0, err
		}
		if _, err := w.Write(data); err != nil {
			return nil, 0, err
		}
	}
	if err := zw.Close(); err != nil {
		return nil, 0, err
	}
	return buf.Bytes(), len(records), nil
}

// csvNumber kenali angka, termasuk desimal koma ala Indonesia (1,5 -> 1.5).
func csvNumber(v string) (string, bool) {
	if _, err := strconv.ParseFloat(v, 64); err == nil {
		return v, true
	}
	dotted := strings.ReplaceAll(v, ",", ".")
	// Hanya terima kalau aslinya memang bentuk angka (digit + satu koma).
	if _, err := strconv.ParseFloat(dotted, 64); err == nil {
		return dotted, true
	}
	return "", false
}
