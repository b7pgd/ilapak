// Package web: server HTTP (Echo SSR) untuk SheetConv.
// Semua file hasil convert hanya ada di memori dan terhapus otomatis
// setelah diunduh atau 10 menit; tidak ada file yang ditulis ke disk.
package web

import (
	"bytes"
	"crypto/rand"
	"encoding/hex"
	"fmt"
	"html/template"
	"io"
	"net/http"
	"os"
	"path/filepath"
	"regexp"
	"strings"
	"sync"
	"time"

	"github.com/labstack/echo/v4"
	"github.com/labstack/echo/v4/middleware"

	"sheetconv/converter"
	"sheetconv/engine"
)

const (
	maxUploadBytes = 100 << 20 // 100 MB
	jobTTL         = 10 * time.Minute
)

// Job satu pekerjaan convert.
type Job struct {
	ID        string
	CreatedAt time.Time
	Stage     string
	Percent   int
	StartedAt time.Time
	Done      bool
	Err       string
	Output    []byte
	FileName  string
	Report    *converter.Report
	mu        sync.Mutex
}

// Server pegang katalog + daftar job.
type Server struct {
	Catalog   *engine.Catalog
	Templates *template.Template
	StaticFS  map[string][]byte // file embed (fallback kalau disk tidak ada)
	jobs      sync.Map // string -> *Job
}

// NewServer buat server; templates dari disk kalau ada, kalau tidak dari embed.
func NewServer(cat *engine.Catalog, tmpl *template.Template, staticFS map[string][]byte) *Server {
	s := &Server{Catalog: cat, Templates: tmpl, StaticFS: staticFS}
	go s.sweeper()
	return s
}

func (s *Server) sweeper() {
	for {
		time.Sleep(time.Minute)
		now := time.Now()
		s.jobs.Range(func(k, v interface{}) bool {
			j := v.(*Job)
			j.mu.Lock()
			expired := now.Sub(j.CreatedAt) > jobTTL
			j.mu.Unlock()
			if expired {
				s.jobs.Delete(k)
			}
			return true
		})
	}
}

func newJobID() string {
	b := make([]byte, 12)
	rand.Read(b)
	return hex.EncodeToString(b)
}

func (s *Server) newJob() *Job {
	j := &Job{ID: newJobID(), CreatedAt: time.Now(), StartedAt: time.Now(), Stage: "Menyiapkan", Percent: 0}
	s.jobs.Store(j.ID, j)
	return j
}

func (j *Job) setProgress(pct int, stage string) {
	j.mu.Lock()
	defer j.mu.Unlock()
	j.Percent = pct
	j.Stage = stage
}

func (j *Job) etaSeconds() int {
	// Dipanggil saat j.mu sudah dipegang pemanggil (handleProgress).
	if j.Percent <= 0 || j.Percent >= 100 || j.Done {
		return 0
	}
	elapsed := time.Since(j.StartedAt).Seconds()
	eta := elapsed * float64(100-j.Percent) / float64(j.Percent)
	return int(eta + 0.5)
}

// Routes daftarkan semua route ke Echo.
func (s *Server) Routes(e *echo.Echo) {
	e.Use(middleware.Recover())
	e.GET("/", s.handleIndex)
	e.GET("/static/*", s.handleStatic)
	e.POST("/api/convert", s.handleConvert)
	e.GET("/api/progress/:id", s.handleProgress)
	e.GET("/download/:id", s.handleDownload)
}

type indexData struct {
	Native   int
	Mappings int
	Padanan  int
	Parsial  int
	TidakAda int
}

func (s *Server) handleIndex(c echo.Context) error {
	padanan, parsial, tidakAda := 0, 0, 0
	for _, m := range s.Catalog.Mappings {
		switch m.Kind {
		case "padanan":
			padanan++
		case "parsial":
			parsial++
		case "tidak_ada":
			tidakAda++
		}
	}
	data := indexData{
		Native:   len(s.Catalog.Native),
		Mappings: len(s.Catalog.Mappings),
		Padanan:  padanan,
		Parsial:  parsial,
		TidakAda: tidakAda,
	}
	var buf bytes.Buffer
	if err := s.Templates.ExecuteTemplate(&buf, "index.html", data); err != nil {
		return c.String(http.StatusInternalServerError, "template error: "+err.Error())
	}
	return c.HTML(http.StatusOK, buf.String())
}

func (s *Server) handleStatic(c echo.Context) error {
	name := strings.TrimPrefix(c.Param("*"), "/")
	if name == "" || strings.Contains(name, "..") {
		return c.NoContent(http.StatusNotFound)
	}
	// Disk dulu, lalu embed.
	if data, err := os.ReadFile(filepath.Join("static", name)); err == nil {
		return c.Blob(http.StatusOK, contentType(name), data)
	}
	if data, ok := s.StaticFS[name]; ok {
		return c.Blob(http.StatusOK, contentType(name), data)
	}
	return c.NoContent(http.StatusNotFound)
}

func contentType(name string) string {
	switch {
	case strings.HasSuffix(name, ".css"):
		return "text/css; charset=utf-8"
	case strings.HasSuffix(name, ".js"):
		return "text/javascript; charset=utf-8"
	default:
		return "application/octet-stream"
	}
}

// handleConvert terima mode link atau upload file.
// Parsing multipart manual (multipart.Reader) supaya file tidak pernah
// ditulis ke disk oleh Go (ParseMultipartForm memakai file temp).
func (s *Server) handleConvert(c echo.Context) error {
	ct := c.Request().Header.Get("Content-Type")
	if !strings.HasPrefix(ct, "multipart/form-data") {
		return c.JSON(http.StatusBadRequest, map[string]string{"error": "kirim sebagai form multipart"})
	}
	mr, err := c.Request().MultipartReader()
	if err != nil {
		return c.JSON(http.StatusBadRequest, map[string]string{"error": "form tidak bisa dibaca"})
	}
	var mode, link, fileName string
	var fileData []byte
	for {
		part, err := mr.NextPart()
		if err == io.EOF {
			break
		}
		if err != nil {
			return c.JSON(http.StatusBadRequest, map[string]string{"error": "form tidak bisa dibaca: " + err.Error()})
		}
		name := part.FormName()
		if name == "file" {
			fileName = part.FileName()
			data, err := io.ReadAll(io.LimitReader(part, maxUploadBytes+1))
			if err != nil {
				return c.JSON(http.StatusBadRequest, map[string]string{"error": "file tidak bisa dibaca"})
			}
			if int64(len(data)) > maxUploadBytes {
				return c.JSON(http.StatusBadRequest, map[string]string{"error": "file terlalu besar (maks 100 MB)"})
			}
			fileData = data
		} else {
			text, _ := io.ReadAll(io.LimitReader(part, 1<<20))
			switch name {
			case "mode":
				mode = strings.TrimSpace(string(text))
			case "link":
				link = strings.TrimSpace(string(text))
			}
		}
		part.Close()
	}
	if mode != "link" && mode != "file" {
		return c.JSON(http.StatusBadRequest, map[string]string{"error": "mode harus link atau file"})
	}
	if mode == "link" && link == "" {
		return c.JSON(http.StatusBadRequest, map[string]string{"error": "tempel link Google Sheets dulu"})
	}
	if mode == "file" && len(fileData) == 0 {
		return c.JSON(http.StatusBadRequest, map[string]string{"error": "pilih file .xlsx atau .csv dulu"})
	}
	job := s.newJob()
	go s.runJob(job, mode, link, fileName, fileData)
	return c.JSON(http.StatusOK, map[string]string{"job_id": job.ID})
}

var sheetIDRe = regexp.MustCompile(`/d/([A-Za-z0-9_-]+)`)

func (s *Server) runJob(job *Job, mode, link, fileName string, fileData []byte) {
	defer func() {
		if r := recover(); r != nil {
			job.mu.Lock()
			job.Done = true
			job.Err = fmt.Sprintf("convert gagal: %v", r)
			job.mu.Unlock()
		}
	}()
	client := &http.Client{Timeout: 90 * time.Second}
	prog := func(pct int, stage string) { job.setProgress(pct, stage) }

	var input []byte
	var srcName, selfID string
	var csvRows int
	var isCSV bool

	if mode == "link" {
		job.setProgress(1, "Mengunduh spreadsheet")
		m := sheetIDRe.FindStringSubmatch(link)
		if m == nil {
			job.mu.Lock()
			job.Done = true
			job.Err = "link tidak dikenali sebagai link Google Sheets (cari /d/ID di URL)"
			job.mu.Unlock()
			return
		}
		selfID = m[1]
		srcName = "spreadsheet_" + selfID
		url := "https://docs.google.com/spreadsheets/d/" + selfID + "/export?format=xlsx"
		req, _ := http.NewRequest("GET", url, nil)
		req.Header.Set("User-Agent", "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0 Safari/537.36")
		resp, err := client.Do(req)
		if err != nil {
			job.mu.Lock()
			job.Done = true
			job.Err = "tidak bisa mengunduh spreadsheet: " + err.Error()
			job.mu.Unlock()
			return
		}
		defer resp.Body.Close()
		if resp.StatusCode != http.StatusOK {
			job.mu.Lock()
			job.Done = true
			job.Err = fmt.Sprintf("Google mengembalikan HTTP %d. Pastikan link spreadsheet bisa dibuka publik (Anyone with the link).", resp.StatusCode)
			job.mu.Unlock()
			return
		}
		data, err := io.ReadAll(io.LimitReader(resp.Body, maxUploadBytes+1))
		if err != nil {
			job.mu.Lock()
			job.Done = true
			job.Err = "gagal membaca spreadsheet: " + err.Error()
			job.mu.Unlock()
			return
		}
		if len(data) < 4 || string(data[:4]) != "PK\x03\x04" {
			job.mu.Lock()
			job.Done = true
			job.Err = "link tidak mengembalikan file spreadsheet (mungkin link tidak publik atau butuh login)"
			job.mu.Unlock()
			return
		}
		input = data
	} else {
		srcName = fileName
		if srcName == "" {
			srcName = "upload.xlsx"
		}
		if strings.HasSuffix(strings.ToLower(srcName), ".csv") || len(fileData) < 4 || string(fileData[:4]) != "PK\x03\x04" {
			if !strings.HasSuffix(strings.ToLower(srcName), ".csv") {
				job.mu.Lock()
				job.Done = true
				job.Err = "file bukan .xlsx atau .csv yang valid"
				job.mu.Unlock()
				return
			}
			isCSV = true
			job.setProgress(2, "Membaca file CSV")
			xlsxBytes, rows, err := converter.CSVToXLSX(fileData, srcName)
			if err != nil {
				job.mu.Lock()
				job.Done = true
				job.Err = err.Error()
				job.mu.Unlock()
				return
			}
			input = xlsxBytes
			csvRows = rows
		} else {
			input = fileData
		}
	}

	out, rep, err := converter.Convert(input, converter.Options{
		Catalog:    s.Catalog,
		SourceName: srcName,
		SelfID:     selfID,
		Progress:   prog,
		HTTPClient: client,
		MaxBytes:   maxUploadBytes,
	})
	if err != nil {
		job.mu.Lock()
		job.Done = true
		job.Err = err.Error()
		job.mu.Unlock()
		return
	}
	if isCSV {
		rep.Notes = append([]string{fmt.Sprintf("File CSV tidak mengandung rumus; %d baris data disalin apa adanya ke sheet Data.", csvRows)}, rep.Notes...)
	}
	job.mu.Lock()
	job.Done = true
	job.Percent = 100
	job.Stage = "Selesai"
	job.Output = out
	job.FileName = rep.FileName
	job.Report = rep
	job.mu.Unlock()
}

func (s *Server) handleProgress(c echo.Context) error {
	id := c.Param("id")
	v, ok := s.jobs.Load(id)
	if !ok {
		return c.JSON(http.StatusNotFound, map[string]string{"error": "job tidak ditemukan (mungkin sudah terhapus)"})
	}
	j := v.(*Job)
	j.mu.Lock()
	defer j.mu.Unlock()
	resp := map[string]interface{}{
		"percent":     j.Percent,
		"stage":       j.Stage,
		"eta_seconds": j.etaSeconds(),
		"done":        j.Done,
		"error":       j.Err,
	}
	if j.Done && j.Err == "" && j.Report != nil {
		resp["report"] = j.Report
		resp["download_url"] = "/download/" + j.ID
		resp["file_name"] = j.FileName
	}
	return c.JSON(http.StatusOK, resp)
}

// handleDownload kirim file hasil convert, lalu hapus dari memori.
func (s *Server) handleDownload(c echo.Context) error {
	id := c.Param("id")
	v, ok := s.jobs.Load(id)
	if !ok {
		return c.String(http.StatusGone, "File sudah terhapus dari server. Convert ulang untuk mengunduh lagi.")
	}
	j := v.(*Job)
	j.mu.Lock()
	if j.Output == nil {
		j.mu.Unlock()
		return c.String(http.StatusGone, "File sudah terhapus dari server. Convert ulang untuk mengunduh lagi.")
	}
	data := j.Output
	name := j.FileName
	// Hapus dari memori setelah diserahkan (server tidak menyimpan file).
	j.Output = nil
	j.mu.Unlock()
	c.Response().Header().Set("Content-Disposition", `attachment; filename="`+name+`"`)
	c.Response().Header().Set("Content-Type", "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet")
	return c.Blob(http.StatusOK, "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet", data)
}
