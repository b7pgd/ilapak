// Package converter: orkestrasi convert Google Sheets -> Excel (SharePoint).
// Semua pemrosesan di memori; tidak ada file yang ditulis ke disk.
package converter

import (
	"fmt"
	"io"
	"net/http"
	"sort"
	"strconv"
	"strings"
	"time"

	"sheetconv/engine"
	"sheetconv/xlsx"
)

// FuncStat statistik satu fungsi untuk laporan.
type FuncStat struct {
	Name      string `json:"name"`
	Count     int    `json:"count"`
	Example   string `json:"example"`
	Mechanism string `json:"mechanism,omitempty"`
	Excel     string `json:"excel,omitempty"`
}

// ImportTabInfo info satu blok data impor di sheet _IMPORT.
// Semua impor numpuk di SATU sheet tersembunyi (_IMPORT), bukan satu tab
// per impor, supaya jumlah sheet hasil convert tidak membengkak
// (54 sheet asli + 1 sheet data = 55, bar tab tetap 54).
type ImportTabInfo struct {
	Name     string `json:"name"`     // nama sheet impor ("_IMPORT")
	Location string `json:"location"` // blok di sheet impor, mis. "A1:H244"
	Source   string `json:"source"`
	Range    string `json:"range"`
	Rows     int    `json:"rows"`
	Cols     int    `json:"cols"`
}

// Report hasil analisa convert.
type Report struct {
	SheetsTotal      int             `json:"sheets_total"`
	SheetsConverted  int             `json:"sheets_converted"`
	FormulasTotal    int             `json:"formulas_total"`
	FormulasConverted int            `json:"formulas_converted"`
	Exact            []FuncStat      `json:"exact"`
	Padanan          []FuncStat      `json:"padanan"`
	Parsial          []FuncStat      `json:"parsial"`
	TidakAda         []FuncStat      `json:"tidak_ada"`
	ExactWeb         []FuncStat      `json:"exact_web"`
	TidakKenal       []FuncStat      `json:"tidak_kenal"`
	ImportTabs       []ImportTabInfo `json:"import_tabs"`
	SpillCleared     int             `json:"spill_cleared"`
	ValuesFrozen     int             `json:"values_frozen"`
	Frozen           []string        `json:"frozen,omitempty"` // sel yang dibekukan jadi nilai (maks 200)
	Notes            []string        `json:"notes"`
	FileName         string          `json:"file_name"`
	Warnings         int             `json:"warnings"`
}

// Options parameter convert.
type Options struct {
	Catalog    *engine.Catalog
	SourceName string // nama file sumber (untuk nama file output)
	SelfID     string // id spreadsheet sumber (link mode); "" kalau upload file
	Progress   func(pct int, stage string)
	HTTPClient *http.Client
	MaxBytes   int64
}

// Convert jalankan convert penuh. Mengembalikan bytes .xlsx hasil + laporan.
func Convert(input []byte, opts Options) ([]byte, *Report, error) {
	prog := opts.Progress
	if prog == nil {
		prog = func(int, string) {}
	}
	rep := &Report{FileName: outputName(opts.SourceName)}
	prog(3, "Membaca file")
	wb, err := xlsx.Open(input)
	if err != nil {
		return nil, nil, err
	}
	rep.SheetsTotal = len(wb.Sheets)

	// Catatan struktur file.
	if hasPivot(wb) {
		rep.Notes = append(rep.Notes, "File ini mengandung pivot table. Pivot dipertahankan apa adanya; tekan Refresh di Excel setelah dibuka supaya angkanya mengikuti data terbaru.")
	}
	if wb.HasPart("xl/externalLinks/externalLink1.xml") {
		rep.Notes = append(rep.Notes, "File ini mengandung tautan eksternal (external links). Tautan tidak diubah converter.")
	}

	prog(10, "Memindai rumus")
	cv := &converter{cat: opts.Catalog, wb: wb, rep: rep, selfID: opts.SelfID, client: opts.HTTPClient, maxBytes: opts.MaxBytes}
	// Nama sheet asli dicatat di sini (sebelum tab impor ditambah) untuk
	// deteksi "sumber = file ini sendiri" di resolveRange.
	cv.origSheets = make(map[string]bool, len(wb.Sheets))
	for _, sh := range wb.Sheets {
		cv.origSheets[sh.Name] = true
	}
	if cv.client == nil {
		cv.client = &http.Client{Timeout: 90 * time.Second}
	}
	if cv.maxBytes <= 0 {
		cv.maxBytes = 200 << 20
	}
	if err := cv.scan(prog); err != nil {
		return nil, nil, err
	}
	prog(20, "Mengunduh data impor")
	if err := cv.resolveAnchors(prog); err != nil {
		return nil, nil, err
	}
	prog(45, "Menulis rumus baru")
	if err := cv.applyEdits(); err != nil {
		return nil, nil, err
	}
	// Sheet impor tunggal (_IMPORT) baru ditambahkan di sini, sesudah semua
	// blok data terkumpul dari resolveAnchors.
	if err := cv.buildImportSheet(); err != nil {
		return nil, nil, err
	}
	prog(78, "Memeriksa hasil")
	cv.coverageCheck()
	prog(88, "Menyusun file output")
	wb.RemoveCalcChain()
	// JANGAN pakai fullCalcOnLoad: memaksa Excel Online menghitung ulang SEMUA
	// rumus saat membuka file (di file ini 848 ribu rumus) sehingga Excel Online
	// kehabisan waktu dan menolak membuka workbook ("Couldn't Open the Workbook").
	// Rumus baru tetap dihitung saat dibuka karena tidak punya nilai cache,
	// sedangkan rumus lain menampilkan nilai cache dari Google.
	out, err := wb.Bytes()
	if err != nil {
		return nil, nil, err
	}
	prog(100, "Selesai")
	cv.finalizeReport()
	return out, rep, nil
}

func hasPivot(wb *xlsx.Workbook) bool {
	for _, p := range wb.SortedPartNames() {
		if strings.HasPrefix(p, "xl/pivotTables/") {
			return true
		}
	}
	return false
}

func outputName(src string) string {
	base := src
	if i := strings.LastIndex(base, "."); i > 0 {
		base = base[:i]
	}
	if base == "" {
		base = "spreadsheet"
	}
	base = strings.ReplaceAll(base, " ", "_")
	return base + "_converted.xlsx"
}

// ---- struktur internal ----

type anchor struct {
	sheet    *xlsx.Sheet
	ref      string
	kind     string // importrange | query
	url      string
	rangeStr string
	query    string
	parts    []engine.QueryDataPart
	freeze   freezeVal // nilai cache sel (untuk dibekukan kalau gagal resolve)
	// hasil resolve
	newFormula string
	rectRows   int
	rectCols   int
	resolved   bool
}

// freezeVal nilai cache sebuah sel rumus, cukup untuk membekukannya jadi
// nilai (tanpa menyimpan seluruh struct Cell).
type freezeVal struct {
	value string // nilai tampilan (hasil shared string / inline)
	raw   string // nilai mentah XML
	typ   string // atribut t=
}

func freezeValOf(c *xlsx.Cell) freezeVal {
	return freezeVal{value: c.Value, raw: c.RawValue, typ: c.Type}
}

type rect struct {
	col, row, rows, cols int
}

func (r rect) contains(ref string) bool {
	c, row := refColRow(ref)
	return c >= r.col && c < r.col+r.cols && row >= r.row && row < r.row+r.rows
}

func refColRow(ref string) (int, int) {
	// Referensi absolut ($C$4) diperlakukan sama seperti C4.
	ref = strings.ReplaceAll(ref, "$", "")
	col, row := 0, 0
	i := 0
	for i < len(ref) && ((ref[i] >= 'A' && ref[i] <= 'Z') || (ref[i] >= 'a' && ref[i] <= 'z')) {
		i++
	}
	for _, ch := range strings.ToUpper(ref[:i]) {
		col = col*26 + int(ch-'A'+1)
	}
	row, _ = strconv.Atoi(ref[i:])
	return col, row
}

type converter struct {
	cat      *engine.Catalog
	wb       *xlsx.Workbook
	rep      *Report
	selfID   string
	client   *http.Client
	maxBytes int64

	origSheets  map[string]bool // nama sheet ASLI (sebelum tab impor ditambah)
	sheetMaxRow map[*xlsx.Sheet]int
	sheetEdits  map[*xlsx.Sheet]map[string]xlsx.CellEdit // rewrite rumus biasa, dicatat saat scan
	anchors     []*anchor
	spills      map[*xlsx.Sheet]map[string]freezeVal // sel COMPUTED_VALUE per sheet
	funcStats   map[string]*FuncStat
	funcTier    map[string]engine.Tier
	importTabs  map[string]importTabEntry // kunci "url|sheet|range" -> blok impor
	srcCache    map[string]*xlsx.Workbook

	// Sheet impor tunggal: semua data impor numpuk di satu sheet tersembunyi
	// (blok-blok bertumpuk vertikal, dipisah 1 baris kosong), bukan satu tab
	// per impor. Nama dipilih sekali di impor pertama.
	importSheetName string
	importBlocks    []importBlock
	importNextRow   int // baris kosong berikutnya di sheet impor (mulai 1)
	importMaxRow    int // baris terakhir yang terisi
	importMaxCol    int // kolom terbanyak di antara semua blok
	importWidths    []string // lebar kolom terlebar per posisi kolom
}

type importBlock struct {
	source   string // url spreadsheet sumber
	rangeStr string // range sumber, mis. "WASTE NC (calc)!S72:Z315"
	startRow int    // baris awal blok di sheet impor (1-based)
	rows     int
	cols     int
	grid     [][]xlsx.ImportCell
}

type importTabEntry struct {
	name string
	ref  string // mis. A1:H244
}

// scan baca semua sheet, kumpulkan rumus, anchor, dan statistik fungsi.
// Peta sel tiap sheet TIDAK disimpan (dibuang setelah diproses) supaya
// memori tetap kecil untuk workbook besar; yang disimpan hanya keputusan
// edit (sheetEdits), anchor, dan nilai cache spill/anchor.
func (cv *converter) scan(prog func(int, string)) error {
	cv.sheetMaxRow = make(map[*xlsx.Sheet]int)
	cv.sheetEdits = make(map[*xlsx.Sheet]map[string]xlsx.CellEdit)
	cv.spills = make(map[*xlsx.Sheet]map[string]freezeVal)
	cv.funcStats = make(map[string]*FuncStat)
	cv.funcTier = make(map[string]engine.Tier)
	cv.importTabs = make(map[string]importTabEntry)
	cv.srcCache = make(map[string]*xlsx.Workbook)

	for i, sh := range cv.wb.Sheets {
		prog(3+7*(i+1)/len(cv.wb.Sheets), "Memindai rumus ("+sh.Name+")")
		cells, err := cv.wb.ReadCells(sh)
		if err != nil {
			return fmt.Errorf("sheet %s: %w", sh.Name, err)
		}
		cv.sheetMaxRow[sh] = xlsx.MaxRow(cells)
		refs := sortedRefs(cells)
		for _, ref := range refs {
			c := cells[ref]
			if !c.IsFormula || c.Formula == "" {
				continue
			}
			cv.rep.FormulasTotal++
			payload, _, isDummy := engine.UnwrapDummy(c.Formula)
			if isDummy {
				cv.handleDummy(sh, c, payload)
				continue
			}
			cv.countFunctions(sh, ref, c.Formula)
			// Rewrite rumus biasa dicatat langsung di sini (bukan di applyEdits)
			// supaya peta sel bisa dibuang.
			if c.IsShared && !c.IsMaster {
				continue // master yang diedit, anggota ikut
			}
			if !engine.HasMappingFunc(c.Formula, cv.cat) {
				continue
			}
			newF, _ := engine.Rewrite(c.Formula, cv.cat)
			if newF != c.Formula {
				if cv.sheetEdits[sh] == nil {
					cv.sheetEdits[sh] = make(map[string]xlsx.CellEdit)
				}
				cv.sheetEdits[sh][ref] = xlsx.CellEdit{Kind: xlsx.EditFormula, Formula: newF}
				cv.rep.FormulasConverted++
			}
		}
		// Peta sel sheet ini dibuang; hanya maxRow + keputusan edit yang disimpan.
	}
	return nil
}

func sortedRefs(cells map[string]*xlsx.Cell) []string {
	refs := make([]string, 0, len(cells))
	for ref := range cells {
		refs = append(refs, ref)
	}
	sort.Slice(refs, func(a, b int) bool {
		ca, ra := refColRow(refs[a])
		cb, rb := refColRow(refs[b])
		if ra != rb {
			return ra < rb
		}
		return ca < cb
	})
	return refs
}

func (cv *converter) handleDummy(sh *xlsx.Sheet, c *xlsx.Cell, payload string) {
	if strings.Contains(payload, "COMPUTED_VALUE") {
		if cv.spills[sh] == nil {
			cv.spills[sh] = make(map[string]freezeVal)
		}
		cv.spills[sh][c.Ref] = freezeValOf(c)
		return
	}
	upper := strings.ToUpper(strings.TrimSpace(payload))
	switch {
	case strings.HasPrefix(upper, "IMPORTRANGE("):
		url, rangeStr, ok := engine.ParseImportRange(payload)
		if !ok {
			cv.rep.Notes = append(cv.rep.Notes, fmt.Sprintf("Sel %s!%s: IMPORTRANGE tidak bisa diurai, rumus dibiarkan apa adanya.", sh.Name, c.Ref))
			return
		}
		cv.anchors = append(cv.anchors, &anchor{sheet: sh, ref: c.Ref, kind: "importrange", url: url, rangeStr: rangeStr, freeze: freezeValOf(c)})
		cv.countOne(sh, c.Ref, "IMPORTRANGE")
	case strings.HasPrefix(upper, "QUERY("):
		data, query, ok := engine.ParseQuery(payload)
		if !ok {
			cv.rep.Notes = append(cv.rep.Notes, fmt.Sprintf("Sel %s!%s: QUERY tidak bisa diurai, rumus dibiarkan apa adanya.", sh.Name, c.Ref))
			return
		}
		parts, err := engine.ParseQueryData(data)
		if err != nil {
			cv.rep.Notes = append(cv.rep.Notes, fmt.Sprintf("Sel %s!%s: data QUERY tidak bisa diurai (%s), rumus dibiarkan apa adanya.", sh.Name, c.Ref, err))
			return
		}
		cv.anchors = append(cv.anchors, &anchor{sheet: sh, ref: c.Ref, kind: "query", query: query, parts: parts, freeze: freezeValOf(c)})
		cv.countOne(sh, c.Ref, "QUERY")
	default:
		trunc := payload
		if len(trunc) > 60 {
			trunc = trunc[:60] + "..."
		}
		cv.rep.Notes = append(cv.rep.Notes, fmt.Sprintf("Sel %s!%s: rumus Google tidak dikenali (%s), dibiarkan apa adanya.", sh.Name, c.Ref, trunc))
	}
}

// countFunctions hitung statistik fungsi untuk laporan.
func (cv *converter) countFunctions(sh *xlsx.Sheet, ref, formula string) {
	seen := make(map[string]bool)
	for _, name := range engine.ScanFunctions(formula) {
		if seen[name] {
			continue
		}
		seen[name] = true
		cv.countOne(sh, ref, name)
	}
}

// countOne hitung satu nama fungsi (untuk anchor IMPORTRANGE/QUERY yang
// namanya tidak muncul sebagai pemanggilan di rumus hasil).
func (cv *converter) countOne(sh *xlsx.Sheet, ref, name string) {
	tier := cv.cat.Classify(name)
	st, ok := cv.funcStats[name]
	if !ok {
		st = &FuncStat{Name: name, Example: sh.Name + "!" + ref}
		if m, isMap := cv.cat.Mappings[name]; isMap {
			st.Mechanism = m.Mekanisme
			st.Excel = m.Excel
		}
		cv.funcStats[name] = st
		cv.funcTier[name] = tier
	}
	st.Count++
}

// resolveAnchors unduh sumber impor dan bangun rumus baru untuk tiap anchor.
func (cv *converter) resolveAnchors(prog func(int, string)) error {
	total := len(cv.anchors)
	for i, a := range cv.anchors {
		prog(20+25*(i+1)/maxInt(total, 1), fmt.Sprintf("Mengunduh data impor (%d/%d)", i+1, total))
		if err := cv.resolveAnchor(a); err != nil {
			return err
		}
	}
	return nil
}

func maxInt(a, b int) int {
	if a > b {
		return a
	}
	return b
}

func (cv *converter) resolveAnchor(a *anchor) error {
	switch a.kind {
	case "importrange":
		lr, err := cv.resolveRange(a.url, a.rangeStr, a.sheet)
		if err != nil {
			// Sumber tidak bisa dijangkau: bekukan nilai cache, flag di laporan.
			cv.freezeAnchor(a, err)
			return nil
		}
		a.newFormula = blankGuard(engine.QuoteSheetName(lr.Sheet) + "!" + lr.Ref)
		rows, cols := rangeDims(lr.Ref)
		a.rectRows, a.rectCols = rows, cols
		a.resolved = true
	case "query":
		var ranges []engine.LocalRange
		for _, p := range a.parts {
			lr, err := cv.resolveRange(p.URL, p.RangeStr, a.sheet)
			if err != nil {
				cv.freezeAnchor(a, err)
				return nil
			}
			ranges = append(ranges, lr)
		}
		f, err := engine.BuildQueryFormula(ranges, a.query)
		if err != nil {
			cv.freezeAnchor(a, err)
			return nil
		}
		// Bungkus supaya sel kosong tetap kosong (bukan 0).
		f = "LET(r, " + f + ", IF(r=\"\", \"\", r))"
		a.newFormula = f
		rows, cols := 0, 0
		for _, r := range ranges {
			rr, cc := rangeDims(r.Ref)
			rows += rr
			if cc > cols {
				cols = cc
			}
		}
		a.rectRows, a.rectCols = rows, cols
		a.resolved = true
	}
	return nil
}

// freezeAnchor sumber tidak bisa dijangkau: sel jadi nilai cache + flag.
func (cv *converter) freezeAnchor(a *anchor, err error) {
	cv.rep.Notes = append(cv.rep.Notes, fmt.Sprintf("Sel %s!%s: sumber impor tidak bisa diunduh (%s). Sel dibiarkan sebagai nilai terakhir.", a.sheet.Name, a.ref, err))
}

// resolveRange ubah (url, rangeStr) jadi LocalRange.
// URL kosong atau id sama dengan file sendiri -> tab lokal (default: sheet
// tempat anchor berada, atau sheet pertama kalau tidak ada).
// Selain itu -> unduh sumber, buat tab impor.
func (cv *converter) resolveRange(url, rangeStr string, defaultSheet *xlsx.Sheet) (engine.LocalRange, error) {
	sheetName, ref := engine.ParseSheetRange(rangeStr)
	id := engine.SpreadsheetID(url)
	if url == "" || id == cv.selfID {
		return cv.localRange(sheetName, ref, defaultSheet)
	}
	// Cek apakah sumber ini sebenarnya file yang sama (upload file tanpa id,
	// atau id sama tapi SelfID kosong): bandingkan daftar nama sheet ASLI.
	src, err := cv.fetchSource(id)
	if err != nil {
		return engine.LocalRange{}, err
	}
	if cv.selfID == "" && cv.isSelfWorkbook(src) {
		return cv.localRange(sheetName, ref, defaultSheet)
	}
	return cv.importRange(src, url, sheetName, ref)
}

// localRange cari tab di workbook sendiri (nama persis, lalu normalisasi).
func (cv *converter) localRange(sheetName, ref string, defaultSheet *xlsx.Sheet) (engine.LocalRange, error) {
	var sh *xlsx.Sheet
	if sheetName == "" {
		sh = defaultSheet
		if sh == nil {
			sh = cv.wb.Sheets[0]
		}
	} else {
		sh = cv.wb.SheetByName(sheetName)
		if sh == nil {
			sh = cv.wb.FindSheetNormalized(engine.NormalizeSheetName(sheetName), engine.NormalizeSheetName)
		}
	}
	if sh == nil {
		return engine.LocalRange{}, fmt.Errorf("tab %q tidak ditemukan di file ini", sheetName)
	}
	bounded := engine.BoundRange(ref, cv.sheetMaxRow[sh])
	return engine.LocalRange{Sheet: sh.Name, Ref: bounded}, nil
}

// importRange ambil range dari workbook sumber, taruh sebagai blok baru di
// sheet impor tunggal (_IMPORT). Blok ditumpuk vertikal (1 baris kosong
// antar blok); anchor menunjuk ke bloknya, bukan ke tab sendiri-sendiri.
func (cv *converter) importRange(src *xlsx.Workbook, url, sheetName, ref string) (engine.LocalRange, error) {
	key := url + "|" + sheetName + "|" + ref
	if tab, ok := cv.importTabs[key]; ok {
		// Blok sudah dibuat untuk range yang sama: pakai lagi.
		return engine.LocalRange{Sheet: tab.name, Ref: tab.ref}, nil
	}
	var sh *xlsx.Sheet
	if sheetName == "" {
		sh = src.Sheets[0]
	} else {
		sh = src.SheetByName(sheetName)
		if sh == nil {
			sh = src.FindSheetNormalized(engine.NormalizeSheetName(sheetName), engine.NormalizeSheetName)
		}
	}
	if sh == nil {
		return engine.LocalRange{}, fmt.Errorf("tab %q tidak ditemukan di spreadsheet sumber", sheetName)
	}
	cells, err := src.ReadCells(sh)
	if err != nil {
		return engine.LocalRange{}, err
	}
	bounded := engine.BoundRange(ref, xlsx.MaxRow(cells))
	grid, rows, cols, err := extractGridFromCells(cells, bounded, src)
	if err != nil {
		return engine.LocalRange{}, err
	}
	// Petakan format angka sumber ke xf yang setara di workbook utama,
	// dan salin lebar kolom sumber supaya angka tidak jadi ###### / 1.11E+08.
	for r := range grid {
		for c := range grid[r] {
			if grid[r][c].NumFmtID != 0 {
				grid[r][c].Style = cv.wb.EnsureNumFmtStyle(grid[r][c].NumFmtID, grid[r][c].NumFmtCode)
			}
		}
	}
	var widths []string
	if srcXML, ok := src.SheetXML(sh); ok {
		c1, _, c2, _ := parseRange(bounded)
		widths = xlsx.ColWidths(srcXML, c1, c2)
	}
	if cv.importSheetName == "" {
		cv.importSheetName = cv.pickImportSheetName()
		cv.importNextRow = 1
	}
	// Alokasi blok: mulai di importNextRow, lalu sisakan 1 baris kosong.
	startRow := cv.importNextRow
	blockRef := "A" + strconv.Itoa(startRow) + ":" + xlsx.CellRef(cols, startRow+rows-1)
	cv.importBlocks = append(cv.importBlocks, importBlock{
		source: url, rangeStr: sheetName + "!" + ref,
		startRow: startRow, rows: rows, cols: cols, grid: grid,
	})
	cv.importNextRow = startRow + rows + 1
	if end := startRow + rows - 1; end > cv.importMaxRow {
		cv.importMaxRow = end
	}
	if cols > cv.importMaxCol {
		cv.importMaxCol = cols
	}
	// Lebar kolom: ambil yang terlebar per posisi kolom, supaya blok lain
	// tidak jadi ###### saat sheet impor dibuka.
	cv.importWidths = mergeWidths(cv.importWidths, widths)
	cv.importTabs[key] = importTabEntry{name: cv.importSheetName, ref: blockRef}
	cv.rep.ImportTabs = append(cv.rep.ImportTabs, ImportTabInfo{
		Name: cv.importSheetName, Location: blockRef,
		Source: url, Range: sheetName + "!" + ref, Rows: rows, Cols: cols,
	})
	return engine.LocalRange{Sheet: cv.importSheetName, Ref: blockRef}, nil
}

// pickImportSheetName cari nama sheet impor yang belum dipakai file asli.
func (cv *converter) pickImportSheetName() string {
	for _, name := range []string{"_IMPORT", "_IMPORT_DATA"} {
		if cv.wb.SheetByName(name) == nil {
			return name
		}
	}
	for i := 1; ; i++ {
		name := fmt.Sprintf("_IMPORT_%d", i)
		if cv.wb.SheetByName(name) == nil {
			return name
		}
	}
}

// mergeWidths gabung lebar kolom dua blok: per posisi kolom ambil yang
// terlebar (string kosong = tidak ada lebar eksplisit).
func mergeWidths(dst, src []string) []string {
	if len(src) > len(dst) {
		nd := make([]string, len(src))
		copy(nd, dst)
		dst = nd
	}
	for i, w := range src {
		if w == "" {
			continue
		}
		if dst[i] == "" {
			dst[i] = w
			continue
		}
		nw, err1 := strconv.ParseFloat(w, 64)
		ow, err2 := strconv.ParseFloat(dst[i], 64)
		if err1 == nil && err2 == nil && nw > ow {
			dst[i] = w
		}
	}
	return dst
}

// buildImportSheet gabung semua blok impor jadi satu sheet tersembunyi
// (_IMPORT) dan tambahkan ke workbook. Dipanggil sesudah resolveAnchors,
// saat semua blok sudah terkumpul.
func (cv *converter) buildImportSheet() error {
	if len(cv.importBlocks) == 0 {
		return nil
	}
	merged := make([][]xlsx.ImportCell, cv.importMaxRow)
	for i := range merged {
		merged[i] = make([]xlsx.ImportCell, cv.importMaxCol)
	}
	for _, b := range cv.importBlocks {
		for r := 0; r < b.rows; r++ {
			for c := 0; c < b.cols; c++ {
				merged[b.startRow-1+r][c] = b.grid[r][c]
			}
		}
	}
	sheetXML := xlsx.BuildImportSheetXML(merged, cv.importWidths)
	_, err := cv.wb.AddSheet(cv.importSheetName, sheetXML)
	return err
}

// fetchSource unduh spreadsheet sumber (cache hanya 1 sumber terakhir,
// supaya memori tidak membengkak; tab impor sudah didedup lewat importTabs
// sehingga sumber yang sama jarang perlu diunduh ulang).
func (cv *converter) fetchSource(id string) (*xlsx.Workbook, error) {
	if wb, ok := cv.srcCache[id]; ok {
		return wb, nil
	}
	url := "https://docs.google.com/spreadsheets/d/" + id + "/export?format=xlsx"
	req, err := http.NewRequest("GET", url, nil)
	if err != nil {
		return nil, err
	}
	req.Header.Set("User-Agent", "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0 Safari/537.36")
	resp, err := cv.client.Do(req)
	if err != nil {
		return nil, fmt.Errorf("tidak bisa mengunduh spreadsheet sumber: %w", err)
	}
	defer resp.Body.Close()
	if resp.StatusCode != http.StatusOK {
		return nil, fmt.Errorf("spreadsheet sumber mengembalikan HTTP %d (pastikan link bisa dibuka publik)", resp.StatusCode)
	}
	data, err := io.ReadAll(io.LimitReader(resp.Body, cv.maxBytes))
	if err != nil {
		return nil, err
	}
	if len(data) < 4 || string(data[:4]) != "PK\x03\x04" {
		return nil, fmt.Errorf("spreadsheet sumber bukan file spreadsheet (mungkin link tidak publik)")
	}
	wb, err := xlsx.Open(data)
	if err != nil {
		return nil, fmt.Errorf("spreadsheet sumber tidak bisa dibaca: %w", err)
	}
	// Buang sumber lama dari cache (hanya 1 yang disimpan).
	for k := range cv.srcCache {
		delete(cv.srcCache, k)
	}
	cv.srcCache[id] = wb
	return wb, nil
}

// isSelfWorkbook true kalau workbook sumber punya daftar sheet yang sama
// dengan file yang sedang dikonversi (daftar ASLI, sebelum tab impor).
func (cv *converter) isSelfWorkbook(src *xlsx.Workbook) bool {
	if len(src.Sheets) != len(cv.origSheets) {
		return false
	}
	for _, s := range src.Sheets {
		if !cv.origSheets[s.Name] {
			return false
		}
	}
	return true
}

// extractGridFromCells ambil nilai range dari sel yang sudah dibaca.
// src workbook sumber (dipakai untuk me-resolve format angka tiap sel).
func extractGridFromCells(cells map[string]*xlsx.Cell, ref string, src *xlsx.Workbook) ([][]xlsx.ImportCell, int, int, error) {
	minCol, minRow, maxCol, maxRow := parseRange(ref)
	if maxRow < minRow || maxCol < minCol {
		return nil, 0, 0, fmt.Errorf("range tidak valid: %s", ref)
	}
	rows := maxRow - minRow + 1
	cols := maxCol - minCol + 1
	grid := make([][]xlsx.ImportCell, rows)
	for r := 0; r < rows; r++ {
		grid[r] = make([]xlsx.ImportCell, cols)
		for c := 0; c < cols; c++ {
			cell := cells[xlsx.CellRef(minCol+c, minRow+r)]
			if cell == nil {
				continue
			}
			grid[r][c] = importCellFrom(cell, src)
		}
	}
	return grid, rows, cols, nil
}

func importCellFrom(cell *xlsx.Cell, src *xlsx.Workbook) xlsx.ImportCell {
	// Format angka di-resolve dari styles.xml SUMBER (numFmtId + formatCode),
	// BUKAN indeks style mentah: indeks itu per-workbook dan akan menunjuk
	// format yang salah di workbook utama (mis. angka biasa tampil 680.00%).
	ic := xlsx.ImportCell{Style: -1}
	if src != nil {
		ic.NumFmtID, ic.NumFmtCode = src.NumFmtForStyle(cell.Style)
	}
	switch cell.Type {
	case "b":
		ic.IsBool = true
		ic.Text = cell.RawValue
		return ic
	case "s", "str", "inlineStr":
		ic.Text = cell.Value
		return ic
	case "e":
		ic.Text = cell.RawValue
		return ic
	default:
		// Angka atau teks biasa.
		if cell.RawValue == "" {
			ic.Text = cell.Value
			return ic
		}
		if _, err := strconv.ParseFloat(strings.ReplaceAll(cell.RawValue, ",", "."), 64); err == nil {
			ic.IsNumber = true
			ic.Text = cell.RawValue
			return ic
		}
		ic.Text = cell.RawValue
		return ic
	}
}

// parseRange "A2:CB500" -> (minCol, minRow, maxCol, maxRow).
func parseRange(ref string) (int, int, int, int) {
	parts := strings.SplitN(ref, ":", 2)
	if len(parts) == 1 {
		c, r := refColRow(parts[0])
		if r == 0 {
			r = 1
		}
		return c, r, c, r
	}
	c1, r1 := refColRow(parts[0])
	c2, r2 := refColRow(parts[1])
	// Ujung terbuka (kolom saja, mis. CB) -> pakai baris 1..1 (akan dibatasi pemanggil).
	if r2 == 0 {
		r2 = r1
	}
	// Kolom polos tanpa nomor baris (mis. "B:C1214") berarti baris 1, bukan 0.
	// Dulu r1=0 lolos sehingga grid impor mulai dari baris 0 (kosong) dan
	// seluruh isi tergeser satu baris ke bawah.
	if r1 == 0 {
		r1 = 1
	}
	if c1 > c2 {
		c1, c2 = c2, c1
	}
	if r1 > r2 {
		r1, r2 = r2, r1
	}
	return c1, r1, c2, r2
}

// rangeDims jumlah baris dan kolom dari sebuah ref.
func rangeDims(ref string) (rows, cols int) {
	c1, r1, c2, r2 := parseRange(ref)
	return r2 - r1 + 1, c2 - c1 + 1
}

// blankGuard bungkus referensi range supaya sel kosong tetap kosong (bukan 0).
func blankGuard(rangeRef string) string {
	return "IF(" + rangeRef + "=\"\", \"\", " + rangeRef + ")"
}

// applyEdits tulis semua perubahan rumus ke sheet.
func (cv *converter) applyEdits() error {
	// Rectangle spill per sheet (dari anchor yang ter-resolve).
	rects := make(map[*xlsx.Sheet][]rect)
	for _, a := range cv.anchors {
		if !a.resolved {
			continue
		}
		c, row := refColRow(a.ref)
		rects[a.sheet] = append(rects[a.sheet], rect{col: c, row: row, rows: a.rectRows, cols: a.rectCols})
	}
	for _, sh := range cv.wb.Sheets {
		edits := make(map[string]xlsx.CellEdit)
		for ref, e := range cv.sheetEdits[sh] {
			edits[ref] = e
		}
		changed := len(edits) > 0
		// Anchor yang ter-resolve: rumus baru.
		for _, a := range cv.anchors {
			if a.sheet != sh || !a.resolved {
				continue
			}
			edits[a.ref] = xlsx.CellEdit{Kind: xlsx.EditFormula, Formula: a.newFormula}
			cv.rep.FormulasConverted++
			changed = true
		}
		// Anchor yang gagal resolve: bekukan jadi nilai cache.
		for _, a := range cv.anchors {
			if a.sheet != sh || a.resolved {
				continue
			}
			edits[a.ref] = freezeEditVal(a.freeze)
			cv.rep.ValuesFrozen++
			cv.noteFrozen(sh, a.ref)
			cv.rep.FormulasConverted++
			changed = true
		}
		// Spill cells: bersihkan yang di dalam rectangle, bekukan yang di luar.
		for ref, fv := range cv.spills[sh] {
			inside := false
			for _, r := range rects[sh] {
				if r.contains(ref) {
					inside = true
					break
				}
			}
			if inside {
				edits[ref] = xlsx.CellEdit{Kind: xlsx.EditClear}
				cv.rep.SpillCleared++
			} else {
				edits[ref] = freezeEditVal(fv)
				cv.rep.ValuesFrozen++
				cv.noteFrozen(sh, ref)
			}
			cv.rep.FormulasConverted++
			changed = true
		}
		if len(edits) == 0 {
			continue
		}
		if err := cv.wb.WriteSheetEdits(sh, edits); err != nil {
			return err
		}
		if changed {
			cv.rep.SheetsConverted++
		}
	}
	return nil
}

// noteFrozen catat sel yang dibekukan (maks 200 entri di laporan).
func (cv *converter) noteFrozen(sh *xlsx.Sheet, ref string) {
	if len(cv.rep.Frozen) < 200 {
		cv.rep.Frozen = append(cv.rep.Frozen, sh.Name+"!"+ref)
	}
}

// freezeEditVal ubah sel rumus jadi nilai cache-nya.
func freezeEditVal(fv freezeVal) xlsx.CellEdit {
	if fv.typ == "s" || fv.typ == "str" || fv.typ == "inlineStr" {
		return xlsx.CellEdit{Kind: xlsx.EditValue, Value: fv.value, VType: "str"}
	}
	if fv.raw != "" {
		if _, err := strconv.ParseFloat(fv.raw, 64); err == nil {
			return xlsx.CellEdit{Kind: xlsx.EditValue, Value: fv.raw}
		}
		return xlsx.CellEdit{Kind: xlsx.EditValue, Value: fv.raw, VType: "str"}
	}
	return xlsx.CellEdit{Kind: xlsx.EditClear}
}

// coverageCheck pastikan tidak ada fungsi tak dikenal yang lolos tanpa flag.
// Semua nama fungsi di rumus hasil dicek ke katalog; yang tidak dikenal
// masuk ke laporan (bagian merah).
func (cv *converter) coverageCheck() {
	seen := make(map[string]bool)
	// Kumpulkan dari statistik (sudah mencakup semua rumus asli) + nama baru
	// dari rewrite (TEXTJOIN, VSTACK, FILTER, TAKE, dst. — semuanya native).
	for name := range cv.funcStats {
		seen[name] = true
	}
	// Periksa rumus hasil anchor: fungsi di dalamnya harus native.
	for _, a := range cv.anchors {
		if !a.resolved {
			continue
		}
		for _, name := range engine.ScanFunctions(a.newFormula) {
			if seen[name] {
				continue
			}
			seen[name] = true
			tier := cv.cat.Classify(name)
			if tier == engine.TierTidakKenal {
				st := &FuncStat{Name: name, Example: a.sheet.Name + "!" + a.ref}
				cv.funcStats[name] = st
				cv.funcTier[name] = tier
			}
		}
	}
}

// finalizeReport susun daftar tier terurut jumlah terbanyak dulu.
func (cv *converter) finalizeReport() {
	byTier := func(t engine.Tier) []FuncStat {
		var out []FuncStat
		for name, st := range cv.funcStats {
			if cv.funcTier[name] == t {
				out = append(out, *st)
			}
		}
		sort.Slice(out, func(i, j int) bool { return out[i].Count > out[j].Count })
		return out
	}
	cv.rep.Exact = byTier(engine.TierExact)
	cv.rep.Padanan = byTier(engine.TierPadanan)
	cv.rep.Parsial = byTier(engine.TierParsial)
	cv.rep.TidakAda = byTier(engine.TierTidakAda)
	cv.rep.ExactWeb = byTier(engine.TierExactWeb)
	cv.rep.TidakKenal = byTier(engine.TierTidakKenal)
	if cv.rep.Exact == nil {
		cv.rep.Exact = []FuncStat{}
	}
	if cv.rep.Padanan == nil {
		cv.rep.Padanan = []FuncStat{}
	}
	if cv.rep.Parsial == nil {
		cv.rep.Parsial = []FuncStat{}
	}
	if cv.rep.TidakAda == nil {
		cv.rep.TidakAda = []FuncStat{}
	}
	if cv.rep.ExactWeb == nil {
		cv.rep.ExactWeb = []FuncStat{}
	}
	if cv.rep.TidakKenal == nil {
		cv.rep.TidakKenal = []FuncStat{}
	}
	if cv.rep.ImportTabs == nil {
		cv.rep.ImportTabs = []ImportTabInfo{}
	}
	if cv.rep.Notes == nil {
		cv.rep.Notes = []string{}
	}
	cv.rep.Warnings = len(cv.rep.TidakAda) + len(cv.rep.Parsial) + len(cv.rep.TidakKenal) + cv.rep.ValuesFrozen
}

