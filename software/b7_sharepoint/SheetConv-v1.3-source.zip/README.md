# SheetConv

Konverter Google Sheets ke Excel (untuk file yang disimpan di SharePoint /
OneDrive). Rumus tetap rumus, tidak diubah jadi nilai.

## Menjalankan

Butuh Go 1.21+. Dari folder project:

```sh
go run .                # jalan di http://localhost:2030
```

Port bisa diubah lewat environment variable `PORT`:

```sh
PORT=8080 go run .
```

File `formulas.json`, folder `template/` dan folder `static/` harus berada di
folder yang sama dengan `main.go`. Kalau file `formulas.json` ada di sebelah
project, katalog yang dipakai adalah file itu (jadi pemetaan rumus bisa diedit
tanpa rebuild; restart server sesudah edit). Kalau tidak ada, dipakai katalog
yang tertanam di dalam binary.

Untuk membuat binary sendiri:

```sh
go build -o sheetconv .                   # Linux / macOS
GOOS=windows go build -o sheetconv.exe .  # Windows
```

## Cara pakai

Satu halaman, dua cara import:

1. **Link Google Sheets** - tempel link spreadsheet publik (Anyone with the
   link). File diambil dari link, dikonversi, lalu bisa diunduh.
2. **Upload File** - upload file `.xlsx` (rumus ikut dikonversi) atau `.csv`
   (data saja, maks 100 MB).

Selama convert ada bar loading dengan persen dan perkiraan sisa waktu.
Sesudah selesai muncul panel hasil analisa dan tombol unduh. File hasil
convert otomatis terhapus dari server setelah diunduh, atau 10 menit setelah
selesai. Refresh halaman juga menghilangkan file. **Server tidak pernah
menyimpan file ke disk** - semua pemrosesan di memori.

Hasil convert adalah file `.xlsx` yang bisa di-upload ke SharePoint lalu
dibuka lewat File > Open (Excel Online).

## Cara kerja convert

- **Rumus native Excel** (IF, VLOOKUP, SUMIFS, dan 500+ fungsi lainnya)
  dipakai apa adanya, tanpa diubah.
- **QUERY** diubah jadi rumus hidup `FILTER(VSTACK(...))` yang menunjuk ke
  tab-tab lokal. Sel spill lama dibersihkan supaya spill Excel bisa jalan.
- **IMPORTRANGE** diubah jadi referensi ke blok data di sheet impor
  tersembunyi (`_IMPORT`) yang berisi data dari spreadsheet sumber, diambil
  sekali saat convert. Hanya data mentah hasil impor yang jadi nilai; semua
  rumus pengolah (VLOOKUP, SUMIFS, dan lain-lain) tetap hidup sebagai rumus.
  Semua blok impor numpuk di SATU sheet `_IMPORT` (tersembunyi) supaya jumlah
  sheet tidak membengkak: sheet asli tetap sama, ditambah 1 sheet data.
- **IMPORTRANGE yang menunjuk ke spreadsheet yang sama** langsung diarahkan
  ke tab lokal, tanpa tab impor dan tanpa unduh.
- **Sel kosong tetap kosong**, bukan 0: rumus impor dibungkus supaya sel
  kosong dari sumber tidak berubah jadi angka 0 di Excel.
- **Pivot table, Excel table, dan semua bagian lain file** dipertahankan apa
  adanya (hanya sel yang berubah yang disentuh). Sesudah dibuka di Excel,
  tekan Refresh pada pivot supaya angkanya mengikuti data terbaru.
- **Tidak ada hardcoding**: perhitungan tidak pernah diubah jadi nilai
  statis. Satu-satunya pengecualian adalah sel yang sumber impornya tidak
  bisa diunduh sama sekali (misalnya link tidak publik) - sel itu dibiarkan
  sebagai nilai terakhir dan dicatat jelas di laporan.

## Panel hasil analisa

- **Rumus dengan padanan persis** - fungsi yang sama persis di Excel.
- **Rumus dengan padanan** - fungsi Google yang tidak ada persis di Excel,
  diganti padanan beserta penjelasan mekanismenya.
- **Rumus dengan padanan sebagian** - padanan yang tidak 100% sama; cek
  hasilnya sebelum dipakai.
- **Rumus tanpa padanan** (kotak merah) - fungsi yang tidak punya padanan di
  Excel dan dibiarkan apa adanya; sel yang memakainya mungkin menampilkan
  error di Excel.
- **Rumus tidak dikenali** - fungsi yang tidak ada di katalog; laporkan ke
  pengembang supaya ditambahkan pemetaannya.
- **Sheet tambahan (_IMPORT)** - 1 sheet tersembunyi berisi semua blok data
  hasil impor (satu blok per IMPORTRANGE, lengkap dengan sumber dan
  ukurannya). Sheet asli tidak berubah jumlahnya; sheet ini hanya tempat
  data, bukan sheet kerja. Untuk melihatnya, klik kanan tab mana pun lalu
  Unhide.
- **Sel yang dibekukan jadi nilai** - daftar sel yang terpaksa dibekukan
  (hanya kalau sumber impor tidak bisa diunduh).

## Katalog rumus

Katalog ada di `formulas.json` (bisa diedit):

- **519 fungsi Excel native** (daftar resmi Microsoft).
- **50 pemetaan** Google Sheets ke Excel: 44 padanan, 4 parsial
  (GOOGLEFINANCE, ISDATE, ISEMAIL, ISURL), 2 tanpa padanan rumus (SPARKLINE,
  AI).
- **8 fungsi native yang tidak jalan di Excel Online**: CELL, ENCODEURL,
  FILTERXML, INFO, WEBSERVICE, CALL, REGISTER.ID, RTD. Fungsi ini di-flag
  di laporan, bukan diklaim bisa.

Urutan pengecekan: pemetaan dulu, lalu fungsi native, lalu flag merah kalau
tidak dikenal.

## Batasan yang jujur

- **Tidak ada auto-update.** Data hasil convert tidak berubah sendiri kalau
  Google Sheet sumber berubah. Ini memang alat migrasi: sesudah migrasi,
  file hasil convert di SharePoint yang jadi sumber kebenaran baru. Auto-update
  butuh sumber di SharePoint + Power Query, itu urusan fase berikutnya.
- **Pivot table tidak dihitung ulang otomatis** oleh converter; tekan Refresh
  di Excel sesudah dibuka.
- **LibreOffice tidak bisa menghitung rumus modern** (LET, VSTACK, FILTER,
  UNIQUE, SORT). File hasil convert tetap bisa dibuka di LibreOffice, tapi
  rumus-rumus itu menampilkan error sampai dibuka di Excel. Verifikasi
  perhitungan akhir sebaiknya di Excel / Excel Online.
- **Excel Online dan file besar.** File hasil convert sengaja TIDAK memakai
  `fullCalcOnLoad` (tanda "hitung ulang semua rumus saat dibuka"). Tanda itu
  membuat Excel Online menghitung ulang ratusan ribu rumus saat membuka file
  sehingga kehabisan waktu dan menolak membuka workbook ("Couldn't Open the
  Workbook"). Tanpa tanda itu, Excel Online membuka file dengan nilai cache
  dan hanya menghitung rumus baru yang belum punya nilai cache.

## Build dari source

Butuh Go 1.21+.

```sh
go run .                                 # langsung jalan
go build -o sheetconv .                  # Linux / macOS
GOOS=windows go build -o sheetconv.exe . # Windows
```

## Perubahan v1.3

- **Semua data impor numpuk di 1 sheet tersembunyi (`_IMPORT`).** Sebelumnya
  tiap IMPORTRANGE dibuatkan tab sendiri (`_IMPORT_1` sampai `_IMPORT_23`)
  sehingga file 54 sheet jadi 77 sheet. Sekarang blok-blok impor ditumpuk
  vertikal di satu sheet `_IMPORT` (tersembunyi): total 55 sheet (54 asli +
  1 data), bar tab tetap 54 seperti aslinya. Panel hasil convert menjelaskan
  sheet tambahan ini.
- **Format angka, lebar kolom, dan tab tersembunyi** dari v1.2 tetap
  dipertahankan (lihat bawah).

## Perubahan v1.2

- **Format angka tab impor dipetakan dengan benar.** Sebelumnya indeks style
  sumber disalin mentah sehingga angka jam 6.8 tampil jadi 680.00%.
  Sekarang format angka sumber (persen, tanggal, desimal) dicari padanannya
  di workbook utama.
- **Lebar kolom sumber ikut tersalin** ke tab impor, jadi tidak ada lagi
  kolom `######` atau angka yang berubah jadi notasi ilmiah.
- **Tab impor disembunyikan** (hidden) supaya bar tab tetap rapi; bisa
  dimunculkan lagi lewat Unhide.
- **ID relasi (rId) tab impor tidak lagi tabrakan** dengan pivotCache /
  slicerCache. Sebelumnya 8 tab impor pertama bisa terbaca kosong di
  beberapa pembaca.
- **Range kolom polos (mis. `B:C`) tidak lagi tergeser satu baris.** Sebelumnya
  baris pertama tab impor kosong dan seluruh isi turun satu baris.

## Struktur project

```
main.go              entry point, load katalog + template, jalan di :2030
formulas.json        katalog fungsi + pemetaan (bisa diedit)
template/index.html  halaman utama (1 halaman)
static/style.css     tampilan putih-biru
engine/              katalog, tokenizer, rewrite rumus, QUERY, IMPORTRANGE
xlsx/                baca/tulis file .xlsx lewat edit XML (pivot tetap utuh)
converter/           orkestrasi convert + laporan
web/                 server HTTP (Echo), job di memori, auto-hapus
```
