<?php

// memanggil library FPDF
require('library/fpdf.php');
include '../../koneksi.php';
session_start();
 
// intance object dan memberikan pengaturan halaman PDF
$pdf=new FPDF('L','mm','A4');
$pdf->SetMargins(8, 8, 1, 1);
class PDF extends FPDF
{
    function Footer()
    {
        $this->SetFont('Arial', 'I', 8);
        
        $this->SetY(-55);
        $this->Cell(0,10,'Keterangan :',"0",0,'L');
        
        $this->SetY(-40);
        $this->Cell(0,10,'*Lakukan pencatatan setiap hari pertama tiap minggu',"0",0,'L');
        
        $this->SetY(-35);
        $this->Cell(280,10,'WI-PR-PR-8001.03',"0",0,'R');
        
        $this->SetY(-30);
        $this->Cell(280, 10, 'Halaman ' . $this->PageNo() . '/{nb}', 0, 0, 'R');
        
        $this->SetY(-30);
        $this->Cell(0,10,'Dokumen ini telah ditandatangani secara elektronik menggunakan aplikasi FUPD Online dengan melampirkan lembar',0,0,'C');
        
        $this->SetY(-25);
        $this->Cell(0,10,'persetujuan elektronik milik PT. Bintang Toedjoe (A Kalbe Company)',0,0,'C');
        
        $this->SetY(-15);
        $this->Cell(132,10,'',0,0,'C');
        $this->SetTextColor(255, 0, 0); // Set warna tulisan menjadi merah (RGB: 255, 0, 0)
        $this->SetDrawColor(255, 0, 0); // Set warna border menjadi merah (RGB: 255, 0, 0)
        $this->Cell(16,7,'Approved',1,0,'C');
        // Mengatur zona waktu menjadi Waktu Indonesia Barat (WIB)
        date_default_timezone_set('Asia/Jakarta');
        // Mendapatkan tanggal dan waktu saat ini
        $currentDateTime = date('Y-m-d H:i:s');
        // Menampilkan informasi pencetakan
        $this->SetTextColor(0, 0, 0);
        $this->Cell(132, 10, 'Printed by: ' . $_SESSION['nama'] . ' on ' . $currentDateTime, 0, 0, 'R');
    }
    //-------------------------

    function Header(){
        $this->SetFont('Times','B',16);
        $this->Cell(50,20,'',"1",0,'C');
        $this->Image('../../img/Bintang-Toedjo-removebg-preview (1).png',-7,-3,80,40,'PNG','#');
        $this->Cell(230,20,'FORMULIR INSPEKSI KEBERSIHAN PERSONEL, RUANGAN DAN PERALATAN',"1",0,'C');
        $this->Cell(10,20,'',0,1);
        $this->SetFont('Times','',12);
        $this->Cell(15,10,'Lokasi : ',0,0);

        //---------------------------------------untuk isi site pada bagian header
        $bulan = "";
        $tahun = "";
        include '../../koneksi.php';
        if (isset($_GET['bulan']) && isset($_GET['tahun'])&& isset($_GET['lokasi'])) {
            $bulan = $_GET['bulan'];
            $tahun = $_GET['tahun'];
            $lokasi = $_GET['lokasi'];
            $data = mysqli_query($conn, "SELECT lokasi FROM tb_pr_inspeksi WHERE MONTH(tgl)='$bulan' AND YEAR(tgl)='$tahun' AND lokasi='$lokasi' LIMIT 1");
        } else {
            // Jika tidak ada bulan dan tahun yang diset, atur default
            $bulan = date('m');
            $tahun = date('Y');
            $data = mysqli_query($conn, "SELECT lokasi FROM tb_pr_inspeksi WHERE MONTH(tgl)='$bulan' AND YEAR(tgl)='$tahun' AND lokasi='$lokasi' LIMIT 0");
        }

        if ($data) {
            while ($d = mysqli_fetch_array($data)) {
                // Mengambil data tanggal
                $lokasi = $d['lokasi'];
                // Menampilkan bulan
                $this->Cell(25, 10, $lokasi, 0, 0);
            }
        }
        //---------------------------------------untuk isi site pada bagian header
        $this->Cell(30,10,'',0,0);
        $this->Cell(15,10,'Bagian : Produksi Liquid ',0,0);
        $this->Cell(66,10,'',0,0);
        $this->Cell(33,10,'Bulan dan Tahun :',0,0);
        //---------------------------------------untuk isi bulan dan tanggal pada bagian header
        $bulan = "";
        $tahun = "";
        if (isset($_GET['bulan']) && isset($_GET['tahun'])) {
            $bulan = $_GET['bulan'];
            $tahun = $_GET['tahun'];
            $data = mysqli_query($conn, "SELECT * FROM tb_pr_inspeksi WHERE MONTH(tgl)='$bulan' AND YEAR(tgl)='$tahun' AND lokasi='$lokasi' LIMIT 1");
        } else {
            // Jika tidak ada bulan dan tahun yang diset, atur default
            $bulan = date('m');
            $tahun = date('Y');
            $data = mysqli_query($conn, "SELECT * FROM tb_pr_inspeksi WHERE MONTH(tgl)='$bulan' AND YEAR(tgl)='$tahun' AND lokasi='$lokasi' LIMIT 0");
        }

        if ($data) {
            while ($d = mysqli_fetch_array($data)) {
                // Mengambil data tanggal
                $tgl = $d['tgl'];

                // Mengubah tanggal menjadi format bulan (MM)
                $bulan_format = date('F Y', strtotime($tgl));

                // Menampilkan bulan
                $this->Cell(60, 10, $bulan_format, 0, 0);
            }
        }
        //---------------------------------------untuk isi bulan dan tanggal pada bagian header
        $this->Cell(5,10,'',0,0);
        $this->Cell(40,10,'Site : Pulogadung ',0,0);

        $this->Cell(10,10,'',0,1);
        $this->SetFont('Times','',10);

        $column_width = [
            "23", "16", "8", "25", "8", "25", "8", "25", "46", "48",
            "48"
        ];

        $cekitem = $column_width[2] + $column_width[3] + $column_width[4] + $column_width[5] + $column_width[6] + $column_width[7];
        

            //first row
            $this->Cell($column_width[0], 14, 'Tanggal', "1", 0, 'C', false);
            $this->Cell($column_width[1], 14, 'Shif', "1", 0, 'C', false);
            $this->Cell($cekitem, 7, 'Check Item', "1", 0, 'C', false);
            $this->MultiCell(48,14,'Lokasi','1','C',false);
            $this->SetY(38);
            $this->Cell(186, 7, '', 0, 0, 'C', false);
            $this->MultiCell(47,14,'Pelaksana','1','C',false);
            $this->SetY(38);
            $this->Cell(233, 7, '', 0, 0, 'C', false); //nambah  + 47
            $this->MultiCell(47,14,'Pemeriksa','1','C',false);
            $this->SetY(45);
            $this->Cell(39, 7, '', 0, 0, 'C', false);
            $this->Cell(16.5, 7, 'Personel', 1, 0, 'C', false);
            $this->Cell(16.5, 7, 'Ket', 1, 0, 'C', false);
            $this->Cell(16.5, 7, 'Personel', 1, 0, 'C', false);
            $this->Cell(16.5, 7, 'Ket', 1, 0, 'C', false);
            $this->Cell(16.5, 7, 'Personel', 1, 0, 'C', false);
            $this->Cell(16.5, 7, 'Ket', 1, 0, 'C', false);
        }
}

$x = 0;
$y = 0;
$pdf = new PDF('L', 'mm', 'A4');
$pdf->SetMargins(8, 8, 1, 1);
$pdf->SetFont('Times', '', 12);
$pdf->AliasNbPages();
$pdf->SetAutoPageBreak(true);
$pdf->SetAutoPageBreak(true, 30);

$pdf->AddPage();
 



// class PDF extends FPDF{
    
    // }
$pdf->Cell(10,7,'',0,1);
$pdf->SetFont('Times','',10);


if(isset($_GET['bulan']) && isset($_GET['tahun'])&& isset($_GET['lokasi']) ){
    $bulan = $_GET['bulan'];
    $tahun = $_GET['tahun'];
    $lokasi = $_GET['lokasi'];
    $data = mysqli_query($conn,"select * from tb_pr_inspeksi where month(tgl)='$bulan' and year(tgl)='$tahun' and lokasi='$lokasi'");

while($d = mysqli_fetch_array($data)){
    $pdf->SetFont('Times','',12);  
    $pdf->Cell(23,6, $d['tgl'],1,0,'C');
    $pdf->Cell(16,6, $d['shift'],1,0,'C');
    $pdf->Cell(16.5,6, $d['cek_personel'],1,0,'C');
    $pdf->Cell(16.5,6, $d['ket_personel'],1,0,'C');
    $pdf->Cell(16.5,6, $d['cek_ruangan'],1,0,'C');
    $pdf->Cell(16.5,6, $d['ket_ruangan'],1,0,'C');
    $pdf->Cell(16.5,6, $d['cek_peralatan'],1,0,'C');
    $pdf->Cell(16.5,6, $d['ket_peralatan'],1,0,'C');
    $pdf->Cell(48,6, $d['lokasi'],1,0,'C');
    $pdf->Cell(47,6, $d['paraf'],1,0,'C');
    $pdf->Cell(47,6, $d['paraf_spv'],1,1,'C');
  
    
    if ($pdf->GetY() > 150) { 
        
        $pdf->AddPage();
        $pdf->Cell(0,7,'',0,1);
    }
}


}


//---------------------------------------untuk cell tanda tangan supervisor/maager
$pdf->AddPage();
$pdf->SetY(-110);
$pdf->Ln();
$pdf->Ln();
$pdf->Ln();
$pdf->Cell(140,7,'Identitas paraf user :',0,0,'L');
$pdf->Ln();
        if(isset($_GET['bulan']) && isset($_GET['tahun'])) {
            $bulan = $_GET['bulan'];
            $tahun = $_GET['tahun'];
            $nmr=1;
            $username_id = mysqli_query($conn,"SELECT DISTINCT paraf FROM tb_pr_inspeksi WHERE MONTH(tgl)='$bulan' AND YEAR(tgl)='$tahun'AND lokasi='$lokasi'");
            while($d = mysqli_fetch_array($username_id)) {
                
                $paraf_id = $d['paraf'];
                $pdf->Cell(5,7,$nmr++ . ' )',0,0,'L');
                $pdf->Cell(20,7,$paraf_id,0,0,'L');
                
                $fullname_id = mysqli_query($conn,"SELECT nama FROM tb_admin_user WHERE username='$paraf_id'");
                while($dd = mysqli_fetch_array($fullname_id)) {
                    $fullname = $dd['nama'];
                    $pdf->Cell(100,7,': ' . $fullname,0,0,'L');
                    $pdf->Ln();
                    
                }
            }
        }
 
$pdf->Output();
 
?>