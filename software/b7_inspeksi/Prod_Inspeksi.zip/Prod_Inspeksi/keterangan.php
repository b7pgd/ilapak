<?php
    session_start();
    include '../../koneksi.php';
    // Periksa apakah parameter missing_shift ada di URL
    if (isset($_GET['missing_shift'])) {
        $missing_shift = $_GET['missing_shift'];
        $lokasi = $_GET['lokasi'];
        $lastdate = $_GET['last_date'];

        $date = strtotime($lastdate);
        $date_option = date('Y-m-d', $date); 

        // Pastikan parameter missing_shift adalah angka dan bernilai 2
        // if (is_numeric($missing_shift) && $missing_shift == 2) {
        //     $missing_shift;
        // } else if (is_numeric($missing_shift) && $missing_shift == 3) {
        //     $missing_shift;
        // } else {
        //     "Parameter shift yang hilang tidak valid.";
        // }
    } else {
        "Tidak ada shift yang hilang yang dilaporkan.";
    }
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link href="./css/jquery.signaturepad.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css">
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Roboto&family=Roboto+Condensed&display=swap" rel="stylesheet">
    <style>
        .page {
            width: 75%;
            min-height: 100%;
            padding: 5mm;
            margin: 5mm auto;
            border: 1px #D3D3D3 solid;
            border-radius: 5px;
            background: white;
            box-shadow: 0 0 5px rgba(0, 0, 0, 0.1);
        }
        .label-input {
            width: 10%;
            padding-bottom: 8px;
            padding-top: 6px;
            margin-bottom: 15px;
            box-sizing: border-box;
            float: left;
        }
        .levelbtn {
            width: 85%;
            padding: 8px;
            margin-bottom: 15px;
            box-sizing: border-box;
            border: 1px solid #2a5783;
            border-radius: 1px;
            float: right;
        }
        .topnav-right {
            padding: 12px 17px;
            float: right;
            background-color: #2a5783;
            color: #fff;
            border-radius: 2px;
        }
    </style>
</head>
<body>
    <div class="topnav-right">
        <a href="../../Home.php" class="openbtn; fas fa-home" style="text-decoration:none; color:white"></a>
    </div>
    <div class="page">
        <form action="" method="post">
            <h2><center><strong>PILIH KETERANGAN</strong></center></h2>
            
            <label for="ket" class="label-input">KETERANGAN</label>
            <select name="ket" id="ket" class="levelbtn" required>
                <option value="" disabled selected>Pilih Keterangan disini</option>
                <option>Hari libur</option>
                <option>OFF</option>
                <option>Lupa isi</option>
            </select>

            <label for="tanggal" class="label-input">TANGGAL</label>
            <input name="tanggal" id="tanggal" class="levelbtn" value="<?php echo $date_option?>" readonly required>
            <label for="lokasi" class="label-input">LOKASI</label>
            <input name="lokasi" id="lokasi" class="levelbtn"  value="<?php echo $lokasi;  ?>" readonly required>
            <label for="shift" class="label-input">SHIFT</label>
            <input name="shift" id="shift" class="levelbtn"  value="<?php echo $missing_shift;  ?>" readonly required>
            <input style="width:100%" type="submit" name="save" value="save">
            

        </form>

        <?php
            if (isset($_POST["save"])) {
                $ket = $_POST['ket'];
                $date_option = $_POST['tanggal'];
                $missing_shifts = $_POST['shift'];
                $lokasi = $_POST['lokasi'];

                $user=$_SESSION['username'];
                
                $query_insert = 
                    "INSERT INTO tb_pr_inspeksi VALUES 
                    (null, '$lokasi', '$missing_shifts', '-', '-', '-', 
                    '$ket', '$ket','$ket', '$date_option', '$user', '', 
                    '0000-00-00', '0000-00-00', 0, '0000-00-00 00:00:00' )";

                mysqli_query($conn, $query_insert);
                // echo $query_insert;
                echo "<script>
                        alert('Data Lengkap! Terima Kasih!');
                        window.location.href='selectlokasi.php';
                    </script>";
                exit();
            }
        ?>
    </div>
</body>
</html>
