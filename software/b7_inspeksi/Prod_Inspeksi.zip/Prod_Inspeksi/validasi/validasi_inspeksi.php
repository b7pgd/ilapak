<?php
    session_start();
    include '../../../koneksi.php';
?>
<!DOCTYPE html>
<html>
    <head>
    <!-- <meta name="viewport" content="width=device-width, initial-scale=1"> -->
    <!-- Stylesheet Font Awesome -->
    <!-- <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css"> -->
    
    <!-- External CSS -->
    <link rel="stylesheet" href="styling.css">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <!-- Stylesheet Font Awesome -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css">
    <!-- Font Roboto -->

    <!-- <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.0.0/dist/css/bootstrap.min.css"> -->

    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Roboto&family=Roboto+Condensed&display=swap" rel="stylesheet">
    
    <!-- Internal CSS -->
    
    <!-- Internal CSS -->
    <style>
        /* Gaya CSS untuk tabel */
        table {
            border-collapse: collapse;
            width: 100%;
        }

        /* Gaya CSS untuk header kolom tabel dan baris genap */
        th,
        td {
            padding: 8px;
            text-align: center;
            border: 1px solid black;
        }

        /* Gaya CSS untuk header tabel */
        th {
            background-color: #ccc;
        }

        /* Gaya CSS untuk baris genap pada tabel */
        tr:nth-child(even) {
            background-color: #f2f2f2;
            border: 1px solid black;
        }

        /* Gaya CSS untuk header baris pada tabel */
        th {
            background-color: #f2f2f2;
            border: 1px solid black;
        }

        /* Styles untuk tampilan layar */
        @media screen {
            #mySidebar {
                display: block; /* Tampilkan sidebar pada tampilan layar */
            }

            #main {
                transition: margin-left 0.5s;
            }
        }

        /* Styles untuk proses print */
        @media print {
            #mySidebar {
                display: none !important; /* Sembunyikan sidebar pada saat mencetak */
            }

            #main {
                margin-left: 0 !important; /* Atur margin kiri ke 0 saat mencetak */
            }
        }

        @media print {
            .topnav-right {
                display: none !important;
            }

            .openbtn {
                display: none !important;
            }
        }

        /* Gaya CSS saat mode cetak untuk footer */
        @media print {
            #footer {
                display: block; /* Tampilkan footer saat mencetak */
            }
        }
        @media print {
    .print-link {
        display: none;
    }
}

         /* Styles untuk tampilan layar */
    footer {
        display: none; /* Sembunyikan footer secara default di tampilan layar */
    }

    /* Styles untuk proses print */
    @media print {
        footer {
            display: block !important; /* Tampilkan footer saat mencetak */
            position: fixed;
            bottom: 0;
            left: 0;
            width: 100%;
        }
    }
    @media print {
        .filter {
            display: none;
        }
    }
    /* Styles untuk jam */
    .print-time {
    position: fixed;
    bottom: 0;
    left: 0; /* Mengubah posisi dari right ke left */
    padding: 8px;
}
    /* Gaya CSS untuk tombol */
    button {
        border: 1px solid red; /* Ubah warna garis tombol menjadi merah */
        color: red; /* Ubah warna teks tombol menjadi merah */
    }

    /* VALIDASI */
    .container{
        width: 90%;
        margin: auto;
        border: 1px solid grey;
        border-radius: 4px;

    }
    /* .validasi{
        width: 90%;
        margin: auto;
        border: 1px solid grey;
        border-radius: 4px;
    } */
    .validasi .uste{
        padding: 14px 15px;
        display: flex;
        justify-content: space-between;
        align-items: center;
        background-color: #ccc;
    }
    .validasi .uste .user,.site{
        width: 600px;
        padding: 14px 15px;
    }
    .validasi .gagu{
        padding: 0 24px;
    }
    .validasi .pildasi{
        display: flex;
        align-items: center;
        gap: 10px;
    }
    .validasi .waktu{
        display: flex;
        justify-content: space-between;
        align-items: center;
    }
    .validasi .date,.time{
        width: 600px;
    }
    .validasi .approv{
        background-color: #ccc;
        margin-top: 14px;
    }
    </style>
</head>
<body>

<!------------------------------------------------------------ SIDE BAR ------------------------------------------------------------>

<div id="mySidebar" class="sidebar">
                <!-- <a><img src="../../img/login.jpg" style="height: 100px" alt="" /></a> -->
                <span><i class="fa-solid fa-user"></i></span>
            <h4><a>
                <?php
                    if (isset($_SESSION['nama']) == $_SESSION['nama']) {
                        // Tampilkan nama di sini
                        echo "Hai, ", $_SESSION['nama'], "!";
                    }
                ?>
            </a></h4>
            <a href="javascript:void(0)" class="closebtn" onclick="closeNav()">&times;</a>
            

        <div class="text">
            <?php

            function form(){
                echo '<a style="cursor:pointer;" onclick="form()">
                        <i  class="fa-solid fa-file style="margin-right: 8px; font-size: 18px;"></i>
                        Pilih Form Departemen
                    </a>

                    <div id="form" class="toggle-element">
                    <a href="../../../production/pr_pilih_form.php"><i  class="fa-solid fa-file style="margin-right: 8px; font-size: 18px;"></i>Production</a>
                    <a href="../../eng_pilih_form.php"><i  class="fa-solid fa-file style="margin-right: 8px; font-size: 18px;"></i>Engineering</a>
                    <a href="../../../warehouse/wh_pilih_form.php"><i  class="fa-solid fa-file style="margin-right: 8px; font-size: 18px;"></i>Warehouse</a>
                    <a href="../../../technical_service/ts_pilih_form.php"><i  class="fa-solid fa-file style="margin-right: 8px; font-size: 18px;"></i>Technical Service</a>
                    <a href="#"><i  class="fa-solid fa-file style="margin-right: 8px; font-size: 18px;"></i>General Affair</a>
                    </div>';
            }
            function preview(){
                echo '<a style="cursor:pointer;" onclick="preview()">
                        <i class="fa-solid fa-clock-rotate-left" style="margin-right: 8px; font-size: 18px;"></i>
                        Preview Form
                    </a>

                    <div id="preview" class="toggle-element">
                    <a href="../../../production/pr_home.php"><i class="fa-solid fa-clock-rotate-left" style="margin-right: 8px; font-size: 18px;"></i>Production</a>
                    <a href="../../inspeksi_putr/preview_putr.php"><i class="fa-solid fa-clock-rotate-left" style="margin-right: 8px; font-size: 18px;"></i>Engineering</a>
                    <a href="../../../warehouse/wh_home.php"><i class="fa-solid fa-clock-rotate-left" style="margin-right: 8px; font-size: 18px;"></i>Warehouse</a>
                    <a href="../../../technical_service/ts_home.php"><i class="fa-solid fa-clock-rotate-left" style="margin-right: 8px; font-size: 18px;"></i>Technical Service</a>
                    <a href="#"><i class="fa-solid fa-clock-rotate-left" style="margin-right: 8px; font-size: 18px;"></i>General Affair</a>
                    </div>';
            }
                function side_admin(){
                    echo
                    '    
                    <a href="../../../admin/user_list.php"><i class="fa-solid fa-list" style="margin-right: 6px; font-size: 18px;"></i> User Account List</a>
                    <a href="../../../admin/operation_log.php"><i class="fa-solid fa-rectangle-list" style="margin-right: 8px; font-size: 18px;"></i>Operation Log</a>
                    ';
                    form();
                    preview();
                    echo '<a href="../../../logout.php"><i class="fa-solid fa-power-off" style="margin-right: 8px; font-size: 18px;"></i>Logout</a>'
                    ;
                }
                
                function side_supmager(){
                    echo '<a href="../../../admin/operation_log.php">Operation Log</a>';
                    form();
                    preview();
                    echo '<a href="../../../logout.php"><i class="fa-solid fa-power-off" style="margin-right: 8px; font-size: 18px;"></i>Logout</a>'
                    ;
                }
                function side_staff(){

                    switch ($_SESSION['level']) {
                        case "staff_prod":
                            
                            break;
            
                        case "staff_tk":
                            echo 
                            '<a href=engineering/eng_home.php>
                            <i  class="fa-solid fa-file style="margin-right: 8px; font-size: 18px;"></i>
                            Pilih Form</a>
                            <a href=engineering/eng_pilih_form.php>
                            <i class="fa-solid fa-clock-rotate-left" style="margin-right: 8px; font-size: 18px;"></i>
                            Preview</a>
                            <a href="../../../logout.php"><i class="fa-solid fa-power-off" style="margin-right: 8px; font-size: 18px;"></i>Logout</a>'
                            ;
                            break;
                        
                        case "staff_wh":
                            
                            break;
                        
                        case "staff_ts":
                            
                            break;
    
                        case "staff_ga":
                            
                            break;
            
                        default:
                            echo "<meta http-equiv='refresh'>";
                            break;
                        }
                    echo
                    '<a href="../../logout.php">Logout</a>';
                }

                

                switch ($_SESSION['level']) {
                    case "staff_prod":
                        side_staff();
                        break;
        
                    case "staff_tk":
                        side_staff();
                        break;
                    
                    case "staff_wh":
                        side_staff();
                        break;
                    
                    case "staff_ts":
                        side_staff();
                        break;

                    case "staff_ga":
                        side_staff();
                        break;

                    case "supmager":
                        side_supmager();
                        break;

                    case "administrator":
                        side_admin();
                        break;
        
                    default:
                        echo "<meta http-equiv='refresh'>";
                        break;
                    }
            ?>
        </div>
    </div>

<!------------------------------------------------------------ BATAS SIDE BAR ------------------------------------------------------------>
<!------------------------------------------------------------ KETIK PROGRAM ANDA DI BAWAH ----------------------------------------------->
<!------------------------------------------------------------ DENGAN MENGHAPUS DARI LINE 54 YAA ----------------------------------------->

        <div id="main">
            <div class="topnav-right">
                <a href="../../../Home.php" class="openbtn; fa-solid fa-arrow-left" style="text-decoration:none; color:white" ></a> <!--program back-->
            </div>
            <a class="openbtn" style="text-decoration:none; color:white;" onclick="openNav()">&equiv;</a>
            
<!------------------------------------------------------------ PREVIEW NYA ------------------------------------------------------------>

<br>
<br>
<div class="filter">

<?php
$koneksisite_lokasi = mysqli_query($conn, "SELECT DISTINCT lokasi FROM tb_pr_inspeksi order by lokasi asc");
$koneksisite_shift = mysqli_query($conn, "SELECT DISTINCT shift FROM tb_pr_inspeksi order by shift asc");
?>
<!-- Pilih Tanggal -->
    <form method="post">
        
                <td>Dari tanggal :</td>
                <td><input type="date" name="dari_tgl" required></td>

    <br>
    <?php
        if (isset($_POST['filter'])) {
            $dari_tgl = mysqli_real_escape_string($conn, $_POST['dari_tgl']);
            // echo "dari tanggal" .$dari_tgl. "sampi tanggal" .$sampai_tgl;
        }
    ?>
<!-- Pilih Lokasi -->
        <select name="lokasi">
            <option value="" selected hidden>Pilih Lokasi</option>
            <?php
                while ($data_lokasi = mysqli_fetch_array($koneksisite_lokasi)) {
                    ?>
                    <option value="<?= $data_lokasi['lokasi'] ?>"><?=  $data_lokasi['lokasi'] ?></option>
                    <?php
                }
            ?>
        </select>
<!-- Pilih Shift -->
        <select name="shift">
            <option value="" selected hidden>Pilih Shift</option>
            <?php
                while ($data_shift = mysqli_fetch_array($koneksisite_shift)) {
                    ?>
                    <option value="<?= $data_shift['shift'] ?>"><?=  $data_shift['shift'] ?></option>
                    <?php
                }
            ?>
        </select>

    <td><input type="submit" class="btn" name="filter" value="Filter" style="background-color: #2a5783; color: #fff;"></td>
    </form>
</div>
    <!-- ---------------------------------------------------------------------------END FILTER---------------------------------------------------------------------------- -->

    <!-- Container -->
    <div class="container mt-4">
        <div id="content">
            <!-- Header Tabel -->
            <table class="table-bordered">
                <th style="text-align: center; vertical-align:middle; width: 200px;"><img src="../img/logo.png" width="120px" height="60"></th>
                <th style="text-align: center; vertical-align:middle;"><h4><strong>Formulir Inspeksi Kebersihan Personil, Ruangan, dan Peralatan</strong></h4></th>
            </table>

            <!-- Informasi Lokasi, Bagian, Departemen, Site, dan Bulan -->
            <table>
                <!-- Informasi Lokasi, Bagian, Departemen, Site, dan Bulan -->
                <thead>
                    <tr>
                        <!-- Informasi Lokasi -->
                        <td rowspan="3" style="border: none; text-align: left;">
                            <small>Lokasi :</small>
                            <span class="lokasi-info"></span>
                            <?php
                            // Inisialisasi variabel $data
                            $data = null;

                            // Ambil data inspeksi dari tabel inspeksi berdasarkan filter bulan, tahun, dan lokasi jika ada
                            // untuk filter bulan
                            if (isset($_POST['filter'])) {
                                $dari_tgl = mysqli_real_escape_string($conn, $_POST['dari_tgl']);
                                $lokasi = mysqli_real_escape_string($conn, $_POST['lokasi']);
                                $shift = mysqli_real_escape_string($conn, $_POST['shift']);
                                $data = mysqli_query($conn,"SELECT * FROM tb_pr_inspeksi WHERE tgl= '$dari_tgl' AND lokasi= '$lokasi' AND shift= '$shift' ");
                            }else{
                                $data = mysqli_query($conn,"SELECT * FROM tb_pr_inspeksi limit 0");
                            }
                            // Loop untuk menampilkan data inspeksi dalam tabel
                            while($row = mysqli_fetch_array($data)){
                                echo $lokasi;}
                        ?>
                        </td>

                        <!-- Informasi Bagian -->
                        <td rowspan="3" style="border: none; text-align: left;"><small>Bagian :</small>
                            <?php
                                // Ambil data bagian dari tabel bagian
                                $connbagian = mysqli_query($conn, "SELECT * FROM tb_pr_bagian");
                                while ($data = mysqli_fetch_array($connbagian)) {
                                    if ($data['bagian'] === "Produksi Liquid") {
                                        echo "<label><small>{$data['bagian']}</small></label><br>";
                                    }
                                }
                            ?>
                        </td>

                        <!-- Informasi Departemen -->
                        <td rowspan="3" style="border: none; text-align: left;"><small>Departemen :</small>
                            <?php
                                // Ambil data departemen dari tabel departemen
                                $conndepartemen = mysqli_query($conn, "SELECT * FROM tb_departemen");
                                while ($data = mysqli_fetch_array($conndepartemen)) {
                                    if ($data['departemen'] === "Produksi PG") {
                                        echo "<label><small>{$data['departemen']}</small></label><br>";
                                    }
                                }
                            ?>
                        </td>

                        <!-- Informasi Site -->
                        <td rowspan="3" style="border: none; text-align: left;"><small>Site :</small>
                            <?php
                                // Ambil data site dari tabel site
                                $connsite = mysqli_query($conn, "SELECT * FROM tb_site");
                                while ($data = mysqli_fetch_array($connsite)) {
                                    if ($data['site'] === "Pulogadung") {
                                        echo "<label><small>{$data['site']}</small></label><br>";
                                    }
                                }
                            ?>
                        </td>
                        <!-- Informasi Bulan -->
                        <td rowspan="3" style="border: none; text-align: right;"><small>Bulan :</small>
                        <?php
                            if (isset($_POST['filter'])) {
                                $dari_tgl = mysqli_real_escape_string($conn, $_POST['dari_tgl']);
                                // Misalnya, $dari_tgl memiliki format 'YYYY-MM-DD', sesuaikan dengan format yang diterima oleh kolom tanggal pada tabel.

                                // Konversi tanggal ke format bulan
                                $bulan_tampilan = date("F Y", strtotime($dari_tgl));

                                echo "$bulan_tampilan";
                            }
                        ?>
                        </td>
                    </tr>
                </thead>
            </table>

            <!-- Tabel Utama -->
            <div class="tab-pane fade" id="custom-tabs-two-profile" role="tabpanel" aria-labelledby="custom-tabs-two-profile-tab">
                <table id="example1" class="table table-bordered table-striped">
                    <thead>
                        <tr>
                            <!-- Header Tabel -->
                            <td rowspan="2" style="vertical-align: middle;">Tanggal</td>
                            <td rowspan="2" style="vertical-align: middle;">Shift</td>
                            <td colspan="6">Check Item</td>
                            <td rowspan="2" style="vertical-align: middle;">Lokasi</td>
                            <td rowspan="2" style="vertical-align: middle;">Pelaksana</td>
                            <td rowspan="2" style="vertical-align: middle;">Pemeriksa</td>
                        </tr>
                        <tr>
                            <!-- Kolom Check Item -->
                            <td>Personel</td>
                            <td>Keterangan Personel</td>
                            <td>Ruangan</td>
                            <td>Keterangan Ruangan</td>
                            <td>Peralatan</td>
                            <td>Keterangan Peralatan</td>
                        </tr>
                    </thead>
                    <tbody>
                        <?php
                            // Inisialisasi variabel $data
                            $data = null;

                            // Ambil data inspeksi dari tabel inspeksi berdasarkan filter bulan, tahun, dan lokasi jika ada
                            // untuk filter bulan
                            if (isset($_POST['filter'])) {
                                $dari_tgl = mysqli_real_escape_string($conn, $_POST['dari_tgl']);
                                $lokasi = mysqli_real_escape_string($conn, $_POST['lokasi']);
                                $shift = mysqli_real_escape_string($conn, $_POST['shift']);
                                $data = mysqli_query($conn,"SELECT * FROM tb_pr_inspeksi WHERE tgl= '$dari_tgl' AND lokasi= '$lokasi' AND shift= '$shift' ");
                            }else{
                                $data = mysqli_query($conn,"SELECT * FROM tb_pr_inspeksi limit 0");
                            }
                            // Loop untuk menampilkan data inspeksi dalam tabel
                            while($row = mysqli_fetch_array($data)){
                        ?>
                            <!-- Tambahkan bagian HTML untuk menampilkan data inspeksi sesuai kebutuhan -->
                            <tr>
                                <td style="text-align: center;"><small><?php echo $row['tgl'] ?></small></td>
                                <td style="text-align: center;"><small><?php echo $row['shift'] ?></small></td>
                                <td style="text-align: center;"><small><?php echo $row['cek_personel'] ?></small></td>
                                <td style="text-align: center;"><small><?php echo $row['ket_personel'] ?></small></td>
                                <td style="text-align: center;"><small><?php echo $row['cek_ruangan'] ?></small></td>
                                <td style="text-align: center;"><small><?php echo $row['ket_ruangan'] ?></small></td>
                                <td style="text-align: center;"><small><?php echo $row['cek_peralatan'] ?></small></td>
                                <td style="text-align: center;"><small><?php echo $row['ket_peralatan'] ?></small></td>
                                <td style="text-align: center;"><small><?php echo $row['lokasi'] ?></small></td>
                                <td style="text-align: center;"><small><?php echo $row['paraf'] ?></small></td>
                                <td style="text-align: center;"><small><?php echo $row['paraf_spv'] ?></small></td>
                            </tr>
                        <?php
                            }
                        ?>
                    </tbody>
                    
                </table>
                
            </div>
        </div>
        
    </div>
</div>
                        

<footer>
            <small>*Lakukan Pencatatan setiap hari pertama tiap minggu</small>
            <center><small>Dokumen ini telah ditandatangani secara elektronik menggunakan aplikasi FUPD Online dengan melampirkan lembar persetujuan elektronik milik PT. Bintang Toedjoe (A Kalbe Company)</small></center>
            <small>Lampiran 1 -WI-PR-PR-8001.03</small></p>
            <center><button>APPROVED</button></center>
            <div class="print-time">Waktu cetak: <script>document.write(new Date().toLocaleString())</script></div>
</footer>
<!------------------------------------------------------------ FORM ------------------------------------------------------------->

      
<!--------------------------------------------------------------------------END FILTER TANGGAL------------------------------------------------------------------------------------------>



</br>
                
<?php
if (isset($_POST['filter'])) {
    $dari_tgl = mysqli_real_escape_string($conn, $_POST['dari_tgl']);
    $lokasi = mysqli_real_escape_string($conn, $_POST['lokasi']);
    $shift = mysqli_real_escape_string($conn, $_POST['shift']);
    // Lakukan query untuk memeriksa apakah ada entri yang cocok
    $result_check = mysqli_query($conn, "SELECT * FROM tb_pr_inspeksi WHERE bulan_form='$dari_tgl' AND lokasi='$lokasi' AND shift='$shift'");
    
    // Periksa kesalahan dalam query SQL
    if (!$result_check) {
        die("Error in query: " . mysqli_error($conn));
    }

    // Jika ada entri yang cocok, maka nonaktifkan input atau form
    $disabled = "";
    if (is_object($result_check) && mysqli_num_rows($result_check) > 0) {
        $disabled = "disabled"; // Menonaktifkan input atau form
    }

?>
                <!-----------UNTUK MENYIMPAN SEBARIS DATA DALAM SESSION SAAT RELOGIN--------------------------------------------------------------------------------------------------------------------------------------->
                <form method="POST" action="relogin_inspeksi.php">
                    
                    <?php
                        if (isset($_POST['filter'])) {
                            $dari_tgl = mysqli_real_escape_string($conn, $_POST['dari_tgl']);
                            $data = mysqli_query($conn,"SELECT * FROM tb_pr_inspeksi WHERE tgl= '$dari_tgl'AND lokasi='$lokasi' AND shift='$shift' ");
                        }else{
                            $data = mysqli_query($conn,"SELECT * FROM tb_pr_inspeksi limit 0");
                        }
                        // Loop untuk menampilkan data inspeksi dalam tabel
                        while ($row = mysqli_fetch_array($data)) {
                            ?>
                            <div class="container text-left">
                                <!-- Your other form elements here -->
                                <input type="hidden" name="tgl" value="<?= $row['tgl'] ?>">
                                <input type="hidden" name="shift" value="<?= $row['shift'] ?>">
                                <input type="hidden" name="cek_personel" value="<?= $row['cek_personel'] ?>">
                                <input type="hidden" name="ket_personel" value="<?= $row['ket_personel'] ?>">
                                <input type="hidden" name="cek_ruangan" value="<?= $row['cek_ruangan'] ?>">
                                <input type="hidden" name="ket_ruangan" value="<?= $row['ket_ruangan'] ?>">
                                <input type="hidden" name="cek_peralatan" value="<?= $row['cek_peralatan'] ?>">
                                <input type="hidden" name="ket_peralatan" value="<?= $row['ket_peralatan'] ?>">
                                <input type="hidden" name="lokasi" value="<?= $row['lokasi'] ?>">
                                <input type="hidden" name="paraf" value="<?= $row['paraf'] ?>">
                                <!-- Add other hidden input fields for each column in your table -->
                            </div>
                            <?php
                        }
                        ?>
<!------------------------------------------------------------------------------------------------FORM-------------------------------------------------------------------------------------->
                <!-- <form method="POST" action="relogin_inspeksi.php"> -->
                    
                        <center><h2><strong>Validasi Form Inspeksi Kebersihan Personil, Ruangan, dan Peralatan</h2></strong></center>
                <div class="container" style="border:1px solid black;">
                    <div class="validasi">
                        <div class="uste">
                            <div class="user">
                                <strong>User  : (as assignment)</strong><br>
                                    <?php
                                        if (isset($_SESSION['nama']) == $_SESSION['nama']) {
                                            // Tampilkan nama di sini
                                            ?>
                                            <input name="paraf_spv" type="text" placeholder="<?php echo $_SESSION['nama']; ?>" style="height: 40px;" readonly <?= $disabled ?>>
                                            <?php } ?>
                            </div>
                                
                            <div class="site" >
                                <small>Site :</small><br>
                                    <?php
                                        include '../../../koneksi.php';
                                        $koneksisite = mysqli_query($conn, "SELECT * FROM tb_site");
                                        while ($data = mysqli_fetch_array($koneksisite)) {
                                                // Memeriksa apakah nilai 'site' adalah "Pulogadung"
                                        if ($data['site'] === "Pulogadung") {
                                        ?>
                                            <input type="checkbox" name="site" value="<?= $data['site'] ?>" required <?= $disabled ?>>
                                            <label><?= $data['site'] ?></label><br>
                                        <?php } } ?>
                            </div>
                        </div>

                        <div class="gagu">
                            <div class="pildasi">
                                <label>Anda memilih form berikut untuk divalidasi :</label>
                                <input style="background-color: #e2e2e2; display: show;" type="text" name="bulan_form" value="<?= $dari_tgl; ?>" <?= $disabled ? 'readonly' : ''; ?>>
                                <p>Lokasi :</p><?php echo $lokasi; $disabled ?>
                                <p>Shift :</p><?php echo $shift; $disabled ?>  
                            </div>
                            <br>
                            <div class="waktu">
                                    <div class="date">
                                        <p><small>Date :</small></p>
                                        <input style="background-color: #e2e2e2; height:40px; width: 600px; border-radius: 4px;" type="date" class="form-control datepicker" name="tgl_spv" aria-describedby="emailHelp" placeholder="(DD/MM/YY)" required readonly <?= $disabled ?>>
                                        <!-- <input name="tgl" type="date" placeholder="Masukkan tanggal saat ini"> -->
                                        <script src="https://code.jquery.com/jquery-3.3.1.slim.min.js" integrity="sha384-q8i/X+965DzO0rT7abK41JStQIAqVgRVzpbzo5smXKp4YfRvH+8abtTE1Pi6jizo" crossorigin="anonymous"></script>
                                        <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.3/umd/popper.min.js" integrity="sha384-ZMP7rVo3mIykV+2+9J3UJ46jBk0WLaUAdn689aCwoqbBJiSnjAK/l8WvCWPIPm49" crossorigin="anonymous"></script>
                                        <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.1.3/js/bootstrap.min.js" integrity="sha384-ChfqqxuZUCnJSK3+MXmPNIyE6ZbWh2IMqE241rYiqJxyMiZ6OW/JmZQ5stwEULTy" crossorigin="anonymous"></script>
                                        <script src="https://momentjs.com/downloads/moment.min.js"></script>
                                        <script src="https://momentjs.com/downloads/moment-timezone-with-data-10-year-range.min.js"></script>

                                        <script>
                                            $(document).ready(function(){
                                            var d = new Date().toISOString();
                                            d = moment.tz(d, "Asia/Jakarta").format();
                                            var minDate = d.substring(0, 10) ;
                                            console.log(minDate);

                                            $(".datepicker").attr({
                                                "value" : minDate,
                                                "min" : minDate,
                                            });
                                            });
                                        </script>
                                        <script src="js/owl.carousel.min.js"></script>
                                        <script src="js/smoothscroll.js"></script>
                                        <script src="js/custom.js"></script>
                                    </div>

                                    <div class="time">
                                        <!-- <label><small>Time :</small></label><br> -->
                                        <p><small>Time :</small></p>
                                        <input style="background-color: #e2e2e2; height:40px; border-radius: 4px;" name="jam_spv" type="time" placeholder="Masukkan waktu saat ini" style="height: 40px;" readonly <?= $disabled ?>>
                                        <script>
                                            $(document).ready(function(){
                                                var now = new Date();
                                                var hours = now.getHours().toString().padStart(2, '0');
                                                var minutes = now.getMinutes().toString().padStart(2, '0');
                                                var currentTime = hours + ":" + minutes;

                                                $("input[name='jam_spv']").val(currentTime);
                                            });
                                        </script>
                                    </div>
                            </div>
                        </div>
<!------------------------------------------------------------ APPROVAL STATUS --------------------------------------------------------->
                        <div class="approv" style="padding: 14px 15px;">
                            <small>Approval Status :</small><br>
                            <input style="margin-top: 10px;" type="checkbox" name="keterangan" value="Approved" required <?= $disabled ?>>
                            <label >Approved</label>
                        </div>                        
                    </div>
                    
                </div>   
                <div style="margin-left: 80px; margin-top: 20px;">
                        <input class="openbtn" type="submit" name="save" value="save" <?= $disabled ?>>
                    </div> 
                </form>
                <?php
                }
                ?>
                
<!------------------------------------------------------------ FORM ----------------------------------------->
    
</body>
</html> 

<!--------------------------------------------- SCRIPT -------------------------------------------->
<script>
            function preview() {
            var x = document.getElementById("preview");
            if (x.style.display === "none") {
                x.style.display = "block";
            } else {
                x.style.display = "none";
            }
            }
            function form() {
            var x = document.getElementById("form");
            if (x.style.display === "none") {
                x.style.display = "block";
            } else {
                x.style.display = "none";
            }
            }
            function openNav() {
            document.getElementById("mySidebar").style.width = "250px";
            document.getElementById("main").style.marginLeft = "250px";
            }

            function closeNav() {
            document.getElementById("mySidebar").style.width = "0";
            document.getElementById("main").style.marginLeft= "0";
            }
        </script>
<!--------------------------------------------- STYLE -------------------------------------------->
<style>
    /* buat tombol departemen */
#preview {
  padding-left: 25%;
width: 75%;
text-align: center;
}

#form {
  padding-left: 25%;
width: 75%;
text-align: center;
}

.toggle-element {
display: none;
}

@media screen {
	.footer{
    display: none !important;
  }
}

::placeholder {
        color: black; /* Ubah warna teks placeholder menjadi hitam */
    }
    
</style>