<?php
session_start();
include '../../../koneksi.php';

if (isset($_POST['LOGIN'])) {
    $username = $_POST['username'];
    $password = $_POST['password'];
    
    // Mengambil data dari database melalui variabel sesi
    $tgl = $_SESSION['tgl'];
    $shift = $_SESSION['shift'];
    $cek_personel = $_SESSION['cek_personel'];
    $ket_personel = $_SESSION['ket_personel'];
    $cek_ruangan = $_SESSION['cek_ruangan'];
    $ket_ruangan = $_SESSION['ket_ruangan'];
    $cek_peralatan = $_SESSION['cek_peralatan'];
    $ket_peralatan = $_SESSION['ket_peralatan'];
    $lokasi = $_SESSION['lokasi'];
    $paraf = $_SESSION['paraf'];
    // Mengambil data dari variabel sesi
    $tgl_spv = $_SESSION['tgl_spv'];
    $jam = $_SESSION['jam_spv'];
    $paraf_spv = $_POST['username'];
    $keterangan = $_SESSION['keterangan'];
    $bulan_form = $_SESSION['bulan_form'];

    // Buat ngecek aja ini , nanti hapus aja Mengambil data dari database melalui variabel sesi
    // echo $_SESSION['tgl'];
    // echo $_SESSION['shift'];
    // echo $_SESSION['cek_personel'];
    // echo $_SESSION['ket_personel'];
    // echo $_SESSION['cek_ruangan'];
    // echo $_SESSION['ket_ruangan'];
    // echo $_SESSION['cek_peralatan'];
    // echo $_SESSION['ket_peralatan'];
    // echo $_SESSION['lokasi'];
    // echo $_SESSION['paraf'];
    // // Mengambil data dari variabel sesi
    // echo $_SESSION['tgl_spv'];
    // echo $_SESSION['jam_spv'];
    // echo $_POST['username'];
    // echo $_SESSION['keterangan'];
    // echo $_SESSION['bulan_form'];


    // Mengambil data dari database berdasarkan username
    $query = "SELECT * FROM tb_admin_user WHERE username='$username'";
    $result = mysqli_query($conn, $query);

    if (mysqli_num_rows($result) == 1) {
        $row = mysqli_fetch_array($result);

        // Verifikasi password menggunakan password_verify
        if (password_verify($password, $row['password'])) {
            // Password cocok, inisialisasi sesi
            $_SESSION['username'] = $row['username'];
            $_SESSION['level'] = $row['level'];
            
            // database insert SQL code

            if ($_SESSION['level'] == 'administrator' or $_SESSION['level'] == 'supervisor' or or $_SESSION['level'] == 'manager') {
                $a = "SELECT * FROM tb_pr_inspeksi WHERE tgl='$tgl' AND lokasi='$lokasi' AND shift='$shift'";
                $b = mysqli_query($conn, $a);
                if (mysqli_num_rows($b) === 1) {
                    $sql = "UPDATE tb_pr_inspeksi 
                    SET
                    lokasi = '$lokasi',
                    shift = '$shift',
                    cek_personel = '$cek_personel',
                    cek_ruangan = '$cek_ruangan',
                    cek_peralatan = '$cek_peralatan',
                    ket_personel = '$ket_personel',
                    ket_ruangan = '$ket_ruangan',
                    ket_peralatan = '$ket_peralatan',
                    tgl = '$tgl',
                    paraf = '$paraf',
                    paraf_spv ='$paraf_spv',
                    tgl_spv = '$tgl_spv',
                    bulan_form ='$bulan_form'
                    WHERE
                    tgl = '$tgl' AND lokasi='$lokasi' AND shift='$shift'";
                }

                if (mysqli_query($conn,$sql)){
                
                    echo "<script>alert('Data berhasil disimpan');</script>";

                    date_default_timezone_set('Asia/Jakarta');
                    $logTimestamp = date("Y-m-d H:i:s");
                    $useraktif = $_SESSION['nama'];
                    $logActivity = "$useraktif melakukan approval form Inspeksi Kebersihan Personil, Ruangan dan Peralatan";
                    $ip_address = $_SERVER['REMOTE_ADDR']; // Mendapatkan IP address pengguna
                    $area = $_SESSION['area'];
                    $logSql = "INSERT INTO tb_admin_logs (id, tanggal, jam,  alamat_ip, nama, area, kegiatan) VALUES (null, '$logTimestamp', '$logTimestamp', '$ip_address', '$useraktif', '$area', '$logActivity')";
                    $conn->query($logSql);

                    header('Location: validasi_inspeksi.php');
                    exit();
                }
            } elseif ($_SESSION['level'] == 'staff_tk' or $_SESSION['level'] == 'staff_prod' or $_SESSION['level'] == 'staff_wh' or $_SESSION['level'] == 'staff_ts'){
                echo "<script>alert('Anda tidak bisa melakukan validasi!');</script>";
                echo "<meta http-equiv='refresh' content='0;url=validasi_inspeksi.php'>";
                exit();
            }
        } else {
            // Password tidak cocok
            echo "<script>alert('Password salah!');</script>";
            echo "<meta http-equiv='refresh' content='0;url=validasi_inspeksi_putr.php'>";
            exit();
        }
    } else {
        // Username tidak ditemukan
        echo "<script>alert('Username tidak tersedia!');</script>";
        echo "<meta http-equiv='refresh' content='0;url=validasi_inspeksi_putr.php'>";
        exit();
    }
}
?>
