<?php
session_start();
    // Include file koneksi.php
    include '../../koneksi.php';
?>

<!DOCTYPE html>
<html>
<head>
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <!-- Stylesheet Font Awesome -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css">
    <!-- Font Roboto -->
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Roboto&family=Roboto+Condensed&display=swap" rel="stylesheet">
    <!-- External CSS -->
    <link rel="stylesheet" href="b.css">

    <!-- Internal CSS -->
    <style>
        /* Gaya CSS untuk tabel */
        table {
            border-collapse: collapse;
            width: 100%;
        }

        /* Gaya CSS untuk header kolom tabel dan baris genap */
        th,
        td {
            padding: 8px;
            text-align: center;
            border: 1px solid black;
        }

        /* Gaya CSS untuk header tabel */
        th {
            background-color: #ccc;
        }

        /* Gaya CSS untuk baris genap pada tabel */
        tr:nth-child(even) {
            background-color: #f2f2f2;
            border: 1px solid black;
        }

        /* Gaya CSS untuk header baris pada tabel */
        th {
            background-color: #f2f2f2;
            border: 1px solid black;
        }

        /* Styles untuk tampilan layar */
        @media screen {
            #mySidebar {
                display: block; /* Tampilkan sidebar pada tampilan layar */
            }

            #main {
                transition: margin-left 0.5s;
            }
        }

        /* Styles untuk proses print */
        @media print {
            #mySidebar {
                display: none !important; /* Sembunyikan sidebar pada saat mencetak */
            }

            #main {
                margin-left: 0 !important; /* Atur margin kiri ke 0 saat mencetak */
            }
        }

        @media print {
            .topnav-right {
                display: none !important;
            }

            .openbtn {
                display: none !important;
            }
        }

        /* Gaya CSS saat mode cetak untuk footer */
        @media print {
            #footer {
                display: block; /* Tampilkan footer saat mencetak */
            }
        }
        @media print {
    .print-link {
        display: none;
    }
}

         /* Styles untuk tampilan layar */
    footer {
        display: none; /* Sembunyikan footer secara default di tampilan layar */
    }

    /* Styles untuk proses print */
    @media print {
        footer {
            display: block !important; /* Tampilkan footer saat mencetak */
            position: fixed;
            bottom: 0;
            left: 0;
            width: 100%;
        }
    }
    @media print {
        .filter {
            display: none;
        }
    }
    /* Styles untuk jam */
    .print-time {
    position: fixed;
    bottom: 0;
    left: 0; /* Mengubah posisi dari right ke left */
    padding: 8px;
}
    /* Gaya CSS untuk tombol */
    button {
        border: 1px solid red; /* Ubah warna garis tombol menjadi merah */
        color: red; /* Ubah warna teks tombol menjadi merah */
    }
    </style>
</head>
<body>

<!------------------------------------------------------------ SIDE BAR ------------------------------------------------------------>

<div id="mySidebar" class="sidebar">
                <!-- <a><img src="../../img/login.jpg" style="height: 100px" alt="" /></a> -->
                <span><i class="fa-solid fa-user"></i></span>
            <h4><a>
                <?php
                    if (isset($_SESSION['username']) == $_SESSION['username']) {
                        // Tampilkan username di sini
                        echo "Hai, ", $_SESSION['username'], "!";
                    }
                ?>
            </a></h4>
            <a href="javascript:void(0)" class="closebtn" onclick="closeNav()">&times;</a>
            

        <div class="text">
            <?php

            function form(){
                echo '<a style="cursor:pointer;" onclick="form()">
                        <i  class="fa-solid fa-file style="margin-right: 8px; font-size: 18px;"></i>
                        Pilih Form Departemen
                    </a>

                    <div id="form" class="toggle-element" style="display: none">
                    <a href="../pr_pilih_form.php"><i  class="fa-solid fa-file style="margin-right: 8px; font-size: 18px;"></i>Production</a>
                    <a href="../../engineering/eng_pilih_form.php"><i  class="fa-solid fa-file style="margin-right: 8px; font-size: 18px;"></i>Engineering</a>
                    <a href="../../warehouse/wh_pilih_form.php"><i  class="fa-solid fa-file style="margin-right: 8px; font-size: 18px;"></i>Warehouse</a>
                    <a href="../../technical_service/ts_pilih_form.php"><i  class="fa-solid fa-file style="margin-right: 8px; font-size: 18px;"></i>Technical Service</a>
                    <a href="#"><i  class="fa-solid fa-file style="margin-right: 8px; font-size: 18px;"></i>General Affair</a>
                    </div>';
            }
            function preview(){
                echo '<a style="cursor:pointer;" onclick="preview()">
                        <i class="fa-solid fa-clock-rotate-left" style="margin-right: 8px; font-size: 18px;"></i>
                        Preview Form
                    </a>

                    <div id="preview" class="toggle-element" style="display: none">
                    <a href="../pr_pilih_preview.php"><i class="fa-solid fa-clock-rotate-left" style="margin-right: 8px; font-size: 18px;"></i>Production</a>
                    <a href="../../engineering/eng_pilih_preview.php"><i class="fa-solid fa-clock-rotate-left" style="margin-right: 8px; font-size: 18px;"></i>Engineering</a>
                    <a href="../../warehouse/wh_pilih_preview.php"><i class="fa-solid fa-clock-rotate-left" style="margin-right: 8px; font-size: 18px;"></i>Warehouse</a>
                    <a href="../../technical_service/ts_pilih_preview.php"><i class="fa-solid fa-clock-rotate-left" style="margin-right: 8px; font-size: 18px;"></i>Technical Service</a>
                    <a href="#"><i class="fa-solid fa-clock-rotate-left" style="margin-right: 8px; font-size: 18px;"></i>General Affair</a>
                    </div>';
            }
                function side_admin(){
                    echo
                    '    
                    <a href="../../admin/user_list.php"><i class="fa-solid fa-list" style="margin-right: 6px; font-size: 18px;"></i> User Account List</a>
                    <a href="../../admin/operation_log.php"><i class="fa-solid fa-rectangle-list" style="margin-right: 8px; font-size: 18px;"></i>Operation Log</a>
                    ';
                    form();
                    preview();
                    echo '<a href="../../logout.php"><i class="fa-solid fa-power-off" style="margin-right: 8px; font-size: 18px;"></i>Logout</a>'
                    ;
                }

                function manager(){
                    echo '<a href="../../admin/operation_log.php">Operation Log</a>';
                    form();
                    preview();
                    echo '<a href="../../logout.php">Logout</a>';
                }
                
                function side_supmager(){
                    echo '<a href="../../admin/operation_log.php">Operation Log</a>';
                    form();
                    preview();
                    echo '<a href="../../logout.php">Logout</a>';
                }
                function side_staff(){

                    switch ($_SESSION['level']) {
                        case "staff_prod":
                            echo 
                            '<a href=../pr_pilih_form.php>
                            <i  class="fa-solid fa-file style="margin-right: 8px; font-size: 18px;"></i>
                            Pilih Form</a>
                            <a href=../pr_pilih_preview.php>
                            <i class="fa-solid fa-clock-rotate-left" style="margin-right: 8px; font-size: 18px;"></i>
                            Preview</a>';
                            break;
            
                        case "staff_tk":
                            
                            break;
                        
                        case "staff_wh":
                            
                            break;
                        
                        case "staff_ts":
                            
                            break;
    
                        case "staff_ga":
                            
                            break;
            
                        default:
                            echo "<meta http-equiv='refresh'>";
                            break;
                        }
                    echo
                    '<a href="../../logout.php">Logout</a>';
                }

                

                switch ($_SESSION['level']) {
                    case "staff_prod":
                        side_staff();
                        break;
        
                    case "staff_tk":
                        side_staff();
                        break;
                    
                    case "staff_wh":
                        side_staff();
                        break;
                    
                    case "staff_ts":
                        side_staff();
                        break;

                    case "staff_ga":
                        side_staff();
                        break;

                    case "supervisor":
                        side_supmager();
                        break;

                    case "manager":
                        manager();
                        break;

                    case "administrator":
                        side_admin();
                        break;
        
                    default:
                        echo "<meta http-equiv='refresh'>";
                        break;
                    }
            ?>
        </div>
    </div>

<!------------------------------------------------------------ BATAS SIDE BAR ------------------------------------------------------------>

<div id="main">
    <!-- Tombol Back -->
    <div class="topnav-right">
        <a href="report_inspeksi.php" class="openbtn" style="text-decoration:none" >&larr;</a> <!--program back-->
    </div>
    <button class="openbtn" onclick="openNav()">&equiv;</button>  
<!-- Form Filter -->
<?php
        //include 'koneksi.php';

        // Ambil data bulan
        $koneksisite_bulan = mysqli_query($conn, "SELECT DISTINCT MONTH(tgl) as bulan FROM tb_pr_inspeksi");

        // Ambil data tahun
        $koneksisite_tahun = mysqli_query($conn, "SELECT DISTINCT YEAR(tgl) as tahun FROM tb_pr_inspeksi");

        // Ambil data lokasi
        $koneksisite_lokasi = mysqli_query($conn, "SELECT DISTINCT lokasi FROM tb_pr_inspeksi");
    ?>
    <form method="get" class="filter">
        <!-- Pilih Bulan -->
        <select name="bulan">
            <option value="" selected hidden>Pilih Bulan</option>
            <?php
                while ($data_bulan = mysqli_fetch_array($koneksisite_bulan)) {
                    ?>
                    <option value="<?= $data_bulan['bulan'] ?>"><?= date("F", mktime(0, 0, 0, $data_bulan['bulan'], 1)) ?></option>
                    <?php
                }
            ?>
        </select>

        <!-- Pilih Tahun -->
        <select name="tahun">
            <option value="" selected hidden>Pilih Tahun</option>
            <?php
                // Ambil data tahun dari tabel inspeksi
                while ($data_tahun = mysqli_fetch_array($koneksisite_tahun)) {
                    ?>
                    <option value="<?= $data_tahun['tahun'] ?>"><?= $data_tahun['tahun'] ?></option>
                    <?php
                }
            ?>
        </select>

        <!-- Pilih Lokasi -->
        <select name="lokasi">
            <option value="" selected hidden>Pilih Lokasi</option>
            <?php
                while ($data_lokasi = mysqli_fetch_array($koneksisite_lokasi)) {
                    ?>
                    <option value="<?= $data_lokasi['lokasi'] ?>"><?=  $data_lokasi['lokasi'] ?></option>
                    <?php
                }
            ?>
        </select>
        <input type="submit" value="FILTER">
    </form>
    <!-- Container -->
    <div class="container mt-4">
        <div id="content">
            <!-- Header Tabel -->
            <table class="table-bordered ">
                <th style="text-align: center; vertical-align:middle; width: 200px;"><img src="img/logo.png" width="100px" height="60"></th>
                <th style="text-align: center; vertical-align:middle;"><h4><strong>Formulir Inspeksi Kebersihan Personil, Ruangan, dan Peralatan</strong></h4></th>
            </table>

            <!-- Informasi Lokasi, Bagian, Departemen, Site, dan Bulan -->
            <table>
                <!-- Informasi Lokasi, Bagian, Departemen, Site, dan Bulan -->
                <thead>
                    <tr>
                        <!-- Informasi Lokasi -->
                        <td rowspan="3" style="border: none; text-align: left;">
                            <small>Lokasi :</small>
                            <span class="lokasi-info"></span>
                                <?php
                                    if(isset($_GET['lokasi'])){
                                        $lokasi = $_GET['lokasi'];
                                        $data = mysqli_query($conn,"select * from tb_pr_inspeksi where lokasi='$lokasi' limit 1");
                                    }else{
                                        //kosong aja sih
                                        $data = mysqli_query($conn,"select * from tb_pr_inspeksi limit 0");
                                    }
                                    while ($d = mysqli_fetch_array($data)) {
                                        // Menampilkan lokasi
                                        echo $lokasi;
                                    }
                                ?>
                        </td>

                        <!-- Informasi Bagian -->
                        <td rowspan="3" style="border: none; text-align: left;"><small>Bagian :</small>
                            <?php
                                // Ambil data bagian dari tabel bagian
                                $connbagian = mysqli_query($conn, "SELECT * FROM tb_pr_bagian");
                                while ($data = mysqli_fetch_array($connbagian)) {
                                    if ($data['bagian'] === "Produksi Liquid") {
                                        echo "<label><small>{$data['bagian']}</small></label><br>";
                                    }
                                }
                            ?>
                        </td>

                        <!-- Informasi Departemen -->
                        <td rowspan="3" style="border: none; text-align: left;"><small>Departemen :</small>
                            <?php
                                // Ambil data departemen dari tabel departemen
                                $conndepartemen = mysqli_query($conn, "SELECT * FROM tb_departemen");
                                while ($data = mysqli_fetch_array($conndepartemen)) {
                                    if ($data['departemen'] === "Produksi PG") {
                                        echo "<label><small>{$data['departemen']}</small></label><br>";
                                    }
                                }
                            ?>
                        </td>

                        <!-- Informasi Site -->
                        <td rowspan="3" style="border: none; text-align: left;"><small>Site :</small>
                            <?php
                                // Ambil data site dari tabel site
                                $connsite = mysqli_query($conn, "SELECT * FROM tb_site");
                                while ($data = mysqli_fetch_array($connsite)) {
                                    if ($data['site'] === "Pulogadung") {
                                        echo "<label><small>{$data['site']}</small></label><br>";
                                    }
                                }
                            ?>
                        </td>
                        <!-- Informasi Bulan -->
                        <td rowspan="3" style="border: none; text-align: right;"><small>Bulan :</small>
                            <?php
                                if(isset($_GET['bulan']) && isset($_GET['tahun']) ){
                                    $bulan = $_GET['bulan'];
                                    $tahun = $_GET['tahun'];
                                    $data = mysqli_query($conn,"select * from tb_pr_inspeksi where month(tgl)='$bulan' and year(tgl)='$tahun' limit 1");
                                }else{
                                    //kosong aja sih
                                    $data = mysqli_query($conn,"select * from tb_pr_inspeksi limit 0");
                                }
                                while ($d = mysqli_fetch_array($data)) {
                                    // Mengambil data tanggal
                                    $tgl = $d['tgl'];

                                    // Mengubah tanggal menjadi format bulan (MM)
                                    $bulan = date('F Y', strtotime($tgl));

                                    // Menampilkan bulan
                                    echo $bulan;
                                }
                            ?>
                        </td>
                    </tr>
                </thead>
            </table>

            <!-- Tabel Utama -->
            <div class="tab-pane fade" id="custom-tabs-two-profile" role="tabpanel" aria-labelledby="custom-tabs-two-profile-tab">
                <table id="example1" class="table table-bordered table-striped">
                    <thead>
                        <tr>
                            <!-- Header Tabel -->
                            <td rowspan="2" style="vertical-align: middle;">Tanggal</td>
                            <td rowspan="2" style="vertical-align: middle;">Shift</td>
                            <td colspan="6">Check Item</td>
                            <td rowspan="2" style="vertical-align: middle;">Lokasi</td>
                            <td rowspan="2" style="vertical-align: middle;">Pelaksana</td>
                            <td rowspan="2" style="vertical-align: middle;">Pemeriksa</td>
                        </tr>
                        <tr>
                            <!-- Kolom Check Item -->
                            <td>Personel</td>
                            <td>Keterangan Personel</td>
                            <td>Ruangan</td>
                            <td>Keterangan Ruangan</td>
                            <td>Peralatan</td>
                            <td>Keterangan Peralatan</td>
                        </tr>
                    </thead>
                    <tbody>
                        <?php
                            // Inisialisasi variabel $data
                            $data = null;

                            // Ambil data inspeksi dari tabel inspeksi berdasarkan filter bulan, tahun, dan lokasi jika ada
                            if(isset($_GET['bulan']) && isset($_GET['tahun']) && isset($_GET['lokasi'])){
                                $bulan = $_GET['bulan'];
                                $tahun = $_GET['tahun'];
                                $lokasi = $_GET['lokasi'];
                                $data = mysqli_query($conn,"SELECT * FROM tb_pr_inspeksi WHERE month(tgl)='$bulan' AND year(tgl)='$tahun' AND lokasi='$lokasi' ORDER BY shift ASC");

                                $filter_url = "cetak.php?bulan=$bulan&tahun=$tahun&lokasi=$lokasi";
                                echo "<script>window.open('$filter_url', '_blank');</script>"; // Buka halaman cetak_inspeksi.php dalam tab baru                            

                            } else {
                                // Jika tidak ada filter lokasi, ambil data berdasarkan filter bulan dan tahun
                                if(isset($_GET['bulan']) && isset($_GET['tahun'])){
                                    $bulan = $_GET['bulan'];
                                    $tahun = $_GET['tahun'];
                                    $data = mysqli_query($conn,"SELECT * FROM tb_pr_inspeksi WHERE month(tgl)='$bulan' AND year(tgl)='$tahun'");
                                } else {
                                    // Jika tidak ada filter bulan dan tahun, ambil semua data
                                    $data = mysqli_query($conn, "SELECT * FROM tb_pr_inspeksi");
                                }
                            }

                            // Loop untuk menampilkan data inspeksi dalam tabel
                            while($row = mysqli_fetch_array($data)){
                        ?>
                            <!-- Tambahkan bagian HTML untuk menampilkan data inspeksi sesuai kebutuhan -->
                            <tr>
                                <td style="text-align: center;"><small><?php echo $row['tgl'] ?></small></td>
                                <td style="text-align: center;"><small><?php echo $row['shift'] ?></small></td>
                                <td style="text-align: center;"><small><?php echo $row['cek_personel'] ?></small></td>
                                <td style="text-align: center;"><small><?php echo $row['ket_personel'] ?></small></td>
                                <td style="text-align: center;"><small><?php echo $row['cek_ruangan'] ?></small></td>
                                <td style="text-align: center;"><small><?php echo $row['ket_ruangan'] ?></small></td>
                                <td style="text-align: center;"><small><?php echo $row['cek_peralatan'] ?></small></td>
                                <td style="text-align: center;"><small><?php echo $row['ket_peralatan'] ?></small></td>
                                <td style="text-align: center;"><small><?php echo $row['lokasi'] ?></small></td>
                                <td style="text-align: center;"><small><?php echo $row['paraf'] ?></small></td>
                                <td style="text-align: center;"><small><?php echo $row['paraf_spv'] ?></small></td>
                            </tr>
                        <?php
                            }
                        ?>
                    </tbody>
                    
                </table>
                
            </div>
        </div>
        
    </div>
</div>

<footer>
            <small>*Lakukan Pencatatan setiap hari pertama tiap minggu</small>
            <center><small>Dokumen ini telah ditandatangani secara elektronik menggunakan aplikasi FUPD Online dengan melampirkan lembar persetujuan elektronik milik PT. Bintang Toedjoe (A Kalbe Company)</small></center>
            <small>Lampiran 1 -WI-PR-PR-8001.03</small></p>
            <center><button>APPROVED</button></center>
            <!-- <div class="print-time">Waktu cetak: <script>document.write(new Date().toLocaleString())</script></div> -->
</footer>


<span class="page-number"></span>
<!-- JavaScript Filter Bulan -->
<script src="https://code.jquery.com/jquery-3.6.4.min.js" integrity="sha384-Gn5384xqQ1aoWXA+058RXPxPg6fy4IWvTNh0E263XmFcJlSAwiGgFAW/dAiS6JXm" crossorigin="anonymous"></script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js" integrity="sha384-e0vHyoXYAqjYK2Vfo8Ft9wMOb6paCwkx5KX+6Z5L/6oBQCFIbYbXHjHo8Nf6AAa" crossorigin="anonymous"></script>

<script>
    // Fungsi untuk melakukan filter berdasarkan lokasi
    function filterLokasi() {
        var selectedLokasi = document.getElementById("lokasiFilter").value;
        var selectedTahun = document.getElementById("tahunFilter").value;
        var lokasiElements = document.querySelectorAll(".lokasi-info");
        var tableRows = document.querySelectorAll("table tr.isi");

        // Mengubah teks pada elemen .lokasi-info menjadi lokasi yang dipilih
        lokasiElements.forEach(function (lokasiElement) {
            lokasiElement.innerText = selectedLokasi;
        });

        // Memeriksa setiap baris tabel
        tableRows.forEach(function (row) {
            var rowLokasi = row.getAttribute("data-lokasi");
            var rowMonth = row.getAttribute("data-bulan");
            var rowYear = row.querySelector("td:first-child").innerText.split('-')[0]; // Mendapatkan tahun dari baris

            // Menyesuaikan dengan filter bulan dan tahun
            var selectedMonth = document.getElementById("bulan").value;

            if ((selectedLokasi === "Semua Lokasi" || rowLokasi === selectedLokasi) &&
                (selectedMonth === "0" || rowMonth === selectedMonth) &&
                (selectedTahun === "0" || rowYear === selectedTahun)) {
                row.style.display = "table-row";
            } else {
                row.style.display = "none";
            }
        });
    }

    // Fungsi untuk kembali ke halaman sebelumnya
    function goBack() {
        window.history.back();
    }

    // Fungsi untuk menampilkan atau menyembunyikan dropdown
    function toggleDropdown(dropdownId) {
        var dropdown = document.getElementById(dropdownId);
        if (dropdown.style.display === 'block') {
            dropdown.style.display = 'none';
        } else {
            dropdown.style.display = 'block';
        }
    }
    function toggleForm() {
                var form = document.getElementById("registrationForm");
                form.style.display = form.style.display === "none" || form.style.display === "" ? "block" : "none";
            }
            function preview() {
            var x = document.getElementById("preview");
            if (x.style.display === "none") {
                x.style.display = "block";
            } else {
                x.style.display = "none";
            }
            }
            function form() {
            var x = document.getElementById("form");
            if (x.style.display === "none") {
                x.style.display = "block";
            } else {
                x.style.display = "none";
            }
            }
            function openNav() {
            document.getElementById("mySidebar").style.width = "250px";
            document.getElementById("main").style.marginLeft = "250px";
            }

            function closeNav() {
            document.getElementById("mySidebar").style.width = "0";
            document.getElementById("main").style.marginLeft= "0";
            }
</script>

</body>
</html>
