<?php
session_start();
include '../../koneksi.php';

if (isset($_POST["save"])) {
    $lokasi = $_POST['lokasi'];

    // Cek apakah lokasi ada di database
    $query_check_lokasi = "SELECT lokasi FROM tb_pr_inspeksi WHERE lokasi = '$lokasi'";
    $result_check_lokasi = mysqli_query($conn, $query_check_lokasi);

    if (mysqli_num_rows($result_check_lokasi) > 0) {
        // Ambil tanggal terakhir untuk lokasi tersebut
        $query_last_date = "SELECT tgl AS last_date FROM tb_pr_inspeksi WHERE lokasi='$lokasi' ORDER BY tgl DESC LIMIT 1";
        $result_last_date = mysqli_query($conn, $query_last_date);

        if ($result_last_date && mysqli_num_rows($result_last_date) > 0) {
            $row_last_date = mysqli_fetch_assoc($result_last_date);
            $last_date = $row_last_date['last_date'];

            // echo $last_date;

            date_default_timezone_set('Asia/Jakarta');
            $today = date('Y-m-d');

            //mengecek apakah $last_date = $today
            if ($last_date == $today){
                $query_shift = "SELECT shift FROM tb_pr_inspeksi WHERE lokasi='$lokasi' AND tgl='$last_date' ORDER BY id DESC LIMIT 1";
                $result_shift = mysqli_query($conn, $query_shift);
                // jika ya $last_date == $today
                if ($result_shift && mysqli_num_rows($result_shift) > 0) {
                    $row_shift = mysqli_fetch_assoc($result_shift);
                    $shift = $row_shift['shift'];
                    //cek shift 1
                    if ($shift == 1) {
                        form_input($shift=2);
                    } elseif ($shift == 2) {    //cek shift 2
                        form_input($shift=3);
                    } elseif ($shift == 3){
                        echo 'Anda sudah melakukan Inspeksi untuk Shift 1, Shift 2, dan Shift 3. Terima kasih! :)';
                    }
                } 
            }
            //mengecek apakah $last_date != $today
            if ($last_date != $today){
                $query_shift_2 = "SELECT shift FROM tb_pr_inspeksi WHERE lokasi='$lokasi' AND tgl='$last_date' ORDER BY id DESC LIMIT 1";
                $result_shift_2 = mysqli_query($conn, $query_shift_2);
                // jika ya $last_date == $today
                if ($result_shift_2 && mysqli_num_rows($result_shift_2) > 0) {
                    $row_shift_2 = mysqli_fetch_assoc($result_shift_2);
                    $shift = $row_shift_2['shift'];
                    // echo $shift;
                    //cek shift 3
                    if ($shift == 3) {    //cek shift 3
                        form_input($shift=1);
                    } elseif ($shift == 2) {    //cek shift 2
                        header("Location: keterangan.php?missing_shift=3&lokasi=$lokasi&last_date=$last_date");
                    } elseif ($shift == 1) {    //cek shift 1
                        header("Location: keterangan.php?missing_shift=2&lokasi=$lokasi&last_date=$last_date");
                        // echo $today;
                    }
                }
            }

        }
    } elseif (mysqli_num_rows($result_check_lokasi) == 0) {
        form_input($shift=1);
    }
}
?>



<?php
    function form_input($shift) {
?>

<!DOCTYPE html>
<html>
    <head>
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css">
        <link rel="preconnect" href="https://fonts.googleapis.com">
        <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
        <link href="https://fonts.googleapis.com/css2?family=Roboto&family=Roboto+Condensed&display=swap" rel="stylesheet">
        <link rel="stylesheet" href="b.css">
        <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet"
        integrity="sha384-T3c6CoIi6uLrA9TneNEoa7RxnatzjcDSCmG1MXxSR1GAsXEV/Dwwykc2MPK8M2HN"
        crossorigin="anonymous">
    </head>
    <style>
   /* Gaya CSS untuk tabel */
   table {
            border-collapse: collapse;
            width: 100%;
        }

        /* Gaya CSS untuk header kolom tabel dan baris genap */
        th,
        td {
            padding: 8px;
            text-align: center;
            border: 1px solid black;
        }

        /* Gaya CSS untuk header tabel */
        th {
            background-color: #ccc;
        }

        /* Gaya CSS untuk baris genap pada tabel */
        tr:nth-child(even) {
            background-color: #f2f2f2;
            border: 1px solid black;
        }

        /* Gaya CSS untuk header baris pada tabel */
        th {
            background-color: #f2f2f2;
            border: 1px solid black;
        }
        /* Styles untuk tampilan layar */
        @media screen {
            #mySidebar {
                display: block; /* Tampilkan sidebar pada tampilan layar */
            }

            #main {
                transition: margin-left 0.5s;
            }
        }

        /* Styles untuk proses print */
        @media print {
            #mySidebar {
                display: none !important; /* Sembunyikan sidebar pada saat mencetak */
            }

            #main {
                margin-left: 0 !important; /* Atur margin kiri ke 0 saat mencetak */
            }
        }
        @media print {
            .topnav-right {
                display: none !important;
            }

            .openbtn {
                display: none !important;
            }
        }
        /* Gaya CSS saat mode cetak untuk footer */
        @media print {
            #footer {
             display: block; /* Tampilkan footer saat mencetak */
                    }
            }
            #footer {
            position: fixed;
            bottom: 0px;
            left: 0px;
            width: 100%;
            padding: 8px;
            display: none; /* Sembunyikan footer secara default */
            }

            /* Gaya CSS saat mode cetak untuk footer */
            @media print {
            #footer {
            display: block; /* Tampilkan footer saat mencetak */
                    }
                }
     </style>
    <body>

<!------------------------------------------------------------ SIDE BAR ------------------------------------------------------------>

<div id="mySidebar" class="sidebar">
                <!-- <a><img src="../../img/login.jpg" style="height: 100px" alt="" /></a> -->
                <span><i class="fa-solid fa-user"></i></span>
            <h4><a>
                <?php
                    if (isset($_SESSION['username']) == $_SESSION['username']) {
                        // Tampilkan username di sini
                        echo "Hai, ", $_SESSION['username'], "!";
                    }
                ?>
            </a></h4>
            <a href="javascript:void(0)" class="closebtn" onclick="closeNav()">&times;</a>
            

            <div class="text">
            <?php

                function form(){
                    echo '<a style="cursor:pointer;" onclick="form()">
                        <i  class="fa-solid fa-file style="margin-right: 8px; font-size: 18px;"></i>
                        Pilih Form Departemen
                    </a>

                    <div id="form" class="toggle-element" style="display: none;">
                        <a href="../../pr_pilih_form.php"><i  class="fa-solid fa-file style="margin-right: 8px; font-size: 18px;"></i>Production</a>
                        <a href="../../engineering/eng_pilih_form.php"><i  class="fa-solid fa-file style="margin-right: 8px; font-size: 18px;"></i>Engineering</a>
                        <a href="../../warehouse/wh_pilih_form.php"><i  class="fa-solid fa-file style="margin-right: 8px; font-size: 18px;"></i>Warehouse</a>
                        <a href="../../technical_service/ts_pilih_form.php"><i  class="fa-solid fa-file style="margin-right: 8px; font-size: 18px;"></i>Technical Service</a>
                        <a href="#"><i  class="fa-solid fa-file style="margin-right: 8px; font-size: 18px;"></i>General Affair</a>
                    </div>';
                }
                function preview(){
                    echo '<a style="cursor:pointer;" onclick="preview()">
                        <i class="fa-solid fa-clock-rotate-left" style="margin-right: 8px; font-size: 18px;"></i>
                        Preview Form
                    </a>

                    <div id="preview" class="toggle-element" style="display: none;">
                        <a href="../../pr_pilih_preview.php"><i class="fa-solid fa-clock-rotate-left" style="margin-right: 8px; font-size: 18px;"></i>Production</a>
                        <a href="../../engineering/eng_pilih_preview.php"><i class="fa-solid fa-clock-rotate-left" style="margin-right: 8px; font-size: 18px;"></i>Engineering</a>
                        <a href="../../warehouse/wh_pilih_preview.php"><i class="fa-solid fa-clock-rotate-left" style="margin-right: 8px; font-size: 18px;"></i>Warehouse</a>
                        <a href="../../technical_service/ts_pilih_preview.php"><i class="fa-solid fa-clock-rotate-left" style="margin-right: 8px; font-size: 18px;"></i>Technical Service</a>
                        <a href="#"><i class="fa-solid fa-clock-rotate-left" style="margin-right: 8px; font-size: 18px;"></i>General Affair</a>
                    </div>';
                }
                function side_admin(){
                    echo
                    '    
                    <a href="../../admin/user_list.php"><i class="fa-solid fa-list" style="margin-right: 6px; font-size: 18px;"></i> User Account List</a>
                    <a href="../../admin/operation_log.php"><i class="fa-solid fa-rectangle-list" style="margin-right: 8px; font-size: 18px;"></i>Operation Log</a>
                    ';
                    form();
                    preview();
                    echo '<a href="../../logout.php"><i class="fa-solid fa-power-off" style="margin-right: 8px; font-size: 18px;"></i>Logout</a>'
                    ;
                }
                
                function side_supmager(){
                    echo '<a href="../../admin/operation_log.php">Operation Log</a>';
                    form();
                    preview();
                    echo '<a href="../../logout.php"><i class="fa-solid fa-power-off" style="margin-right: 8px; font-size: 18px;"></i>Logout</a>'
                    ;
                }
                function side_staff(){

                    switch ($_SESSION['level']) {
                        case "staff_tk":
                            
                            break;
            
                        case "staff_prod":
                            echo 
                            '<a href=../pr_pilih_form.php>
                            <i  class="fa-solid fa-file style="margin-right: 8px; font-size: 18px;"></i>
                            Pilih Form</a>
                            <a href=../pr_pilih_preview.php>
                            <i class="fa-solid fa-clock-rotate-left" style="margin-right: 8px; font-size: 18px;"></i>
                            Preview</a>
                            <a href="../../logout.php"><i class="fa-solid fa-power-off" style="margin-right: 8px; font-size: 18px;"></i>Logout</a>'
                            ;
                            break;
                        
                        case "staff_wh":
                            
                            break;
                        
                        case "staff_ts":
                            
                            break;
    
                        case "staff_ga":
                            
                            break;
            
                        default:
                            echo "<meta http-equiv='refresh'>";
                            break;
                        }
                   
                }

                

                switch ($_SESSION['level']) {
                    case "staff_prod":
                        side_staff();
                        break;
        
                    case "staff_tk":
                        side_staff();
                        break;
                    
                    case "staff_wh":
                        side_staff();
                        break;
                    
                    case "staff_ts":
                        side_staff();
                        break;

                    case "staff_ga":
                        side_staff();
                        break;

                    case "supervisor":
                        side_supmager();
                        break;

                    case "manager":
                        side_supmager();
                        break;

                    case "administrator":
                        side_admin();
                        break;
        
                    default:
                        echo "<meta http-equiv='refresh'>";
                        break;
                    }
            ?>
        </div>
        </div>

        <script>
            function openNav() {
            document.getElementById("mySidebar").style.width = "250px";
            document.getElementById("main").style.marginLeft = "250px";
            }

            function closeNav() {
            document.getElementById("mySidebar").style.width = "0";
            document.getElementById("main").style.marginLeft= "0";
            }
        </script>
<!------------------------------------------------------------ BATAS SIDE BAR ------------------------------------------------------------>
<!------------------------------------------------------------ KETIK PROGRAM ANDA DI BAWAH ----------------------------------------------->
<!------------------------------------------------------------ DENGAN MENGHAPUS DARI LINE 54 YAA ----------------------------------------->

<div id="main">
            <div class="topnav-right">
                <a href="../Prod_Inspeksi/selectlokasi.php" class="openbtn" style="text-decoration:none" >&larr;</a> <!--program back-->
            </div>
            <button class="openbtn" onclick="openNav()">&equiv;</button>   
            <div class="container mt-4">
        <div class="card">
            <div class="card-header" style="background-color: #2a5783;">
            <h4 class="text-center" style="color: white;"><strong>Formulir Inspeksi Kebersihan Personil, Ruangan dan Peralatan</strong></h4>
            </div>
            <div class="card-body">
                <form method="POST" action="koneksi.php" id="myForm">
                    <div class="row">
                        <div class="col-md-6">
                        <label for="date">Tanggal:</label>
                                    <input type="date" class="form-control datepicker" name="tgl"
                                        aria-describedby="emailHelp" placeholder="(DD/MM/YY)" required readonly>
                                    <script
                                        src="https://code.jquery.com/jquery-3.3.1.slim.min.js"
                                        integrity="sha384-q8i/X+965DzO0rT7abK41JStQIAqVgRVzpbzo5smXKp4YfRvH+8abtTE1Pi6jizo"
                                        crossorigin="anonymous"></script>
                                    <script
                                        src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.3/umd/popper.min.js"
                                        integrity="sha384-ZMP7rVo3mIykV+2+9J3UJ46jBk0WLaUAdn689aCwoqbBJiSnjAK/l8WvCWPIPm49"
                                        crossorigin="anonymous"></script>
                                    <script
                                        src="https://stackpath.bootstrapcdn.com/bootstrap/4.1.3/js/bootstrap.min.js"
                                        integrity="sha384-ChfqqxuZUCnJSK3+MXmPNIyE6ZbWh2IMqE241rYiqJxyMiZ6OW/JmZQ5stwEULTy"
                                        crossorigin="anonymous"></script>
                                    <script src="https://momentjs.com/downloads/moment.min.js"></script>
                                    <script
                                        src="https://momentjs.com/downloads/moment-timezone-with-data-10-year-range.min.js"></script>

                                    <script>
                                        $(document).ready(function () {
                                            var d = new Date().toISOString();
                                            d = moment.tz(d, "Asia/Jakarta").format();
                                            var minDate = d.substring(0, 10);
                                            console.log(minDate);

                                            $(".datepicker").attr({
                                                "value": minDate,
                                                "min": minDate,
                                            });
                                        });
                                    </script>
                                    <script src="js/owl.carousel.min.js"></script>
                                    <script src="js/smoothscroll.js"></script>
                                    <script src="js/custom.js"></script>
                        </div>
                        <div class="col-md-6">
                            <label for="lokasi">Lokasi :</label><br>
                            <!-- <select name="lokasi" class="form-control" required>
                                <option value="" selected disabled>Pilih Lokasi</option>
                                <?php 
                                    if (isset($_POST["save"])) {
                                    $lokasi = $_POST['lokasi'];
                                    echo "<option value='" . $lokasi . "'>" . $lokasi . "</option>"; 
                                    }
                                ?>
                            </select> -->
                            <div class="col">
                                <input name="lokasi" type="text" value="<?php echo $lokasi; ?>" 
                                style="height: 40px; pointer-events:none; 
                                background-color: #e9ecef; border-radius: 5px;"  readonly>
                            </div>
                        </div>
                        <div class="mt-3">
                            <label>Shift :</label>
                            <div class="d-flex gap-2">
                                <!-- <div class='form-check'>
                                    <input type='radio' class='form-check-input' name='shift' value='<?php $shift?>' required>
                                    <label class='form-check-label'><?php echo $shift?></label>
                                </div> -->
                                <div class="col">
                                    <input name="shift" type="text" value="<?php echo $shift; ?>" 
                                    style="height: 40px; pointer-events:none; 
                                    background-color: #e9ecef; border-radius: 5px;"  readonly>
                                </div>
                            </div>
                        </div>


                    <div class="mt-3">
                        <label for="personil">Personil :</label>
                        <div class="d-flex gap-2">
                            <?php
                            include  '../../koneksi.php';
                            $connbagian = mysqli_query($conn, "SELECT  * FROM tb_pr_cek_personel");
                            while ($data = mysqli_fetch_array($connbagian)) {
                                echo "<div class='form-check'>
                                        <input type='radio' class='form-check-input' name='personil' value='" . $data['cek'] . "' required>
                                        <label class='form-check-label'>" . $data['cek'] . "</label>
                                    </div>";
                            }
                            ?>
                        </div>
                        <input type="text" class="form-control mt-2" placeholder="Keterangan Personil" name="ket_personil" required>
                    </div>

                    <div class="mt-3">
                        <label for="ruangan">Ruangan :</label>
                        <div class="d-flex gap-2">
                            <?php
                            $connruangan = mysqli_query($conn, "SELECT  * FROM tb_pr_cek_ruangan");
                            while ($data = mysqli_fetch_array($connruangan)) {
                                echo "<div class='form-check'>
                                        <input type='radio' class='form-check-input' name='ruangan' value='" . $data['cek'] . "' required>
                                        <label class='form-check-label'>" . $data['cek'] . "</label>
                                    </div>";
                            }
                            ?>
                        </div>
                        <input type="text" class="form-control mt-2" placeholder="Keterangan Ruangan" name="ket_ruangan" required>
                    </div>

                    <div class="mt-3">
                        <label for="peralatan">Peralatan :</label>
                        <div class="d-flex gap-2">
                            <?php
                            $connperalatan = mysqli_query($conn, "SELECT  * FROM tb_pr_cek_peralatan");
                            while ($data = mysqli_fetch_array($connperalatan)) {
                                echo "<div class='form-check'>
                                        <input type='radio' class='form-check-input' name='peralatan' value='" . $data['cek'] . "' required>
                                        <label class='form-check-label'>" . $data['cek'] . "</label>
                                    </div>";
                            }
                            ?>
                        </div>
                        <input type="text" class="form-control mt-2" placeholder="Keterangan Peralatan" name="ket_peralatan" required>
                    </div><br>

<!-------------------------------------------------- Paraf dan Keterangan --------------------------------------------------------->
                        <div class="mt-3">
                            
                                <div class="card card-custom">
                                    <div class="card-header sticky">
                                        <div class="row">
                                            <div class="col">
                                            <small>Paraf (same as user):</small><br>
                                            <?php
                                                if (isset($_SESSION['username']) == $_SESSION['username']) {
                                                    // Tampilkan nama di sini
                                                    ?>
                                                    <input name="paraf" type="text" placeholder="<?php echo $_SESSION['username']; ?>" style="height: 40px; pointer-events:none; background-color: #e9ecef; border-radius: 5px;"  readonly>
                                                    <?php } ?>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            
                        </div>

                    <div class="mt-3">
                        <input type="submit" onclick="return confirm('Are you sure you want to send data?')" name="save" value="Submit" class="btn btn-success">
                        
                    </div>
                </form>
            </div>
        </div>
    </div>
</div>

<script>
function submitForm() {
            console.log("Submit button clicked!");
            // Validasi form sebelum submit
            if (validateForm()) {
                // Lakukan operasi submit atau simpan data
                alert("Data berhasil disubmit!");
                document.getElementById("myForm").submit(); // Ganti "myForm" dengan ID form Anda
            } else {
                // Tampilkan popup "isi secara lengkap" jika form tidak valid
                alert("Harap isi semua field secara lengkap!");
            }
        }
        function validateAndSubmit() {
    var lokasi = document.getElementsByName("lokasi")[0].value;

    // Cek apakah opsi yang dipilih adalah "Pilih Lokasi"
    if (lokasi === "") {
        alert("Harap pilih lokasi yang valid!");
    } else {
        // Lakukan operasi submit atau simpan data
        alert("Data berhasil disubmit!");
        document.getElementById("myForm").submit();
    }
}
        // Fungsi untuk validasi formulir
        function validateForm() {
            // Validasi setiap field
            var date = document.getElementsByName("tgl")[0].value;
            var lokasi = document.getElementsByName("lokasi")[0].value;
            var shift = document.querySelector('input[name="shift"]:checked');
            var personil = document.querySelector('input[name="personil"]:checked');
            var ruangan = document.querySelector('input[name="ruangan"]:checked');
            var peralatan = document.querySelector('input[name="peralatan"]:checked');

            // Cek apakah ada field yang kosong
            if (date === "" || lokasi === "" || shift === null || personil === null || ruangan === null || peralatan === null) {
                return false;
            }

            // Validasi tambahan sesuai kebutuhan

            return true; // Form valid jika semua kondisi terpenuhi
        }
        function toggleDropdown(dropdownId) {
        var dropdown = document.getElementById(dropdownId);
        if (dropdown.style.display === 'block') {
            dropdown.style.display = 'none';
        } else {
            dropdown.style.display = 'block';
        }
    }
    </script>   

    </body>
</html>

<?php } ?>