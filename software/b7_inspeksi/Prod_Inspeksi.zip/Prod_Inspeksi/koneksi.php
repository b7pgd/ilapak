<?php 
session_start();
include '../../koneksi.php';

if(isset($_POST["save"])){
    // get the post records
    $lokasi = $_POST['lokasi'];
    $shift = $_POST['shift'];
    $cek_personil = $_POST['personil'];
    $cek_ruangan = $_POST['ruangan'];
    $cek_peralatan = $_POST['peralatan'];
    $ket_personel = $_POST['ket_personil'];
    $ket_ruangan = $_POST['ket_ruangan'];
    $ket_peralatan = $_POST['ket_peralatan'];
    $tgl = $_POST['tgl'];
	//$paraf = $_POST['paraf'];
	$paraf = $_SESSION['username'];


    // database insert SQL code
    $sql = "INSERT INTO tb_pr_inspeksi 
            VALUES (null, '$lokasi', '$shift', '$cek_personil',  '$cek_ruangan', '$cek_peralatan', '$ket_personel', '$ket_ruangan', '$ket_peralatan', '$tgl', '$paraf', '','0000-00-00','0000-00-00', 0, '0000-00-00 00:00:00')";

    // insert in database 
    if(mysqli_query($conn, $sql)){
        echo "<script>alert('Data berhasil disimpan');</script>";

        date_default_timezone_set('Asia/Jakarta');
        $logTimestamp = date("Y-m-d H:i:s");
        $useraktif = $_SESSION['nama'];
        $logActivity = "$useraktif melakukan pengisian form Inspeksi Kebersihan Personil, Ruangan dan Peralatan";
        $ip_address = $_SERVER['REMOTE_ADDR']; // Mendapatkan IP address pengguna
        $area = $_SESSION['area'];
        // $logSql = "INSERT INTO tb_admin_logs (id, tanggal, jam,  alamat_ip, nama, area, kegiatan) VALUES (null, '$logTimestamp', '$logTimestamp', '$ip_address', '$useraktif', '$area', '$logActivity')";
        // $conn->query($logSql);
        
        header('Location: selectlokasi.php');
    } else{
        echo "ERROR: Tidak bisa mengeksekusi SQL. " . mysqli_error($conn);
    }
}

?>
