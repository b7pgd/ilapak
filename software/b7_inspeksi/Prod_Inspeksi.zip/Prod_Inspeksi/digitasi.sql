-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Waktu pembuatan: 19 Des 2023 pada 04.37
-- Versi server: 10.4.28-MariaDB
-- Versi PHP: 8.2.4

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `digitasi`
--

-- --------------------------------------------------------

--
-- Struktur dari tabel `bagian`
--

CREATE TABLE `bagian` (
  `bagian` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data untuk tabel `bagian`
--

INSERT INTO `bagian` (`bagian`) VALUES
('Produksi Liquid'),
('Produksi Powder');

-- --------------------------------------------------------

--
-- Struktur dari tabel `bulan`
--

CREATE TABLE `bulan` (
  `bulan` varchar(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data untuk tabel `bulan`
--

INSERT INTO `bulan` (`bulan`) VALUES
('Januari'),
('Febuari'),
('Maret'),
('April'),
('Mei'),
('Juni'),
('Juli'),
('Agustus'),
('September'),
('Oktober'),
('November'),
('Desember');

-- --------------------------------------------------------

--
-- Struktur dari tabel `cek_peralatan`
--

CREATE TABLE `cek_peralatan` (
  `cek` varchar(3) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data untuk tabel `cek_peralatan`
--

INSERT INTO `cek_peralatan` (`cek`) VALUES
('OK'),
('NOK');

-- --------------------------------------------------------

--
-- Struktur dari tabel `cek_personel`
--

CREATE TABLE `cek_personel` (
  `cek` varchar(3) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data untuk tabel `cek_personel`
--

INSERT INTO `cek_personel` (`cek`) VALUES
('OK'),
('NOK');

-- --------------------------------------------------------

--
-- Struktur dari tabel `cek_ruangan`
--

CREATE TABLE `cek_ruangan` (
  `cek` varchar(3) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data untuk tabel `cek_ruangan`
--

INSERT INTO `cek_ruangan` (`cek`) VALUES
('OK'),
('NOK');

-- --------------------------------------------------------

--
-- Struktur dari tabel `departemen`
--

CREATE TABLE `departemen` (
  `departemen` varchar(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data untuk tabel `departemen`
--

INSERT INTO `departemen` (`departemen`) VALUES
('Produksi PG'),
('Warehouse PG');

-- --------------------------------------------------------

--
-- Struktur dari tabel `inspeksi`
--

CREATE TABLE `inspeksi` (
  `id` int(5) NOT NULL,
  `lokasi` varchar(50) NOT NULL,
  `bagian` varchar(30) NOT NULL,
  `site` varchar(20) NOT NULL,
  `bulan` varchar(40) NOT NULL,
  `shift` varchar(1) NOT NULL,
  `cek_personel` varchar(5) NOT NULL,
  `cek_ruangan` varchar(5) NOT NULL,
  `cek_peralatan` varchar(5) NOT NULL,
  `ket_personel` varchar(50) NOT NULL,
  `ket_ruangan` varchar(50) NOT NULL,
  `ket_peralatan` varchar(50) NOT NULL,
  `tgl` date NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data untuk tabel `inspeksi`
--

INSERT INTO `inspeksi` (`id`, `lokasi`, `bagian`, `site`, `bulan`, `shift`, `cek_personel`, `cek_ruangan`, `cek_peralatan`, `ket_personel`, `ket_ruangan`, `ket_peralatan`, `tgl`) VALUES
(62, 'Compounding Liquid 1', '', '', '', '1', 'OK', 'OK', 'OK', '-', '-', '-', '2023-11-17'),
(63, 'Compounding Liquid 1', '', '', '', '1', 'OK', 'OK', 'NOK', '-', 'tidak apa-apa', 'kurang', '2023-11-17'),
(64, 'Compounding Liquid 1', '', '', '', '1', 'OK', 'OK', 'OK', '-', '-', 'kurang', '2023-11-17'),
(65, 'Compounding Liquid 1', '', '', '', '2', 'OK', 'OK', 'OK', '-', '-', 'kurang', '2023-11-21'),
(68, 'Compounding Liquid 1', '', '', '', '2', 'OK', 'NOK', 'NOK', '-', '-', 'kurang', '2023-11-23'),
(69, 'Compounding Liquid 1', '', '', '', '1', 'OK', 'OK', 'OK', '-', '-', '-', '2023-11-24'),
(70, 'Compounding Liquid 1', '', '', '', '3', 'OK', 'OK', 'NOK', 'tidak apa-apa', 'tidak apa-apa', 'kurang', '2023-11-24'),
(71, 'Compounding Liquid 1', '', '', '', '2', 'OK', 'OK', 'NOK', '-', '-', '-', '2023-11-24'),
(72, 'Compounding Liquid 1', '', '', '', '1', 'OK', 'OK', 'OK', '-', '-', '-', '2023-11-24'),
(73, 'Compounding Liquid 1', '', '', '', '3', 'NOK', 'NOK', 'NOK', 'tidak apa-apa', 'tidak apa-apa', 'kurang', '2023-11-24'),
(76, 'Compounding Liquid 1', '', '', '', '1', 'OK', 'OK', 'OK', '-', '-', '-', '2023-11-29'),
(77, 'Compounding Liquid 1', '', '', '', '3', 'OK', 'OK', 'NOK', '-', 'tidak apa-apa', 'kurang', '2023-11-30'),
(78, 'Compounding Liquid 1', '', '', '', '1', 'OK', 'OK', 'OK', '-', '-', '-', '2023-12-01'),
(79, 'Compounding Liquid 1', '', '', '', '2', 'NOK', 'OK', 'NOK', 'tidak apa-apa', 'tidak apa-apa', '-', '2023-12-06'),
(80, 'Compounding Liquid 1', '', '', '', '1', 'OK', 'OK', 'NOK', 'tidak apa-apa', 'tidak apa-apa', 'kurang', '2023-12-07'),
(81, 'Compounding Liquid 1', '', '', '', '3', 'NOK', 'NOK', 'OK', '-', '-', 'kurang', '2023-12-08'),
(83, 'Compounding Liquid 1', '', '', '', '1', 'OK', 'OK', 'OK', '-', '-', '-', '2023-12-11'),
(100, 'Compounding Liquid 1', '', '', '', '1', 'OK', 'OK', 'OK', 'A', 'B', 'C', '2023-12-15'),
(101, 'Compounding Liquid 1', '', '', '', '1', 'OK', 'NOK', 'NOK', '-', 'tidak apa-apa', 'biss', '2023-12-15'),
(102, 'Compounding Liquid 1', '', '', '', '1', 'NOK', 'NOK', 'NOK', 'tidak apa-apa', 'tidak apa-apa', 'biss11111', '2023-12-15'),
(103, 'Compounding Liquid 1', '', '', '', '1', 'OK', 'NOK', 'OK', 'tidak apa-apa', '123r345yvebt', 'fssf waf', '2023-12-15'),
(104, 'Compounding Liquid 1', '', '', '', '1', 'OK', 'OK', 'OK', 'ewrcwr', 'ecwe', 'bisnillahj', '2023-12-15'),
(105, 'Compounding Liquid 1', '', '', '', '1', 'OK', 'NOK', 'NOK', 'tidak apa-apa', '123r345yvebt', '3', '2023-12-15'),
(106, 'Compounding Liquid 1', '', '', '', '1', 'OK', 'OK', 'OK', 'tidak apa-apa', '123r345yvebt', '-', '2023-12-15'),
(107, 'Compounding Liquid 1', '', '', '', '2', 'OK', 'NOK', 'NOK', '-', 'ecwe', 'biss', '2023-12-15'),
(108, 'Compounding Liquid 1', '', '', '', '1', 'OK', 'OK', 'OK', '-', '-', '-', '2023-12-18'),
(109, 'Filling Solid 1', '', '', '', '1', 'OK', 'NOK', 'NOK', '-', 'B', 'biss', '2023-12-18'),
(115, 'Compounding Liquid 3', '', '', '', '1', 'OK', 'NOK', 'NOK', 'tidak apa-apa', 'B', 'biss11111', '2023-12-18'),
(120, 'Staging Solid 1', '', '', '', '1', 'OK', 'OK', 'NOK', 'tidak apa-apa', 'tidak apa-apa', 'kurang', '2023-12-19'),
(123, 'Compounding Liquid 1', '', '', '', '1', 'OK', 'OK', 'OK', '-', '-', '-', '2023-12-19'),
(125, 'Pilih Lokasi', '', '', '', '1', 'OK', 'OK', 'NOK', 'tidak apa-apa', 'tidak apa-apa', 'kurang', '2023-12-19'),
(126, 'Packaging 1', '', '', '', '1', 'OK', 'OK', 'OK', 'tidak apa-apa', 'B', 'biss11111', '2023-12-19'),
(127, 'Compounding Liquid 1', '', '', '', '1', 'OK', 'OK', 'OK', '-', '3', 'kurang', '2023-12-19'),
(128, 'Compounding Liquid 4', '', '', '', '1', 'OK', 'OK', 'OK', '-', '3', 'biss11111', '2023-12-19'),
(129, 'Filling Liquid 1', '', '', '', '1', 'NOK', 'NOK', 'NOK', '-', '-', 'biss', '2023-12-19'),
(130, 'Compounding Solid 7', '', '', '', '1', 'OK', 'OK', 'OK', '-', '-', 'bismillah', '2023-12-19');

-- --------------------------------------------------------

--
-- Struktur dari tabel `lokasi`
--

CREATE TABLE `lokasi` (
  `lokasi` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data untuk tabel `lokasi`
--

INSERT INTO `lokasi` (`lokasi`) VALUES
('Compounding Liquid 1'),
('Compounding Liquid 2'),
('Compounding Liquid 3'),
('Compounding Liquid 4'),
('Compounding Solid 2'),
('Compounding Solid 4'),
('Compounding Solid 7'),
('Compounding Solid 8'),
('Filling Liquid 1'),
('Filling Liquid 2'),
('Filling Liquid 3'),
('Filling Liquid 4'),
('Filling Liquid 5'),
('Filling Liquid 6'),
('Filling Liquid 7'),
('Filling Liquid 8'),
('Filling Liquid 9'),
('Filling Liquid 10'),
('Filling Liquid 11'),
('Filling Solid 1'),
('Filling Solid 2'),
('Packaging 1'),
('Packaging 2'),
('Packaging 3'),
('Staging Foil 1'),
('Staging RM 2'),
('Staging Solid 1'),
('Staging Solid 5');

-- --------------------------------------------------------

--
-- Struktur dari tabel `shift`
--

CREATE TABLE `shift` (
  `shift` int(1) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data untuk tabel `shift`
--

INSERT INTO `shift` (`shift`) VALUES
(1),
(2),
(3);

-- --------------------------------------------------------

--
-- Struktur dari tabel `site`
--

CREATE TABLE `site` (
  `site` varchar(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data untuk tabel `site`
--

INSERT INTO `site` (`site`) VALUES
('Pulogadung');

-- --------------------------------------------------------

--
-- Struktur dari tabel `tb_pr_ins_comp1`
--

CREATE TABLE `tb_pr_ins_comp1` (
  `id` int(5) NOT NULL,
  `lokasi` varchar(50) NOT NULL,
  `bagian` varchar(30) NOT NULL,
  `site` varchar(20) NOT NULL,
  `bulan` varchar(40) NOT NULL,
  `shift` varchar(1) NOT NULL,
  `cek_personel` varchar(5) NOT NULL,
  `cek_ruangan` varchar(5) NOT NULL,
  `cek_peralatan` varchar(5) NOT NULL,
  `ket_personel` varchar(50) NOT NULL,
  `ket_ruangan` varchar(50) NOT NULL,
  `ket_peralatan` varchar(50) NOT NULL,
  `tgl` date NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Indexes for dumped tables
--

--
-- Indeks untuk tabel `inspeksi`
--
ALTER TABLE `inspeksi`
  ADD PRIMARY KEY (`id`);

--
-- Indeks untuk tabel `tb_pr_ins_comp1`
--
ALTER TABLE `tb_pr_ins_comp1`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT untuk tabel yang dibuang
--

--
-- AUTO_INCREMENT untuk tabel `inspeksi`
--
ALTER TABLE `inspeksi`
  MODIFY `id` int(5) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=131;

--
-- AUTO_INCREMENT untuk tabel `tb_pr_ins_comp1`
--
ALTER TABLE `tb_pr_ins_comp1`
  MODIFY `id` int(5) NOT NULL AUTO_INCREMENT;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
