<?php
session_start();
include '../../koneksi.php';
$username = $_SESSION['username'];
$lokasi = $_SESSION['lokasi'];
// echo $lokasi;

// Ambil tanggal terakhir dari database
$query_last_date = "SELECT tgl AS last_date FROM tb_pr_inspeksi WHERE lokasi = ?";
$stmt = $conn->prepare($query_last_date);
$stmt->bind_param("s", $lokasi);  // Gunakan 's' untuk string
$stmt->execute();
$result_last_date = $stmt->get_result();

// Periksa apakah query berhasil dan memiliki hasil
if ($result_last_date && $result_last_date->num_rows > 0) {
    $row_last_date = $result_last_date->fetch_assoc();
    $last_date = $row_last_date['last_date'];
    $lastdate = strtotime($last_date);
    
    // Ambil semua shift pada tanggal terakhir
    $query_shifts = "SELECT shift FROM tb_pr_inspeksi WHERE tgl = ?";
    $stmt_shifts = $conn->prepare($query_shifts);
    $stmt_shifts->bind_param("s", $last_date);
    $stmt_shifts->execute();
    $result_shifts = $stmt_shifts->get_result();
    
    
    $shifts = array();
    while ($row_shift = $result_shifts->fetch_assoc()) {
        $shifts[] = $row_shift['shift'];
    }
    // echo $shifts;
    
    // Pastikan shift bernilai 1, 2, 3
    $required_shifts = array(1, 2, 3);
    
    // Cek apakah ada shift yang terlewat
    $missing_shifts = array_diff($required_shifts, $shifts);
    
    // sbagai tanggal kemarin
    $end_date = strtotime("7 days ago");

    
    // Debugging
    echo "Last date: $last_date\n";
    // echo "Shifts: " . implode(", ", $shifts) . "\n";
    // echo "Missing shifts: " . implode(", ", $missing_shifts) . "\n";
} else {
    // echo "Tidak ada data ditemukan untuk lokasi: $lokasi.";
}

// Tutup statement
// $stmt->close();
// if (isset($stmt_shifts)) {
//     $stmt_shifts->close();
// }

// Tutup koneksi
// $conn->close();
?>


<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link href="./css/jquery.signaturepad.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css">
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Roboto&family=Roboto+Condensed&display=swap" rel="stylesheet">
    <style>
        .page {
            width: 75%;
            min-height: 100%;
            padding: 5mm;
            margin: 5mm auto;
            border: 1px #D3D3D3 solid;
            border-radius: 5px;
            background: white;
            box-shadow: 0 0 5px rgba(0, 0, 0, 0.1);
        }
        .label-input {
            width: 10%;
            padding-bottom: 8px;
            padding-top: 6px;
            margin-bottom: 15px;
            box-sizing: border-box;
            float: left;
        }
        .levelbtn {
            width: 85%;
            padding: 8px;
            margin-bottom: 15px;
            box-sizing: border-box;
            border: 1px solid #2a5783;
            border-radius: 1px;
            float: right;
        }
        .topnav-right {
            padding: 12px 17px;
            float: right;
            background-color: #2a5783;
            color: #fff;
            border-radius: 2px;
        }
    </style>
</head>
<body>
    <div class="topnav-right">
        <a href="../../Home.php" class="openbtn; fas fa-home" style="text-decoration:none; color:white"></a>
    </div>
    <div class="page">
        <form action="" method="post">
            <h2><center><strong>PILIH KETERANGAN</strong></center></h2>
            
            <label for="ket" class="label-input">KETERANGAN</label>
            <select name="ket" id="ket" class="levelbtn" required>
                <option value="" disabled selected>Pilih Keterangan disini</option>
                <option>Hari libur</option>
                <option>Tidak melakukan pengisian</option>
            </select>

            <label for="tanggal" class="label-input">TANGGAL</label>

            <?php $date_option = date('Y-m-d', $lastdate); ?>

            <input name="tanggal" id="tanggal" class="levelbtn" value="<?php echo $date_option?>" required>

            <label for="shift" class="label-input">SHIFT</label>
            <input name="shift[]" id="shift" class="levelbtn" 
            value="
            <?php
                // Misalkan $shifts adalah array yang berisi nilai shift
                // Contoh: $shifts = [1, 1, 2, 3, 3];

                // Menghilangkan duplikasi nilai
                $shifts_unique = array_unique($shifts);

                // Mengurutkan array untuk memastikan urutannya konsisten
                sort($shifts_unique);

                // Menggabungkan nilai array menjadi string
                $a = implode(", ", $shifts_unique);

                // Logika berdasarkan deskripsi
                if ($a == '1') {
                    $b = 2;
                } elseif ($a == '1, 2') {
                    $b = 3;
                } elseif ($a == '1, 2, 3') {
                    // Redirect ke halaman baru
                    header('Location: form_inspeksi.php');
                    exit; // Pastikan keluar dari skrip setelah redirect
                } else {
                    // alert
                    // header('Location: selectlokasi.php');
                }

                echo $b;
            ?>

            " required>

            <input style="width:100%" type="submit" name="save" value="save">
        </form>

        <?php

if (isset($_POST["save"])) {
    $ket = $_POST['ket'];
    $date_option = $_POST['tanggal'];
    $missing_shifts = $_POST['shift']; // Ambil nilai shift yang terlewat

    // Jika ada shift yang terlewat, tambahkan input untuk masing-masing shift
    if (!empty($missing_shifts)) {
        foreach ($missing_shifts as $shift) {
            echo "Shift terlewat: $shift <br>";
            // Lakukan proses penyimpanan atau tindakan lain untuk masing-masing shift di sini
            // Contoh: INSERT ke database untuk setiap shift
            $query_insert = "INSERT INTO tb_pr_inspeksi 
                            VALUES (null, '$lokasi', $shift, '', '', '', '', '','', '$date_option', '', '', '0000-00-00', '0000-00-00', 0, '0000-00-00 00:00:00' )";
            mysqli_query($conn, $query_insert);
        }
    }

    // Tutup koneksi database
    // mysqli_close($conn);

    echo "<script>
            alert('Data Lengkap! Terima Kasih!');
            window.location.href='selectlokasi.php';
        </script>";
    exit();
}


        ?>
    </div>
</body>
</html>
