<?php 
session_start(); 


?>

<!doctype html>
<html lang="en">
    <head>
        <link rel="shortcut icon" href="../img/LOGO HD copy.png" type="image/png">
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <title>Dashboard</title>
        <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-T3c6CoIi6uLrA9TneNEoa7RxnatzjcDSCmG1MXxSR1GAsXEV/Dwwykc2MPK8M2HN" crossorigin="anonymous">
        
        <link rel="stylesheet" href="../css/dashboard.css">
        <link rel="stylesheet" href="../login.css">
        <!-- <link rel="stylesheet" href="style.css"> -->
    </head>
    <body>
    <form action="relogin_validasi_revisi.php" method="post">
        <?php
            if(isset($_POST['save'])){
                $_SESSION['id'] = $_POST['id'];
                $id = $_SESSION['id'];
                ?>

<input type="hidden" name="id" value="<?php echo $id; ?>">

                <div class="page">
                <div class="container text-left">
                        <img style="width: 150px;" src="../img/Bintang-Toedjo-removebg-preview (1).png" alt="">
                        <p class="tulisan_login"><strong>Silahkan Masukkan Username dan Password</strong></p>
                                <br>
                                <table style= "width:100%;">
                                    <thead>
                                        <tr>
                                            <th></th>
                                            <th><label><strong>Username</strong></label></th>
                                        </tr>
                                        <tr>
                                            <th><img src="../../../img/login.jpg" alt="Logo Image" height="35px"></th>
                                            <th><input type="text" name="username" class="form_login" placeholder="Username.." required="required"></th>
                                        </tr>

                                        <tr>
                                            <th></th>
                                            <th><label><strong>Password</strong></label></th>
                                        </tr>
                                        <tr>
                                            <th><img src="../../../img/key copy.png" alt="Logo Image" height="35px"></th>
                                            <th><input type="password" name="password" class="form_login" placeholder="Password.." required="required"></th>
                                        </tr>
                                    </thead>
                                </table>
                                <br>
                                    <input style= "width:100%;" type="submit" class="tombol_login" name="LOGIN" value="LOGIN">                      
                                    <br/><br/>
                    </div>
                    </div>';
                <?php }
        ?>
    </form>

     </body>
</html>

<!--------------------------------------------------------- SCRIPT -------------------------------------------------------->


<!--------------------------------------------------------- STYLE -------------------------------------------------------->
  <style>
      #loginBtn {
            /* Gaya latar belakang dan warna teks */
            background-color: #2a5783;
            color: whitesmoke;

            /* Gaya padding dan border */
            padding: 8px 20px;
            border: none;
            border-radius: 8px; /* Sudut melengkung pada sudut tombol */

            /* Gaya kursor saat mengarahkan */
            cursor: pointer;

            /* Gaya hover */
            transition: background-color 0.3s;
        }

        #loginBtn:hover {
            background-color: whitesmoke;
            color: #2a5783;
            border: 1px solid #2a5783;
        }

        .page {
            width: 350px;
            min-height: 300px;
            padding: 5mm;
            margin: 5mm auto;
            border: 1px #D3D3D3 solid;
            border-radius: 5px;
            background: white;
            box-shadow: 0 0 5px rgba(0, 0, 0, 0.1);
        }
    </style>