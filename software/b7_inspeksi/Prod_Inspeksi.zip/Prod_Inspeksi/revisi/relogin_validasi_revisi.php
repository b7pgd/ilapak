<?php
session_start();
include '../../../koneksi.php';

if (isset($_POST['LOGIN'])) {
    $username = $_POST['username'];
    $password = $_POST['password'];
    $_SESSION['id'] = $_POST['id'];
    $id = $_SESSION['id'];

    // Mengambil data dari database berdasarkan username
    $query = "SELECT * FROM tb_admin_user WHERE username='$username'";
    $result = mysqli_query($conn, $query);

    if (mysqli_num_rows($result) == 1) {
        $row = mysqli_fetch_array($result);

        // Verifikasi password menggunakan password_verify
        if (password_verify($password, $row['password'])) {
            // Password cocok, inisialisasi sesi
            $username = $row['username'];
            $level = $row['level'];
            
            // database insert SQL code

            if ($level == 'administrator' or $level == 'supervisor'or $level == 'manager') {
                // echo $id;
                echo "<meta http-equiv='refresh' content='0;url=edit.php'>";   
                
                
            } elseif ($level == 'staff_tk' or $level == 'staff_prod' or $level == 'staff_wh' or $level == 'staff_ts'){
                echo "<script>alert('Anda tidak bisa melakukan validasi!');</script>";
                echo "<meta http-equiv='refresh' content='0;url=../report_inspeksi.php'>";
                exit();
            }
        } else {
            // Password tidak cocok
            echo "<script>alert('Password salah!');</script>";
            echo "<meta http-equiv='refresh' content='0;url=../report_inspeksi.php'>";
            exit();
        }
    } else {
        // Username tidak ditemukan
        echo "<script>alert('Username tidak tersedia!');</script>";
        echo "<meta http-equiv='refresh' content='0;url=../report_inspeksi.php'>";
        exit();
    }
}
?>
