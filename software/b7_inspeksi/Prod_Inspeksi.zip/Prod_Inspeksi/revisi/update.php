<?php 
include '../../../koneksi.php';
session_start();

if(isset($_POST["save"])){
    // menangkap data yang dikirim dari form
    $id = $_POST['id'];
    $tgl = $_POST['tgl'];
    $lokasi = $_POST['lokasi'];
    $shift = $_POST['shift'];
    $cek_personel = $_POST['cek_personel'];
    $ket_personel = $_POST['ket_personel'];
    $cek_ruangan = $_POST['cek_ruangan'];
    $ket_ruangan = $_POST['ket_ruangan'];
    $cek_peralatan = $_POST['cek_peralatan'];
    $ket_peralatan = $_POST['ket_peralatan'];
    $paraf = $_POST['paraf'];
    $rev_number = $_POST['rev_num'];
    $rev_num = $rev_number +1;

    date_default_timezone_set('Asia/Jakarta');
    $logTimestamp = date("Y-m-d H:i:s");
    $useraktif = $_SESSION['username'];
    $rev_date = $logTimestamp;

    // menangkap data yang diambil dari database
    $atgl = $_POST['atgl'];
    $alokasi = $_POST['alokasi'];
    $ashift = $_POST['ashift'];
    $acek_personel = $_POST['acek_personel'];
    $aket_personel = $_POST['aket_personel'];
    $acek_ruangan = $_POST['acek_ruangan'];
    $aket_ruangan = $_POST['aket_ruangan'];
    $acek_peralatan = $_POST['acek_peralatan'];
    $aket_peralatan = $_POST['aket_peralatan'];
    $aparaf = $_POST['aparaf'];
    $aparaf_spv = $_POST['aparaf_spv'];
    $arev_number = $_POST['arev_num'];

    // update data ke database
    $sql="UPDATE tb_pr_inspeksi SET 
        tgl='$tgl',
        lokasi='$lokasi',
        shift='$shift',
        cek_personel='$cek_personel',
        ket_personel='$ket_personel',
        cek_ruangan='$cek_ruangan',
        ket_ruangan='$ket_ruangan',
        cek_peralatan='$cek_peralatan',
        ket_peralatan='$ket_peralatan',
        paraf='$paraf',
        rev_num='$rev_num',
        rev_date='$rev_date'
        WHERE id='$id'";

    if ($conn->query($sql) === TRUE) {
        // Catat log trail
        date_default_timezone_set('Asia/Jakarta');
        $logTimestamp = date("Y-m-d H:i:s");
        $useraktif = $_SESSION['nama'];
        $logActivity = "$useraktif melakukan pengisian form Inspeksi Kebersihan Personil, Ruangan dan Peralatan";
        $ip_address = $_SERVER['REMOTE_ADDR']; // Mendapatkan IP address pengguna
        $area = $_SESSION['area'];

        $alogActivity = "$useraktif memperbarui data Form Inspeksi Kebersihan Personel, Ruangan dan Peralatan.
                    Data sebelumnya:
                    Tanggal : $atgl,
                    Lokasi : $alokasi,
                    Shift : $ashift,
                    Cek Personel : $acek_personel,
                    Keterangan Personel : $aket_personel,
                    Cek Ruangan : $acek_ruangan,
                    Keterangan Ruangan : $aket_ruangan,
                    Cek Peralatan : $acek_peralatan,
                    Keterangan Peralatan : $aket_peralatan,
                    Paraf User : $aparaf,
                    Paraf Pemeriksa : $aparaf_spv,
                    Nomor Revisi : $arev_number";

                    $alogSql = "INSERT INTO tb_admin_logs (id, tanggal, jam,  alamat_ip, nama, area, kegiatan) 
                                VALUES (null, '$alogTimestamp', '$alogTimestamp', '$ip_address', '$auseraktif', '$area', '$alogActivity')";
                    mysqli_query($conn, $alogSql);

        $logActivity = "$useraktif memperbarui data Form Inspeksi Kebersihan Personel, Ruangan dan Peralatan.
        Data setelah perubahan: 
        Tanggal : $tgl,
        Lokasi : $lokasi,
        Shift : $shift,
        Cek_personel : $cek_personel,
        Ket_personel : $ket_personel,
        Cek_ruangan : $cek_ruangan,
        Ket_ruangan : $ket_ruangan,
        Cek_peralatan : $cek_peralatan,
        Ket_peralatan : $ket_peralatan,
        Teknisi : $paraf,
        Nomor Revisi : $rev_num";

        $logSql = "INSERT INTO tb_admin_logs (id, tanggal, jam,  alamat_ip, nama, area, kegiatan) 
                    VALUES (null, '$alogTimestamp', '$alogTimestamp', '$ip_address', '$auseraktif', '$area', '$logActivity')";
        $conn->query($logSql);
        
        echo "<script>alert('Data berhasil disimpan');</script>";
        echo "<script>window.location.href='../report_inspeksi.php';</script>";
    }

    // unset($_SESSION['variabel']); >> untuk mengakhiri sesi dari sebuah variabel
    unset($_SESSION['id']);

    exit();
}

// Check connection
if (mysqli_connect_errno()){
    echo "Koneksi database gagal : " . mysqli_connect_error();
}
  
?>