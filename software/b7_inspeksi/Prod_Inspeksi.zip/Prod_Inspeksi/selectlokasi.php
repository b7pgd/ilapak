<?php
session_start();
include '../../koneksi.php';
?>
<!DOCTYPE html>
<html>
<head>
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css">
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Roboto&family=Roboto+Condensed&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="b.css">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet"
    integrity="sha384-T3c6CoIi6uLrA9TneNEoa7RxnatzjcDSCmG1MXxSR1GAsXEV/Dwwykc2MPK8M2HN"
    crossorigin="anonymous">
    <style>
        /* Gaya CSS untuk tabel */
    table {
            border-collapse: collapse;
            width: 100%;
        }

        /* Gaya CSS untuk header kolom tabel dan baris genap */
        th,
        td {
            padding: 8px;
            text-align: center;
            border: 1px solid black;
        }

        /* Gaya CSS untuk header tabel */
        th {
            background-color: #ccc;
        }

        /* Gaya CSS untuk baris genap pada tabel */
        tr:nth-child(even) {
            background-color: #f2f2f2;
            border: 1px solid black;
        }

        /* Gaya CSS untuk header baris pada tabel */
        th {
            background-color: #f2f2f2;
            border: 1px solid black;
        }
        /* Styles untuk tampilan layar */
        @media screen {
            #mySidebar {
                display: block; /* Tampilkan sidebar pada tampilan layar */
            }

            #main {
                transition: margin-left 0.5s;
            }
        }

        /* Styles untuk proses print */
        @media print {
            #mySidebar {
                display: none !important; /* Sembunyikan sidebar pada saat mencetak */
            }

            #main {
                margin-left: 0 !important; /* Atur margin kiri ke 0 saat mencetak */
            }
        }
        @media print {
            .topnav-right {
                display: none !important;
            }

            .openbtn {
                display: none !important;
            }
        }
        /* Gaya CSS saat mode cetak untuk footer */
        @media print {
            #footer {
             display: block; /* Tampilkan footer saat mencetak */
                    }
            }
            #footer {
            position: fixed;
            bottom: 0px;
            left: 0px;
            width: 100%;
            padding: 8px;
            display: none; /* Sembunyikan footer secara default */
            }

            /* Gaya CSS saat mode cetak untuk footer */
            @media print {
            #footer {
            display: block; /* Tampilkan footer saat mencetak */
                    }
                }
    </style>
</head>
<body>
<!------------------------------------------------------------ SIDE BAR ------------------------------------------------------------>

<div id="mySidebar" class="sidebar">
                <!-- <a><img src="../../img/login.jpg" style="height: 100px" alt="" /></a> -->
                <span><i class="fa-solid fa-user"></i></span>
            <h4><a>
                <?php
                    if (isset($_SESSION['username']) == $_SESSION['username']) {
                        // Tampilkan username di sini
                        echo "Hai, ", $_SESSION['username'], "!";
                    }
                ?>
            </a></h4>
            <a href="javascript:void(0)" class="closebtn" onclick="closeNav()">&times;</a>
            

            <div class="text">
            <?php

                function form(){
                    echo '<a style="cursor:pointer;" onclick="form()">
                        <i  class="fa-solid fa-file style="margin-right: 8px; font-size: 18px;"></i>
                        Pilih Form Departemen
                    </a>

                    <div id="form" class="toggle-element" style="display: none;">
                        <a href="../../pr_pilih_form.php"><i  class="fa-solid fa-file style="margin-right: 8px; font-size: 18px;"></i>Production</a>
                        <a href="../../engineering/eng_pilih_form.php"><i  class="fa-solid fa-file style="margin-right: 8px; font-size: 18px;"></i>Engineering</a>
                        <a href="../../warehouse/wh_pilih_form.php"><i  class="fa-solid fa-file style="margin-right: 8px; font-size: 18px;"></i>Warehouse</a>
                        <a href="../../technical_service/ts_pilih_form.php"><i  class="fa-solid fa-file style="margin-right: 8px; font-size: 18px;"></i>Technical Service</a>
                        <a href="#"><i  class="fa-solid fa-file style="margin-right: 8px; font-size: 18px;"></i>General Affair</a>
                    </div>';
                }
                function preview(){
                    echo '<a style="cursor:pointer;" onclick="preview()">
                        <i class="fa-solid fa-clock-rotate-left" style="margin-right: 8px; font-size: 18px;"></i>
                        Preview Form
                    </a>

                    <div id="preview" class="toggle-element" style="display: none;">
                        <a href="../../pr_pilih_preview.php"><i class="fa-solid fa-clock-rotate-left" style="margin-right: 8px; font-size: 18px;"></i>Production</a>
                        <a href="../../engineering/eng_pilih_preview.php"><i class="fa-solid fa-clock-rotate-left" style="margin-right: 8px; font-size: 18px;"></i>Engineering</a>
                        <a href="../../warehouse/wh_pilih_preview.php"><i class="fa-solid fa-clock-rotate-left" style="margin-right: 8px; font-size: 18px;"></i>Warehouse</a>
                        <a href="../../technical_service/ts_pilih_preview.php"><i class="fa-solid fa-clock-rotate-left" style="margin-right: 8px; font-size: 18px;"></i>Technical Service</a>
                        <a href="#"><i class="fa-solid fa-clock-rotate-left" style="margin-right: 8px; font-size: 18px;"></i>General Affair</a>
                    </div>';
                }
                function side_admin(){
                    echo
                    '    
                    <a href="../../admin/user_list.php"><i class="fa-solid fa-list" style="margin-right: 6px; font-size: 18px;"></i> User Account List</a>
                    <a href="../../admin/operation_log.php"><i class="fa-solid fa-rectangle-list" style="margin-right: 8px; font-size: 18px;"></i>Operation Log</a>
                    ';
                    form();
                    preview();
                    echo '<a href="../../logout.php"><i class="fa-solid fa-power-off" style="margin-right: 8px; font-size: 18px;"></i>Logout</a>'
                    ;
                }
                
                function side_supmager(){
                    echo '<a href="../../admin/operation_log.php">Operation Log</a>';
                    form();
                    preview();
                    echo '<a href="../../logout.php"><i class="fa-solid fa-power-off" style="margin-right: 8px; font-size: 18px;"></i>Logout</a>'
                    ;
                }
                function side_staff(){

                    switch ($_SESSION['level']) {
                        case "staff_tk":
                            
                            break;
            
                        case "staff_prod":
                            echo 
                            '<a href=../pr_pilih_form.php>
                            <i  class="fa-solid fa-file style="margin-right: 8px; font-size: 18px;"></i>
                            Pilih Form</a>
                            <a href=../pr_pilih_preview.php>
                            <i class="fa-solid fa-clock-rotate-left" style="margin-right: 8px; font-size: 18px;"></i>
                            Preview</a>
                            <a href="../../logout.php"><i class="fa-solid fa-power-off" style="margin-right: 8px; font-size: 18px;"></i>Logout</a>'
                            ;
                            break;
                        
                        case "staff_wh":
                            
                            break;
                        
                        case "staff_ts":
                            
                            break;
    
                        case "staff_ga":
                            
                            break;
            
                        default:
                            echo "<meta http-equiv='refresh'>";
                            break;
                        }
                   
                }

                

                switch ($_SESSION['level']) {
                    case "staff_prod":
                        side_staff();
                        break;
        
                    case "staff_tk":
                        side_staff();
                        break;
                    
                    case "staff_wh":
                        side_staff();
                        break;
                    
                    case "staff_ts":
                        side_staff();
                        break;

                    case "staff_ga":
                        side_staff();
                        break;

                    case "supervisor":
                        side_supmager();
                        break;

                    case "manager":
                        side_supmager();
                        break;

                    case "administrator":
                        side_admin();
                        break;
        
                    default:
                        echo "<meta http-equiv='refresh'>";
                        break;
                    }
            ?>
        </div>
        </div>

        <script>
            function openNav() {
            document.getElementById("mySidebar").style.width = "250px";
            document.getElementById("main").style.marginLeft = "250px";
            }

            function closeNav() {
            document.getElementById("mySidebar").style.width = "0";
            document.getElementById("main").style.marginLeft= "0";
            }
        </script>
<!------------------------------------------------------------ BATAS SIDE BAR ------------------------------------------------------------>
<div id="main">
    <div class="topnav-right">
        <a href="../pr_pilih_form.php" class="openbtn" style="text-decoration:none">&larr;</a>
    </div>
    <button class="openbtn" onclick="openNav()">&equiv;</button>   
    <div class="container mt-4">
        <div class="card">
            <div class="card-header" style="background-color: #2a5783;">
                <h4 class="text-center" style="color: white;"><strong>Select Lokasi</strong></h4>
            </div>
            <div class="card-body">
                <form method="POST" action="form_inspeksi.php" id="myForm">
                    <div class="row">
                        <div class="col-md-12">
                            <label for="lokasi">Lokasi :</label>
                            <select name="lokasi" class="form-control" required>
                                <option value="" selected disabled>Pilih Lokasi</option>
                                <?php
                                    include '../../koneksi.php';
                                    $connlokasi = mysqli_query($conn, "SELECT DISTINCT lokasi FROM tb_pr_lokasi");
                                    while ($data = mysqli_fetch_array($connlokasi)) {
                                        echo "<option value='" . $data['lokasi'] . "'>" . $data['lokasi'] . "</option>";
                                    }
                                ?>
                            </select>
                        </div>
                    </div>

                    <!-- Additional form fields for Shift, Personil, Ruangan, Peralatan, etc. -->

                    <div class="mt-3">
                        <input type="submit" onclick="submitForm()" name="save" value="Submit" class="btn btn-success">
                    </div>
                </form>
            </div>
        </div>
    </div>
</div>

<script>
    function submitForm() {
            console.log("Submit button clicked!");
            // Validasi form sebelum submit
            if (validateForm()) {
                // Lakukan operasi submit atau simpan data
                alert("Data berhasil disubmit!");
                document.getElementById("myForm").submit(); // Ganti "myForm" dengan ID form Anda
            } else {
                // Tampilkan popup "isi secara lengkap" jika form tidak valid
                alert("Harap isi semua field secara lengkap!");
            }
        }
        function validateAndSubmit() {
    var lokasi = document.getElementsByName("lokasi")[0].value;

    // Cek apakah opsi yang dipilih adalah "Pilih Lokasi"
    if (lokasi === "") {
        alert("Harap pilih lokasi yang valid!");
    } else {
        // Lakukan operasi submit atau simpan data
        alert("Data berhasil disubmit!");
        document.getElementById("myForm").submit();
    }
}
        // Fungsi untuk validasi formulir
        function validateForm() {
            // Validasi setiap field
            var date = document.getElementsByName("tgl")[0].value;
            var lokasi = document.getElementsByName("lokasi")[0].value;
            var shift = document.querySelector('input[name="shift"]:checked');
            var personil = document.querySelector('input[name="personil"]:checked');
            var ruangan = document.querySelector('input[name="ruangan"]:checked');
            var peralatan = document.querySelector('input[name="peralatan"]:checked');

            // Cek apakah ada field yang kosong
            if (date === "" || lokasi === "" || shift === null || personil === null || ruangan === null || peralatan === null) {
                return false;
            }

            // Validasi tambahan sesuai kebutuhan

            return true; // Form valid jika semua kondisi terpenuhi
        }
        function toggleDropdown(dropdownId) {
        var dropdown = document.getElementById(dropdownId);
        if (dropdown.style.display === 'block') {
            dropdown.style.display = 'none';
        } else {
            dropdown.style.display = 'block';
        }
    }
</script>

</body>
</html>
