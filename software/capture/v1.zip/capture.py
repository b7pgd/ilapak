import os
import sys
import time
import json
import datetime

try:
    import pywinauto
    from pywinauto import Desktop, Application
    from pywinauto.controls.uiawrapper import UIAWrapper
except ImportError:
    print("[ERROR] 'pywinauto' library is not installed.")
    print("Please install it using: pip install pywinauto")
    sys.exit(1)

# File log tunggal dalam format JSON ringkas
JSON_LOG_FILE = "capture.json"

# Konfigurasi pencarian window 3WS
TARGET_PROCESS_NAMES = ["3ws.exe", "3ws.net.exe"]
TARGET_WINDOW_TITLE_KEYWORDS = ["Penimbangan FG"]

# Interval polling (detik)
SEARCH_INTERVAL = 1.0
MONITOR_INTERVAL = 1.0

# Mapping Automation ID ke Field Target
TARGET_AUTOMATION_IDS = {
    "1705480": "work_order",
    "395160": "formula",
    "1050396": "batch",
    "btnIncompleteMB": "incomplete_mb",
    "btnLastMB": "last_mb"
}

def safe_get_process_name(pid: int) -> str:
    if not pid:
        return "unknown"
    try:
        mod = pywinauto.application.process_module(pid)
        return os.path.basename(mod).lower() if mod else "unknown"
    except Exception:
        return "unknown"

def find_target_window():
    """
    Mempertahankan mekanisme discovery awal tanpa diagnostic noise.
    """
    # Tahap A: UIA Discovery
    try:
        desktop_uia = Desktop(backend="uia")
        windows_uia = desktop_uia.windows()
        for win in windows_uia:
            try:
                info = win.element_info
                win_title = info.name or ""
                pid = info.process_id or 0
                proc_name_str = safe_get_process_name(pid)

                title_match = any(kw.lower() in win_title.lower() for kw in TARGET_WINDOW_TITLE_KEYWORDS)
                proc_match = any(p.lower() in proc_name_str for p in TARGET_PROCESS_NAMES)

                if title_match or proc_match:
                    return win, {
                        "title": win_title,
                        "process_name": proc_name_str,
                        "pid": pid,
                        "hwnd": hex(win.handle) if win.handle else "0x0"
                    }
            except Exception:
                continue
    except Exception:
        pass

    # Tahap B: Win32 Fallback Discovery jika UIA miss
    try:
        desktop_win32 = Desktop(backend="win32")
        windows_win32 = desktop_win32.windows()
        for win in windows_win32:
            try:
                win_title = win.window_text() or ""
                hwnd = win.handle
                pid = win.process_id()
                proc_name_str = safe_get_process_name(pid)

                title_match = any(kw.lower() in win_title.lower() for kw in TARGET_WINDOW_TITLE_KEYWORDS)
                proc_match = any(p.lower() in proc_name_str for p in TARGET_PROCESS_NAMES)

                if title_match or proc_match:
                    app = Application(backend="uia").connect(handle=hwnd)
                    uia_win = app.window(handle=hwnd)
                    return uia_win, {
                        "title": win_title,
                        "process_name": proc_name_str,
                        "pid": pid,
                        "hwnd": hex(hwnd)
                    }
            except Exception:
                continue
    except Exception:
        pass

    return None, None

def get_element_value(element: UIAWrapper) -> str:
    """
    Mekanisme pembacaan value dari kode awal yang terbukti bekerja:
    1. iface_value.CurrentValue
    2. texts() fallback
    3. iface_legacy_iaccessible.CurrentValue fallback
    """
    val = ""
    try:
        if hasattr(element, "iface_value") and element.iface_value:
            val = str(element.iface_value.CurrentValue or "").strip()
    except Exception:
        pass

    if not val:
        try:
            texts = element.texts()
            if texts:
                filtered = [t.strip() for t in texts if t and t.strip()]
                if filtered:
                    val = " | ".join(filtered)
        except Exception:
            pass

    if not val:
        try:
            if hasattr(element, "iface_legacy_iaccessible") and element.iface_legacy_iaccessible:
                val = str(element.iface_legacy_iaccessible.CurrentValue or "").strip()
        except Exception:
            pass

    return val

def extract_target_fields(element: UIAWrapper, target_data: dict = None) -> dict:
    """
    Menggunakan traversal tree element.children() persis seperti kode awal,
    tetapi hanya memfilter dan mengambil 5 control target berdasarkan Automation ID.
    """
    if target_data is None:
        target_data = {}

    try:
        auto_id = str(element.element_info.automation_id or "").strip()

        if auto_id in TARGET_AUTOMATION_IDS:
            field_name = TARGET_AUTOMATION_IDS[auto_id]
            control_type = str(element.element_info.control_type or "").lower()

            if "button" in control_type or auto_id.startswith("btn"):
                # Handling Button Control
                exists = True
                is_enabled = False
                try:
                    is_enabled = bool(element.is_enabled())
                except Exception:
                    pass
                target_data[field_name] = {
                    "exists": exists,
                    "enabled": is_enabled
                }
            else:
                # Handling Edit Control (Work Order, Formula, Batch)
                target_data[field_name] = get_element_value(element)

        # Early exit jika 5 target sudah terkumpul
        if len(target_data) >= 5:
            return target_data

        children = element.children()
        for child in children:
            extract_target_fields(child, target_data)
            if len(target_data) >= 5:
                break
    except Exception:
        pass

    return target_data

def normalize_target_state(extracted: dict) -> dict:
    """
    Memastikan 5 field memiliki struktur lengkap/default.
    """
    return {
        "work_order": extracted.get("work_order", ""),
        "formula": extracted.get("formula", ""),
        "batch": extracted.get("batch", ""),
        "incomplete_mb": extracted.get("incomplete_mb", {"exists": False, "enabled": False}),
        "last_mb": extracted.get("last_mb", {"exists": False, "enabled": False})
    }

def load_or_init_json_log() -> dict:
    if os.path.exists(JSON_LOG_FILE):
        try:
            with open(JSON_LOG_FILE, "r", encoding="utf-8") as f:
                data = json.load(f)
                if isinstance(data, dict) and "captures" in data:
                    return data
        except Exception:
            pass

    return {
        "tool": "capture.py",
        "target": {},
        "captures": []
    }

def save_json_log(data: dict):
    temp_file = JSON_LOG_FILE + ".tmp"
    with open(temp_file, "w", encoding="utf-8") as f:
        json.dump(data, f, indent=2, ensure_ascii=False)
    os.replace(temp_file, JSON_LOG_FILE)

def main():
    log_data = load_or_init_json_log()
    target_win = None
    target_info = None
    last_state = None
    window_was_found = False

    try:
        while True:
            # 1. WINDOW DISCOVERY
            if target_win is None:
                if not window_was_found:
                    print("[WAITING] Penimbangan FG not found")
                
                win, info = find_target_window()

                if win is not None:
                    target_win = win
                    target_info = info
                    log_data["target"] = target_info
                    save_json_log(log_data)

                    print(f"[FOUND] Penimbangan FG attached (PID: {target_info['pid']}, HWND: {target_info['hwnd']})")
                    window_was_found = True
                else:
                    window_was_found = False
                    time.sleep(SEARCH_INTERVAL)
                    continue

            # 2. UIA EXTRACTION & MONITORING
            try:
                # Validasi root window
                _ = target_win.element_info.name

                raw_extracted = extract_target_fields(target_win)
                current_state = normalize_target_state(raw_extracted)

                # Syarat validitas aktivitas awal (agar startup kosong tidak trigger event palsu)
                has_valid_data = bool(current_state["work_order"] and (current_state["formula"] or current_state["batch"]))

                if current_state != last_state:
                    if last_state is None:
                        # Event Perdana saat data valid terdeteksi
                        if has_valid_data:
                            timestamp = datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S.%f")[:-3]
                            
                            event_entry = {
                                "timestamp": timestamp,
                                "event": "activity_detected",
                                "work_order": current_state["work_order"],
                                "formula": current_state["formula"],
                                "batch": current_state["batch"],
                                "incomplete_mb": current_state["incomplete_mb"],
                                "last_mb": current_state["last_mb"]
                            }

                            log_data["captures"].append(event_entry)
                            save_json_log(log_data)

                            print(f"\n[CAPTURE] {timestamp}")
                            print(f"  Event              : activity_detected")
                            print(f"  WO                 : {current_state['work_order']}")
                            print(f"  Formula            : {current_state['formula']}")
                            print(f"  Batch              : {current_state['batch']}")
                            print(f"  Incomplete MB      : exists={str(current_state['incomplete_mb']['exists']).lower()} enabled={str(current_state['incomplete_mb']['enabled']).lower()}")
                            print(f"  Master Box Terakhir: exists={str(current_state['last_mb']['exists']).lower()} enabled={str(current_state['last_mb']['enabled']).lower()}")
                            
                            last_state = current_state
                    else:
                        # Event Perubahan Data (WO / Batch / Button state berubah)
                        timestamp = datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S.%f")[:-3]

                        event_entry = {
                            "timestamp": timestamp,
                            "event": "data_changed",
                            "work_order": current_state["work_order"],
                            "formula": current_state["formula"],
                            "batch": current_state["batch"],
                            "incomplete_mb": current_state["incomplete_mb"],
                            "last_mb": current_state["last_mb"]
                        }

                        log_data["captures"].append(event_entry)
                        save_json_log(log_data)

                        print(f"\n[CAPTURE] {timestamp}")
                        print(f"  Event              : data_changed")
                        print(f"  WO                 : {current_state['work_order']}")
                        print(f"  Formula            : {current_state['formula']}")
                        print(f"  Batch              : {current_state['batch']}")
                        print(f"  Incomplete MB      : exists={str(current_state['incomplete_mb']['exists']).lower()} enabled={str(current_state['incomplete_mb']['enabled']).lower()}")
                        print(f"  Master Box Terakhir: exists={str(current_state['last_mb']['exists']).lower()} enabled={str(current_state['last_mb']['enabled']).lower()}")

                        last_state = current_state

            except Exception as e:
                print("[LOST] Penimbangan FG unavailable")
                target_win = None
                target_info = None
                last_state = None
                window_was_found = False

            time.sleep(MONITOR_INTERVAL)

    except KeyboardInterrupt:
        print("\n[STOP] Capture stopped.")
        save_json_log(log_data)
        sys.exit(0)

if __name__ == "__main__":
    main()