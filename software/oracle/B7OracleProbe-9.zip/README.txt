B7OracleProbe v0.11 - Proof of Concept
====================================
Program sederhana (bukan Python) untuk membuktikan apakah Oracle EBS Forms
(Java) bisa di-record: baca teks BPP, record klik Submit, baca Request ID,
baca baris teratas daftar Requests.

BARU DI v0.11: dua perbaikan dari hasil tes v0.10.
1) "ORACLE TERHUBUNG" sempat salah mendeteksi jendela cmd program ini
sendiri (judulnya path EXE dan foldernya bernama "oracle") — sekarang
judul harus diawali "Oracle" dan jendela sendiri dikecualikan, jadi
notif hanya muncul untuk jendela Oracle asli.
2) R kini juga memasang JAVA_TOOL_OPTIONS di environment user (HKCU,
TANPA Admin): "-Djavax.accessibility.assistive_technologies=...".
JVM membaca variabel ini sendiri saat start, apa pun launcher-nya
(java.exe, javaws.exe, jp2launcher.exe) — jadi kalau file
.accessibility.properties tidak dibaca JVM Oracle, jalur ini tetap
memasukkan properti bridge-nya. Sekali saja per PC/user; perlu
tutup-buka browser sekali supaya browser mewarisi variabel baru ini
sebelum membuka Oracle. Probe juga kini memuat DLL bridge dari folder
bin Java dulu (bukan dari PATH/System32) supaya versinya sama dengan
JVM Oracle, dan DIAGNOSA runtime kini mengecek msvcr100.dll juga.

BARU DI v0.10: notif "ORACLE TERHUBUNG" — probe mendeteksi jendela
Oracle lewat judulnya (Win32, TANPA bridge), jadi kepastian "Oracle
terhubung" muncul begitu Oracle dibuka, dan "ORACLE TERPUTUS" kalau
jendelanya hilang. Sambil merekam, tiap 15 detik ada detak "Masih
merekam... Oracle: TERHUBUNG / belum terdeteksi", jadi log tidak pernah
kosong mlompong lagi. Begitu bridge jalan, tiap menu yang dibuka juga
muncul live ("ORACLE: masuk 'Find Batches (BPG)'", "... 'Submit
Request'", "... 'Decision'"). Catatan jujur: menu-menu itu frame
internal Swing tanpa jendela Windows sendiri, jadi HANYA kebaca lewat
bridge — tanpa bridge, yang terlihat cuma jendela utama Oracle.
Cek proses Java kini juga mengenali jp2launcher.exe (launcher .jnlp
yang dipakai Oracle di PC ini, bukan javaws.exe), dan DIAGNOSA kini
mengecek runtime yang dibutuhkan JavaAccessBridge (VCRUNTIME140 +
Universal CRT di SysWOW64). Scan JAB kini jalan di goroutine terpisah
yang dijaga satu jalan, supaya satu panggilan JAB yang macet tidak
membuat seluruh polling diam.

BARU DI v0.9: cek handler .jnlp dari registry (otomatis saat program
dibuka dan saat tekan R). Program menampilkan javaws.exe dari Java mana
yang dipakai Windows untuk membuka frmservlet.jnlp, dan apakah folder
Java itu punya file bridge. Ini pertanyaan penentunya: kalau handler
menunjuk ke jre6/latest (tidak punya file bridge), bridge tidak akan
pernah aktif apa pun yang dilakukan tombol R, dan restart Oracle pun
tidak ada gunanya — Oracle harus jalan di jre1.8.0_471. Cek proses Java
juga sekarang menampilkan jumlah proses yang dipindai, jadi ketahuan
kalau pemindaiannya sendiri yang gagal.

BARU DI v0.8: SATU TOMBOL SAJA — R. Tekan R, program mengerjakan semua
persiapan otomatis (tulis file JAB user, muat DLL bridge, daftarkan
callback klik, cek jendela + proses Java), lalu menampilkan:
"Program sudah berjalan, silahkan buka java oracle dan lakukan submit
data." Setelah itu tinggal submit di Oracle seperti biasa — cmd
otomatis menampilkan log tiap langkah (KLIK Submit + jam, Request ID,
produk/batch) dan RESULT akhirnya:
  RESULT :
  BPP
  SUBMMITED DATE : 2026-11-10 20:15:30
  LKJTA JL436
Tombol E/J/C/P/T/S tetap ada untuk keperluan manual, tapi tidak perlu
lagi ditekan. Satu catatan: file JAB harus sudah ada SEBELUM Java Oracle
start — jadi kalau ini pertama kali R ditekan di PC ini, tutup total
Oracle lalu buka lagi sekali saja, record sudah jalan, tinggal submit.
RESULT juga tidak lagi menunggu teks BPP kebaca — jam submit + produk/
batch yang sudah ada cukup untuk mencetak RESULT.

BARU DI v0.7: tombol P + cek otomatis saat program dibuka dan saat tekan R:
program menampilkan proses Java yang sedang jalan (javaw.exe / java.exe /
javaws.exe) beserta path lengkap, jam start, dan 32/64-bit, lalu
membandingkannya dengan jam file E ditulis. Kalau JVM Oracle start
SEBELUM file E ditulis, program bilang langsung: JVM itu belum baca
file E, harus tutup total Oracle lalu buka lagi. Kalau Oracle jalan di
Java lain yang tidak punya file bridge (jre6/latest), program bilang
juga. Jadi tidak perlu tebak-tebakan lagi kenapa CEK JAVA nol.

BARU DI v0.6: perbaikan tombol E. Sebelumnya E tidak menulis file kalau
DLL Windows sudah ke-load ("JAB sudah aktif") — padahal DLL ke-load
BUKAN berarti Java Oracle sudah mengaktifkan bridge. Akibatnya file
.accessibility.properties tidak pernah tertulis dan record diam saja.
Sekarang E SELALU menulis file, apa pun status DLL-nya. File ini
per-user dan per-PC: tiap PC / tiap akun Windows harus tekan E sekali.

BARU DI v0.5: tombol C + cek otomatis saat program dibuka dan saat tekan R:
program melaporkan apakah ada jendela Java yang bridge-nya merespon
("CEK JAVA"). Kalau TIDAK ADA jendela Java, berarti JVM Oracle belum
memuat bridge (biasanya Oracle dibuka sebelum tekan E) — tutup semua
Oracle lalu buka lagi. Jadi record tidak diam tanpa kabar lagi.

BARU DI v0.4: perbaikan NAMA FUNGSI JAB. Nama export asli di DLL itu
huruf kecil (isJavaWindow, getAccessibleContextInfo, ...) dan setter
callback pakai akhiran FP (setMouseClickedFP, ...). v0.1-v0.3 memakai
nama huruf besar (IsJavaWindow, SetMouseClicked) yang TIDAK ADA di DLL,
jadi selalu gagal walau DLL-nya ke-load. v0.4 mencoba nama asli dulu,
lalu varian huruf besar sebagai fallback.

BARU DI v0.3: tombol E di dalam program untuk mengaktifkan JAB cara
user (tanpa Admin, tanpa IT), plus diagnosa otomatis isi folder Java
saat program dibuka, plus perbaikan load DLL bridge (msvcr100.dll /
vcruntime140.dll / ucrtbase.dll dimuat dulu dari folder Java yang sama,
karena Windows tidak mencari dependency di folder si DLL itu sendiri).

File di ZIP ini:
  B7OracleProbe64.exe  - coba yang ini dulu (butuh Java 64-bit)
  B7OracleProbe32.exe  - kalau yang 64-bit gagal soal JAB, coba ini (Java 32-bit)
  README.txt           - file ini

LANGKAH 0 - TIDAK ADA LAGI (sejak v0.8, R mengerjakan semuanya)
--------------------------------------------------------------------
  Dulu: tekan E untuk mengaktifkan JAB, lalu restart Oracle, baru R.
  Sekarang: cukup tekan R. Program otomatis menulis file JAB user
  (%USERPROFILE%\.accessibility.properties), memuat DLL bridge,
  mendaftarkan callback klik, lalu mengecek jendela + proses Java.
  Satu-satunya yang tetap perlu dilakukan sekali saja di tiap PC:
  kalau ini pertama kali R ditekan di PC itu, TUTUP total Oracle
  lalu BUKA LAGI (file JAB harus sudah ada SEBELUM Java Oracle
  start). Setelah itu record sudah jalan — tinggal submit.
  Tombol E/J di bawah ini hanya untuk keperluan manual.

  CARA USER, TANPA ADMIN (manual, kalau mau tekan E sendiri):
    1. Buka program ini (B7OracleProbe64.exe). Perhatikan baris
       DIAGNOSA di awal: program menampilkan file bridge apa saja
       yang ADA / tidak ada di tiap folder bin Java, jadi tidak
       perlu lagi buka-buka folder manual.
    2. Tekan E. Program menulis file di folder user sendiri:
         %USERPROFILE%\.accessibility.properties
       isinya 2 baris (assistive_technologies + screen_magnifier).
       File ini yang dibaca Java saat start. Tidak menyentuh
       System32, tidak mengubah file Java, tidak muncul prompt
       Admin, tidak perlu IT. Ini isi yang sama dengan yang
       ditulis jabswitch -enable.
    3. Kalau program bilang "DLL bridge Windows ketemu", lanjut
       langkah 4. Kalau bilang belum ketemu, lihat DIAGNOSA:
       kalau file WindowsAccessBridge-32.dll TIDAK ADA di folder
       Java, berarti JAB memang tidak ter-install di Java itu.
    4. TUTUP Oracle Forms lalu BUKA LAGI (Java baru memuat bridge
       saat start). Tutup-buka lagi program ini, tekan R untuk
       mulai record.

  CARA JABSWITCH (tombol J, butuh Admin):
    1. Buka program ini, tekan J. Program menjalankan
       jabswitch -enable. Akan muncul prompt Admin Windows.
       Kalau akun lo bukan admin, Windows minta password admin.
    2. TUTUP Oracle Forms lalu BUKA LAGI, tekan R.

  Catatan: JAB adalah fitur resmi Java (buat screen reader),
  bukan hack. Kalau langkah ini dilewati, program tetap jalan
  tapi HANYA bisa melihat judul jendela (mis. dialog "Decision")
  dan TIDAK bisa membaca isi teks / button di dalam Oracle.

LANGKAH 1 - JALANKAN (cukup tekan R)
--------------------------------------
  1. Double-click B7OracleProbe32.exe (Java di PC ini 32-bit).
     Muncul jendela cmd hitam.
  2. Tekan R saja. Program otomatis menyiapkan semuanya, lalu
     menampilkan: "Program sudah berjalan, silahkan buka java
     oracle dan lakukan submit data." Kalau mau berhenti, tekan Q.
  3. Buka Oracle Java seperti biasa, jalankan alur:
       Run this Request -> isi Parameters -> klik Submit
       -> dialog "Decision" muncul -> klik No
       -> daftar Requests muncul (baris teratas = request barusan)
  4. Perhatikan layar cmd: SETIAP button yang lo klik di Oracle akan
     muncul live sebagai baris "KLIK: ...". Ini pembuktian bahwa
     semua button Oracle bisa di-record, bukan cuma Submit.
  5. Kalau semua langkah kebaca, muncul:
       RESULT :
       BPP
       SUBMMITED DATE : 2026-11-10 17:05:22
       LKJTA JL436
  6. Tekan Q untuk keluar.

TOMBOL LAIN DI CMD
------------------
  E = aktifkan JAB cara user (tanpa Admin) - lihat LANGKAH 0
  J = aktifkan JAB via jabswitch (butuh Admin) - lihat LANGKAH 0
  T = dump tree (tulis seluruh isi layar Oracle yang kebaca ke tree_dump.txt)
  S = scan paksa (baca ulang layar Oracle sekarang juga)

FILE HASIL (di folder yang sama dengan EXE)
--------------------------------------------
  record.log     - log lengkap semua event + jam (kirim file ini ke gw)
  tree_dump.txt  - isi layar Oracle yang berhasil dibaca JAB
  result.txt     - RESULT terakhir + detail (Request ID, dsb.)

KALAU ADA MASALAH, CATAT / KIRIM KE GW
----------------------------------------
  - "JAB TIDAK ketemu"  -> JAB belum aktif (coba tombol E dulu,
    lihat Langkah 0), atau coba EXE satunya (64-bit <-> 32-bit).
  - "Tidak ada jendela Java" -> Oracle belum dibuka, atau JAB belum aktif.
  - Dialog "Decision" muncul di layar tapi tidak ada baris KLIK saat
    klik Submit -> callback klik tidak jalan di Java ini; program tetap
    mencatat jam submit dari munculnya dialog (ditulis "fallback" di log).
  - RESULT tidak muncul tapi baris KLIK jalan -> kirim record.log +
    tree_dump.txt ke gw, gw lihat struktur layarnya.

Program ini HANYA MEMBACA layar Oracle dan mencatat ke file log.
Tidak mengubah data apa pun di Oracle.
