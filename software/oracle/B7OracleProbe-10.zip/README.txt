B7OracleProbe v0.12 - Proof of Concept (Agent Sniffing)
=====================================================
Recorder Oracle EBS Forms (Java) via Java agent yang ditempel ke JVM
Oracle yang SUDAH jalan (Attach API).

TIDAK PERLU: restart Oracle, restart browser, Admin/IT, atau JAB.
Oracle sudah login dan jalan duluan pun tidak apa-apa — agen ditempel
ke prosesnya yang sedang berjalan.

Cara pakai (cukup 1 tombol):
1. Extract ZIP ini ke satu folder (mis. Desktop\oracle).
2. Jalankan B7OracleProbe32.exe (Java Oracle 32-bit) atau
   B7OracleProbe64.exe (Java 64-bit). Jalankan biasa, bukan Run as Admin.
3. Tekan R. Program mencari jendela Oracle, menempelkan agen ke
   prosesnya, lalu merekam. Kalau Oracle belum dibuka, program menunggu
   dan menempel otomatis begitu jendela Oracle muncul.
4. Eksekusi di Oracle seperti biasa (klik View, Submit, dsb).
   Tiap klik tercatat SATU baris log atomik di jendela cmd, misal:
     2026-11-11 17:45:01.123 KLIK: "View Details" (JButton)
     2026-11-11 17:45:02.456 KLIK: "Submit" (JButton)
   Teks layar dibaca tiap detik (judul menu, BPP, Request ID, baris
   teratas tabel Requests -> kode produk + kode batch).
5. Setelah submit + masuk menu Requests, program mencetak RESULT:
     RESULT :
     BPP
     SUBMMITED DATE : 2026-11-11 17:45:02
     LKJTA JL436
   dan menyimpannya ke result.txt di folder yang sama.

Tombol lain: S = tempel ulang agent, A = status agent,
P = cek proses Java, Q = keluar.

File-file:
  B7OracleProbe64.exe / B7OracleProbe32.exe - program probe (cmd)
  B7Agent.jar       - agen Java (dibaca Oracle dari dalam JVM-nya)
  B7Attacher.jar    - program kecil yang menempelkan agen (Attach API)
  attach-api.jar    - API Attach JDK 8 (supaya attacher jalan di JRE)
  attach.dll        - library Attach JDK 8 32-bit (wajib satu folder)
  record.log        - log lengkap probe (dibuat otomatis)
  agent-events.log  - log mentah agen (dibuat otomatis)
  result.txt        - hasil RESULT (dibuat otomatis)

Catatan jujur:
- Agen hanya MEMBACA (klik + teks layar). Tidak mengubah data apa pun
  di Oracle dan tidak mengirim apa pun ke jaringan.
- Kalau agen gagal ditempel, log akan bilang sebabnya (mis. Oracle
  belum dibuka, atau java.exe tidak ketemu). Tekan R lagi untuk coba
  ulang, atau tekan A untuk status agent.
- Versi 0.1-0.11 memakai Java Access Bridge (JAB) dan ditinggalkan:
  JAB hanya aktif kalau JVM start dengan bridge diaktifkan, sementara
  use case di sini Oracle sudah jalan duluan.
