B7OracleProbe v0.14 - Proof of Concept (Agent Sniffing)
=====================================================
Recorder Oracle EBS Forms (Java) via Java agent yang ditempel ke JVM
Oracle yang SUDAH jalan (Attach API).

CUKUP 1 FILE EXE. File agen (B7Agent.jar, B7Attacher.jar,
attach-api.jar, attach.dll) sudah dikemas DI DALAM exe dan diekstrak
otomatis saat program jalan. Tidak ada file lain yang perlu dibawa.

TIDAK PERLU: restart Oracle, restart browser, Admin/IT, atau JAB.
Oracle sudah login dan jalan duluan pun tidak apa-apa — agen ditempel
ke prosesnya yang sedang berjalan.

Cara pakai (cukup 1 tombol):
1. Jalankan B7OracleProbe32.exe (Java Oracle 32-bit) atau
   B7OracleProbe64.exe (Java 64-bit). Jalankan biasa, bukan Run as Admin.
2. Tekan R. Program mencari jendela Oracle, menempelkan agen ke
   prosesnya, lalu merekam. Kalau Oracle belum dibuka, program menunggu
   dan menempel otomatis begitu jendela Oracle muncul.
3. Eksekusi di Oracle seperti biasa (klik View, Submit, dsb).
   Tiap klik tercatat SATU baris log atomik di jendela cmd, misal:
     2026-11-11 17:45:01.123 KLIK: "View Details" (JButton)
     2026-11-11 17:45:02.456 KLIK: "Submit" (JButton)
   Teks layar dibaca tiap detik (judul menu, BPP, Request ID, baris
   teratas tabel Requests -> kode produk + kode batch).
4. Setelah submit + masuk menu Requests, program mencetak RESULT:
     RESULT :
     BPP
     SUBMMITED DATE : 2026-11-11 17:45:02
     LKJTA JL436
   dan menyimpannya ke result.txt di folder yang sama.

Tombol lain: S = tempel ulang agent, A = status agent,
P = cek proses Java, Q = keluar.

File yang dibuat program (otomatis, di folder exe):
  record.log        - log lengkap probe
  agent-events.log  - log mentah agen
  result.txt        - hasil RESULT
  B7Agent.jar, B7Attacher.jar, attach-api.jar, attach.dll
                    - file agen hasil ekstrak (abaikan saja)

Isi agen (buat yang penasaran):
  B7Agent.jar    - agen "sniffer": hidup di dalam JVM Oracle, merekam
                   klik + membaca teks layar dari dalam.
  B7Attacher.jar - program kecil yang menempelkan agen ke Oracle.
  attach-api.jar - API Attach JDK 8 (supaya attacher bisa bicara ke
                   JVM yang sudah jalan).
  attach.dll     - library native Attach JDK 8 32-bit.

Catatan jujur:
- Agen hanya MEMBACA (klik + teks layar). Tidak mengubah data apa pun
  di Oracle dan tidak mengirim apa pun ke jaringan.
- v0.14 ini membawa diagnosa sendiri: 3 detik setelah agen ditempel,
  program mengecek apakah file log agen ada dan seberapa besar, lalu
  menuliskannya di cmd ("AGENT: cek log ..."). Kalau agen tidak bisa
  menulis log di folder exe, ia otomatis memakai file cadangan di
  folder Temp Windows (B7Agent-events.log) dan program akan membacanya
  dari sana. Jadi habis tekan R, tunggu 10 detik, lalu foto layar cmd.
- Kalau agen gagal ditempel, log akan bilang sebabnya (mis. Oracle
  belum dibuka, atau java.exe tidak ketemu). Tekan R lagi untuk coba
  ulang, atau tekan A untuk status agent.
- Versi 0.1-0.11 memakai Java Access Bridge (JAB) dan ditinggalkan:
  JAB hanya aktif kalau JVM start dengan bridge diaktifkan, sementara
  use case di sini Oracle sudah jalan duluan.
