B7OracleProbe v0.4 - Proof of Concept
====================================
Program sederhana (bukan Python) untuk membuktikan apakah Oracle EBS Forms
(Java) bisa di-record: baca teks BPP, record klik Submit, baca Request ID,
baca baris teratas daftar Requests.

BARU DI v0.4: perbaikan NAMA FUNGSI JAB. Nama export asli di DLL itu
huruf kecil (isJavaWindow, getAccessibleContextInfo, ...) dan setter
callback pakai akhiran FP (setMouseClickedFP, ...). v0.1-v0.3 memakai
nama huruf besar (IsJavaWindow, SetMouseClicked) yang TIDAK ADA di DLL,
jadi selalu gagal walau DLL-nya ke-load. v0.4 mencoba nama asli dulu,
lalu varian huruf besar sebagai fallback.

BARU DI v0.3: tombol E di dalam program untuk mengaktifkan JAB cara
user (tanpa Admin, tanpa IT), plus diagnosa otomatis isi folder Java
saat program dibuka, plus perbaikan load DLL bridge (msvcr100.dll /
vcruntime140.dll / ucrtbase.dll dimuat dulu dari folder Java yang sama,
karena Windows tidak mencari dependency di folder si DLL itu sendiri).

File di ZIP ini:
  B7OracleProbe64.exe  - coba yang ini dulu (butuh Java 64-bit)
  B7OracleProbe32.exe  - kalau yang 64-bit gagal soal JAB, coba ini (Java 32-bit)
  README.txt           - file ini

LANGKAH 0 - AKTIFKAN JAVA ACCESS BRIDGE (sekali saja, di PC kantor)
--------------------------------------------------------------------
  CARA USER, TANPA ADMIN (baru di v0.3, coba ini dulu):
    1. Buka program ini (B7OracleProbe64.exe). Perhatikan baris
       DIAGNOSA di awal: program menampilkan file bridge apa saja
       yang ADA / tidak ada di tiap folder bin Java, jadi tidak
       perlu lagi buka-buka folder manual.
    2. Tekan E. Program menulis file di folder user sendiri:
         %USERPROFILE%\.accessibility.properties
       isinya 2 baris (assistive_technologies + screen_magnifier).
       File ini yang dibaca Java saat start. Tidak menyentuh
       System32, tidak mengubah file Java, tidak muncul prompt
       Admin, tidak perlu IT. Ini isi yang sama dengan yang
       ditulis jabswitch -enable.
    3. Kalau program bilang "DLL bridge Windows ketemu", lanjut
       langkah 4. Kalau bilang belum ketemu, lihat DIAGNOSA:
       kalau file WindowsAccessBridge-32.dll TIDAK ADA di folder
       Java, berarti JAB memang tidak ter-install di Java itu.
    4. TUTUP Oracle Forms lalu BUKA LAGI (Java baru memuat bridge
       saat start). Tutup-buka lagi program ini, tekan R untuk
       mulai record.

  CARA JABSWITCH (tombol J, butuh Admin):
    1. Buka program ini, tekan J. Program menjalankan
       jabswitch -enable. Akan muncul prompt Admin Windows.
       Kalau akun lo bukan admin, Windows minta password admin.
    2. TUTUP Oracle Forms lalu BUKA LAGI, tekan R.

  Catatan: JAB adalah fitur resmi Java (buat screen reader),
  bukan hack. Kalau langkah ini dilewati, program tetap jalan
  tapi HANYA bisa melihat judul jendela (mis. dialog "Decision")
  dan TIDAK bisa membaca isi teks / button di dalam Oracle.

LANGKAH 1 - JALANKAN
---------------------
  1. Double-click B7OracleProbe64.exe (muncul jendela cmd hitam).
  2. Tekan R  (mulai record). Kalau mau berhenti, tekan Q.
  3. Buka Oracle Java seperti biasa, jalankan alur:
       Run this Request -> isi Parameters -> klik Submit
       -> dialog "Decision" muncul -> klik No
       -> daftar Requests muncul (baris teratas = request barusan)
  4. Perhatikan layar cmd: SETIAP button yang lo klik di Oracle akan
     muncul live sebagai baris "KLIK: ...". Ini pembuktian bahwa
     semua button Oracle bisa di-record, bukan cuma Submit.
  5. Kalau semua langkah kebaca, muncul:
       RESULT :
       BPP
       SUBMMITED DATE : 2026-11-10 17:05:22
       LKJTA JL436
  6. Tekan Q untuk keluar.

TOMBOL LAIN DI CMD
------------------
  E = aktifkan JAB cara user (tanpa Admin) - lihat LANGKAH 0
  J = aktifkan JAB via jabswitch (butuh Admin) - lihat LANGKAH 0
  T = dump tree (tulis seluruh isi layar Oracle yang kebaca ke tree_dump.txt)
  S = scan paksa (baca ulang layar Oracle sekarang juga)

FILE HASIL (di folder yang sama dengan EXE)
--------------------------------------------
  record.log     - log lengkap semua event + jam (kirim file ini ke gw)
  tree_dump.txt  - isi layar Oracle yang berhasil dibaca JAB
  result.txt     - RESULT terakhir + detail (Request ID, dsb.)

KALAU ADA MASALAH, CATAT / KIRIM KE GW
----------------------------------------
  - "JAB TIDAK ketemu"  -> JAB belum aktif (coba tombol E dulu,
    lihat Langkah 0), atau coba EXE satunya (64-bit <-> 32-bit).
  - "Tidak ada jendela Java" -> Oracle belum dibuka, atau JAB belum aktif.
  - Dialog "Decision" muncul di layar tapi tidak ada baris KLIK saat
    klik Submit -> callback klik tidak jalan di Java ini; program tetap
    mencatat jam submit dari munculnya dialog (ditulis "fallback" di log).
  - RESULT tidak muncul tapi baris KLIK jalan -> kirim record.log +
    tree_dump.txt ke gw, gw lihat struktur layarnya.

Program ini HANYA MEMBACA layar Oracle dan mencatat ke file log.
Tidak mengubah data apa pun di Oracle.
