<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class Report extends Model
{
    protected $fillable = ['message', 'photos'];
    protected $casts = ['photos' => 'array']; // Otomatis handle JSON ke Array
}

