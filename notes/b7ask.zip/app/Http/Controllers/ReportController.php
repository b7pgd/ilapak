<?php

namespace App\Http\Controllers;

use App\Models\Report;
use Illuminate\Http\Request;

class ReportController extends Controller
{
    public function index() {
        return view('operator_home');
    }

    public function store(Request $request) {
        $request->validate([
            'message' => 'required',
            'photos.*' => 'image|mimes:jpeg,png,jpg|max:2048'
        ]);

        $paths = [];
        if($request->hasFile('photos')) {
            foreach($request->file('photos') as $photo) {
                $paths[] = $photo->store('reports', 'public');
            }
        }

        Report::create([
            'message' => $request->message,
            'photos' => $paths
        ]);

        return back()->with('success', 'Laporan berhasil terkirim!');
    }

    public function admin() {
        $reports = Report::latest()->get();
        return view('admin_panel', compact('reports'));
    }
}

