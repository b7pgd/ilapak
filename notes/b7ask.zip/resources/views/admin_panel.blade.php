<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin Panel - Riwayat Keluhan</title>
    <script src="https://cdn.tailwindcss.com"></script>
</head>
<body class="bg-slate-200 p-4">
    <div class="max-w-2xl mx-auto">
        <h1 class="text-2xl font-bold mb-6 text-gray-800">Riwayat Masukan Karyawan</h1>
        
        <div class="space-y-4">
            @foreach($reports as $report)
            <div class="bg-white p-4 rounded-lg shadow-sm border-l-4 border-blue-500">
                <p class="text-gray-800 whitespace-pre-wrap">{{ $report->message }}</p>
                
                @if($report->photos)
                <div class="flex flex-wrap gap-2 mt-3">
                    @foreach($report->photos as $path)
                    <a href="{{ asset('storage/'.$path) }}" target="_blank">
                        <img src="{{ asset('storage/'.$path) }}" class="w-20 h-20 object-cover rounded-md border hover:opacity-80 transition">
                    </a>
                    @endforeach
                </div>
                @endif
                
                <span class="text-[10px] text-gray-400 mt-2 block italic">{{ $report->created_at->format('d M Y, H:i') }} WIB</span>
            </div>
            @endforeach
        </div>
    </div>
</body>
</html>

