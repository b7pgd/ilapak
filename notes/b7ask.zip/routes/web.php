<?php

use Illuminate\Support\Facades\Route;
use App\Http\Controllers\ReportController;

Route::get('/', [ReportController::class, 'index'])->name('home');
Route::post('/report', [ReportController::class, 'store'])->name('report.store');

// URL admin di-hide (hanya yang tahu linknya yang bisa akses)
Route::get('/panel-admin-rahasia-askb7', [ReportController::class, 'admin']);

