Langkah Penting Terakhir:
​Jalankan perintah php artisan storage:link di terminal agar foto yang diupload bisa muncul di browser.
​Pastikan folder storage/app/public/reports tersedia atau akan dibuat otomatis saat upload.